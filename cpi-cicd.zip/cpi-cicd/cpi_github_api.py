#!/usr/bin/env python3
"""
SAP CPI to GitHub Deployment API
Converted from Jupyter Notebook

This Python API provides automated deployment of SAP Cloud Platform Integration (CPI) 
artifacts to GitHub repositories.

Features:
1. Download IFlow artifacts from SAP CPI using OData API
2. Create/manage GitHub repositories named after CPI packages
3. Environment-specific branching (dev, test, prod)
4. Automated pull request creation for code review
5. RESTful API built with FastAPI
6. HTTP Proxy support for CPI API calls with authentication

Requirements:
- SAP CPI access with valid S-User credentials
- GitHub personal access token with repo permissions
- Python packages: fastapi, requests, uvicorn, pydantic, python-multipart
- Git CLI and GitHub CLI (gh) installed

Proxy Configuration:
- Supports HTTP/HTTPS proxies with optional authentication
- Can be configured per request or via environment variables for webhooks
- Environment variables: CPI_PROXY_URL, CPI_PROXY_USERNAME, CPI_PROXY_PASSWORD
"""

from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import requests
import base64
import os
import tempfile
import shutil
import zipfile
import json
import subprocess
import socket
import time
import hmac
import hashlib
import uvicorn
import zipfile
import zipfile
import subprocess
import logging
import json
import hmac
import hashlib
import socket
import secrets
import time
from datetime import datetime
from typing import Optional, Dict, Any
import uvicorn
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Configuration and Data Models

# CPI tenant URLs for different environments
CPI_TENANTS = {
    "dev": "https://l5967-tmn.hci.us2.hana.ondemand.com",
    "test": "https://l5968-tmn.hci.us2.hana.ondemand.com", 
    "prod": "https://your-prod-tenant.hci.eu1.hana.ondemand.com"
}

# Connection configuration for troubleshooting
CONNECTION_CONFIG = {
    "connect_timeout": 60,  # Seconds to wait for connection
    "read_timeout": 1000,    # Seconds to wait for response
    "max_retries": 3,       # Number of retry attempts
    "backoff_factor": 1,    # Wait time multiplier between retries
    "verify_ssl": True,     # Set to False if SSL issues (NOT recommended for production)
    "chunk_size": 8192      # Chunk size for file downloads
}

# Global HTTP Proxy Configuration for CPI API calls
# Set these values to configure proxy for all CPI OData API requests
GLOBAL_PROXY_CONFIG = {
    "enabled": True,  # Set to True to enable proxy
    "proxy_url": "proxy-intlho.wal-mart.com:8080",  # Your proxy server URL
    "proxy_username": "k0j0abt",  # Proxy username (set if authentication required)
    "proxy_password": "StrongestPassw0rd!",  # Proxy password (set if authentication required)
    "proxy_type": "http"     # Proxy type (http/https)
}

# Proxy configuration class
class ProxyConfig:
    """HTTP Proxy configuration for CPI API calls"""
    def __init__(self, 
                 proxy_url: Optional[str] = None,
                 proxy_username: Optional[str] = None, 
                 proxy_password: Optional[str] = None,
                 proxy_type: str = "http"):
        self.proxy_url = proxy_url
        self.proxy_username = proxy_username
        self.proxy_password = proxy_password
        self.proxy_type = proxy_type.lower()
    
    def get_proxies(self) -> Optional[Dict[str, str]]:
        """Get proxy configuration for requests"""
        if not self.proxy_url:
            return None
        
        # Build proxy URL with authentication if provided
        if self.proxy_username and self.proxy_password:
            # Format: http://username:password@proxy_host:port
            proxy_parts = self.proxy_url.split("://")
            if len(proxy_parts) == 2:
                scheme, host_port = proxy_parts
                proxy_url = f"{scheme}://{self.proxy_username}:{self.proxy_password}@{host_port}"
            else:
                # Assume no scheme provided, default to http
                proxy_url = f"http://{self.proxy_username}:{self.proxy_password}@{self.proxy_url}"
        else:
            proxy_url = self.proxy_url
        
        return {
            "http": proxy_url,
            "https": proxy_url
        }
    
    def is_enabled(self) -> bool:
        """Check if proxy is configured"""
        return bool(self.proxy_url)

def get_global_proxy_config() -> Optional[ProxyConfig]:
    """Get global proxy configuration based on GLOBAL_PROXY_CONFIG settings"""
    if not GLOBAL_PROXY_CONFIG.get("enabled", False):
        return None
    
    return ProxyConfig(
        proxy_url=GLOBAL_PROXY_CONFIG.get("proxy_url"),
        proxy_username=GLOBAL_PROXY_CONFIG.get("proxy_username"),
        proxy_password=GLOBAL_PROXY_CONFIG.get("proxy_password"),
        proxy_type=GLOBAL_PROXY_CONFIG.get("proxy_type", "http")
    )

# Request model for deployment
class GitUploadRequest(BaseModel):
    cpi_package: str = Field(..., description="SAP CPI Package Name")
    iflow_name: str = Field(..., description="IFlow Name")
    cpi_environment: str = Field(..., description="Environment (dev/test/prod)")
    s_user: str = Field(..., description="SAP S-User ID")
    s_password: str = Field(..., description="SAP S-User Password")
    github_token: str = Field(..., description="GitHub Personal Access Token")

# Response model
class GitUploadResponse(BaseModel):
    status: str
    message: str
    repository_url: Optional[str] = None
    branch_name: Optional[str] = None
    pull_request_url: Optional[str] = None
    
# Error response model
class ErrorResponse(BaseModel):
    error: str
    details: Optional[str] = None

# CPI Connection validation request model
class CPIConnectionRequest(BaseModel):
    environment: str = Field(..., description="Environment (dev/test/prod)")
    s_user: str = Field(..., description="SAP S-User ID")
    s_password: str = Field(..., description="SAP S-User Password")

# Test upload request model
class TestUploadRequest(BaseModel):
    cpi_package: str = Field(..., description="SAP CPI Package Name")
    iflow_name: str = Field(..., description="IFlow Name")
    cpi_environment: str = Field(..., description="Environment (dev/test/prod)")
    s_user: str = Field(..., description="SAP S-User ID")
    s_password: str = Field(..., description="SAP S-User Password")
    github_token: str = Field(..., description="GitHub Personal Access Token")

# Webhook models
class WebhookRepository(BaseModel):
    name: str
    full_name: str
    clone_url: str

class WebhookCommit(BaseModel):
    id: str
    message: str
    timestamp: str
    author: Dict[str, Any]
    modified: list = []
    added: list = []
    removed: list = []

class WebhookPush(BaseModel):
    ref: str
    before: str
    after: str
    repository: WebhookRepository
    commits: list = []
    head_commit: Optional[WebhookCommit] = None

class DeploymentResponse(BaseModel):
    status: str
    message: str
    environment: str
    package: Optional[str] = None
    iflow: Optional[str] = None
    deployment_details: Optional[Dict[str, Any]] = None

# Configuration for webhook secret (should be environment variable in production)
WEBHOOK_SECRET = os.getenv("GITHUB_WEBHOOK_SECRET", "your-webhook-secret-here")

# SAP CPI Integration Class

class CPIClient:
    """Client for interacting with SAP CPI OData API"""
    
    def __init__(self, base_url: str, username: str, password: str, proxy_config: Optional[ProxyConfig] = None):
        self.base_url = base_url.rstrip('/')
        self.auth_header = self._create_auth_header(username, password)
        self.proxy_config = proxy_config
        self.session = self._create_session_with_retry()
        self._csrf_token = None  # Cache CSRF token
    
    def _create_auth_header(self, username: str, password: str) -> str:
        """Create basic authentication header"""
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        return f"Basic {encoded_credentials}"
    
    def _create_session_with_retry(self) -> requests.Session:
        """Create a requests session with retry strategy"""
        session = requests.Session()
        
        # Configure proxy if provided
        if self.proxy_config and self.proxy_config.is_enabled():
            proxies = self.proxy_config.get_proxies()
            if proxies:
                session.proxies.update(proxies)
                print(f"🌐 Proxy configured: {self.proxy_config.proxy_url}")
        
        # Define retry strategy - updated for newer urllib3 versions
        retry_strategy = Retry(
            total=3,  # Total number of retries
            status_forcelist=[429, 500, 502, 503, 504],  # HTTP status codes to retry
            allowed_methods=["HEAD", "GET", "PUT", "DELETE", "OPTIONS", "TRACE", "POST"],  # Updated parameter name
            backoff_factor=2,  # Increased backoff time between retries
            raise_on_redirect=False,
            raise_on_status=False
        )
        
        # Mount adapter with retry strategy
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,
            pool_maxsize=20
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Configure session to mimic browser behavior
        session.verify = True  # Keep SSL verification enabled
        session.stream = False  # Don't stream by default
        
        return session
    
    def _get_csrf_token(self) -> str:
        """Get CSRF token for POST/PUT operations"""
        if self._csrf_token:
            return self._csrf_token
            
        # Fetch CSRF token using a HEAD request to any endpoint
        url = f"{self.base_url}/api/v1/IntegrationPackages"
        headers = {
            "Authorization": self.auth_header,
            "X-CSRF-Token": "Fetch",  # Request CSRF token
            "Accept": "application/json"
        }
        
        try:
            print("🔑 Fetching CSRF token...")
            response = self.session.head(url, headers=headers, verify=False, timeout=(30, 60))
            
            if response.status_code in [200, 404]:  # 404 is also acceptable for token fetch
                csrf_token = response.headers.get('X-CSRF-Token')
                if csrf_token:
                    self._csrf_token = csrf_token
                    print(f"✅ CSRF token obtained: {csrf_token[:20]}...")
                    return csrf_token
                else:
                    print("⚠️ No CSRF token in response headers")
                    return None
            else:
                print(f"❌ Failed to fetch CSRF token: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ Error fetching CSRF token: {str(e)}")
            return None
    
    def _refresh_csrf_token(self):
        """Refresh CSRF token (invalidate cache)"""
        self._csrf_token = None
        return self._get_csrf_token()
    
    def _make_request(self, method: str, url: str, headers: dict = None, **kwargs) -> requests.Response:
        """Make HTTP request with error handling and retries"""
        if headers is None:
            headers = {}
        
        # Add headers that mimic Postman/browser requests
        headers = {
            "Authorization": self.auth_header,
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            **headers  # Merge with any provided headers
        }
        
        # Add CSRF token for POST, PUT, DELETE operations
        if method.upper() in ['POST', 'PUT', 'DELETE']:
            csrf_token = self._get_csrf_token()
            if csrf_token:
                headers["X-CSRF-Token"] = csrf_token
                print(f"🔑 Added CSRF token to {method} request")
            else:
                print(f"⚠️ No CSRF token available for {method} request")

        request_options = {
            "verify": False,  # Verify SSL certificates
            "allow_redirects": True,
            "timeout": (60, 1000),  # (connect_timeout, read_timeout)
        }
        request_options.update(kwargs)
        
        print(f"🔍 Making {method} request to: {url}")
        # Add small delay to avoid overwhelming the server
        time.sleep(0.5)  # 500ms delay between requests
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                **request_options
            )
            
            print(f"📊 Response: {response.status_code} - {response.reason}")
            
            # Check if CSRF token is invalid (typically 403 Forbidden)
            if response.status_code == 403 and method.upper() in ['POST', 'PUT', 'DELETE']:
                print("🔄 CSRF token might be invalid, refreshing...")
                csrf_token = self._refresh_csrf_token()
                if csrf_token:
                    headers["X-CSRF-Token"] = csrf_token
                    print("🔄 Retrying request with new CSRF token...")
                    response = self.session.request(
                        method=method,
                        url=url,
                        headers=headers,
                        **request_options
                    )
                    print(f"📊 Retry Response: {response.status_code} - {response.reason}")
            
            # Log response headers for debugging
            print(f"📥 Response Headers: {dict(response.headers)}")
            
            return response
            
        except requests.exceptions.ConnectionError as e:
            error_msg = f"Connection error to CPI server: {str(e)}"
            print(f"❌ {error_msg}")
            raise HTTPException(status_code=503, detail=error_msg)
            
        except requests.exceptions.Timeout as e:
            error_msg = f"Request timeout to CPI server: {str(e)}"
            print(f"⏰ {error_msg}")
            raise HTTPException(status_code=504, detail=error_msg)
            
        except requests.exceptions.SSLError as e:
            error_msg = f"SSL error connecting to CPI server: {str(e)}"
            print(f"🔒 {error_msg}")
            raise HTTPException(status_code=495, detail=error_msg)
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Request failed to CPI server: {str(e)}"
            print(f"🚫 {error_msg}")
            raise HTTPException(status_code=500, detail=error_msg)
    
    def get_iflow_details(self, cpi_package: str, iflow_name: str) -> dict:
        """Get IFlow details from CPI"""
        url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_name}',Version='active')"
        headers = {
            "Accept": "application/json"
        }
        print(f"🔍 Fetching IFlow details from: {url}")
        
        response = self._make_request("GET", url, headers=headers)
        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to get IFlow details: {response.text}"
            )
        print(f"ODATA API Response:", response.content)
        return response.content if response.content else {}
    
    def download_iflow_artifact(self, cpi_package: str, iflow_name: str, download_path: str) -> str:
        """Download IFlow artifact as ZIP file"""
        url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_name}',Version='active')/$value"
        headers = {
            "Accept": "application/zip"
        }
        
        print(f"🔄 Downloading IFlow artifact from: {url}")
        response = self._make_request("GET", url, headers=headers, stream=True)
        
        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to download IFlow artifact: {response.text}"
            )
        
        # Save the ZIP file
        zip_path = os.path.join(download_path, f"{iflow_name}.zip")
        print(f"💾 Saving ZIP file to: {zip_path}")
        
        try:
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:  # Filter out keep-alive chunks
                        f.write(chunk)
            
            file_size = os.path.getsize(zip_path)
            print(f"✅ Download completed. File size: {file_size} bytes")
            return zip_path
            
        except Exception as e:
            # Clean up partial file if download fails
            if os.path.exists(zip_path):
                os.remove(zip_path)
            raise HTTPException(
                status_code=500,
                detail=f"Failed to save downloaded file: {str(e)}"
            )

    def test_connection(self) -> dict:
        """Test connection to CPI server"""
        url = f"{self.base_url}/api/v1/IntegrationPackages"
        headers = {
            "Accept": "application/json"
        }
        
        print(f"🔍 Testing connection to CPI server: {self.base_url}")
        
        try:
            start_time = time.time()
            response = self._make_request("GET", url, headers=headers)
            response_time = time.time() - start_time
            
            return {
                "status": "success" if response.status_code == 200 else "failed",
                "status_code": response.status_code,
                "response_time_seconds": round(response_time, 2),
                "server_url": self.base_url,
                "message": "Connection successful" if response.status_code == 200 else f"HTTP {response.status_code}"
            }
            
        except HTTPException as e:
            return {
                "status": "failed",
                "status_code": e.status_code,
                "server_url": self.base_url,
                "error": e.detail
            }

    def validate_api_endpoints(self) -> dict:
        """Validate all API endpoints conform to SAP CPI OData specifications"""
        validation_results = {
            "base_url": self.base_url,
            "api_version": "v1",
            "endpoints_validated": [],
            "all_valid": True
        }
        
        # Test basic connectivity
        try:
            packages_url = f"{self.base_url}/api/v1/IntegrationPackages"
            response = self._make_request("GET", packages_url, headers={"Accept": "application/json"})
            validation_results["endpoints_validated"].append({
                "endpoint": "/api/v1/IntegrationPackages",
                "method": "GET",
                "status": "valid" if response.status_code == 200 else "invalid",
                "status_code": response.status_code
            })
        except Exception as e:
            validation_results["endpoints_validated"].append({
                "endpoint": "/api/v1/IntegrationPackages", 
                "method": "GET",
                "status": "error",
                "error": str(e)
            })
            validation_results["all_valid"] = False
        
        return validation_results


    def iflow_exists_in_designtime(self, cpi_package: str, iflow_name: str) -> bool:
        """Check if IFlow exists in design time artifacts"""
        try:
            url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_name}',Version='active')"
            headers = {
                "Accept": "application/json"
            }
            
            response = self._make_request("GET", url, headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            print(f"Error checking IFlow existence: {str(e)}")
            return False
    
    def get_iflow_info_if_exists(self, cpi_package: str, iflow_name: str) -> dict:
        """Get IFlow information if it exists, return None if not found"""
        try:
            iflow_details = self.get_iflow_details(cpi_package, iflow_name)
            return {
                "exists": True,
                "details": iflow_details
            }
        except HTTPException as e:
            if e.status_code == 404:
                return {
                    "exists": False,
                    "details": None
                }
            else:
                raise e
    
    def package_exists(self, cpi_package: str) -> bool:
        """Check if integration package exists"""
        try:
            print(f"🔍 Checking if package '{cpi_package}' exists...")
            url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')"
            headers = {
                "Accept": "application/json"
            }
            response = self._make_request("GET", url, headers=headers)
            return response.status_code == 200
        except Exception as e:
            print(f"Error checking package existence: {str(e)}")
            return False
    
    def create_package_if_not_exists(self, cpi_package: str, description: str = "") -> dict:
        """Create integration package if it doesn't exist"""
        if self.package_exists(cpi_package):
            print(f"Package '{cpi_package}' exists")
            return {"status": "exists", "message": f"Package {cpi_package} already exists"}
        
        url = f"{self.base_url}/api/v1/IntegrationPackages"
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "DataServiceVersion": "2.0"
        }
        
        data = {
            "Id": cpi_package,
            "Name": cpi_package,
            "Description": description or f"Auto-created package for {cpi_package}",
            "ShortText": cpi_package
        }
        
        response = self._make_request("POST", url, headers=headers, json=data)
        if response.status_code in [201, 202]:
            print(f"Package '{cpi_package}' created successfully")
            return {
                "status": "created",
                "message": f"Package {cpi_package} created successfully",
                "data": response.json() if response.content else {}
            }
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create package: {response.text}"
            )
    
    def update_iflow_artifact(self, cpi_package: str, iflow_name: str, zip_path: str) -> dict:
        """Update existing IFlow artifact in CPI"""
        url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_name}',Version='active')/$value"
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/zip"
        }
        
        # Read the ZIP file content
        with open(zip_path, 'rb') as f:
            zip_content = f.read()
            
        response = self._make_request("PUT", url, headers=headers, data=zip_content)
        
        if response.status_code in [200, 202, 204]:
            return {
                "status": "updated",
                "message": f"IFlow {iflow_name} updated successfully",
                "action": "update"
            }
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to update IFlow artifact: {response.text}"
            )

    def upload_iflow_artifact(self, cpi_package: str, iflow_name: str, zip_path: str) -> dict:
        """Create new IFlow artifact in CPI"""
        url = f"{self.base_url}/api/v1/IntegrationDesigntimeArtifacts"
        # Note: Do not set Content-Type for multipart/form-data - requests will set it automatically with boundary
        headers = {
            "Accept": "application/json"
        }
        
        # Read the ZIP file content
        with open(zip_path, 'rb') as f:
            files = {
                'file': (f"{iflow_name}.zip", f, 'application/zip')
            }
            data = {
                'Id': iflow_name,
                'Name': iflow_name,
                'PackageId': cpi_package
            }
            
            response = self._make_request("POST", url, headers=headers, files=files, data=data)
            
        if response.status_code in [201, 202]:
            return {
                "status": "created",
                "message": f"IFlow {iflow_name} created successfully",
                "action": "create",
                "data": response.json() if response.content else {}
            }
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to upload IFlow artifact: {response.text}"
            )
    
    def upload_or_update_iflow_artifact(self, cpi_package: str, iflow_name: str, zip_path: str) -> dict:
        """Upload or update IFlow artifact - check if exists first"""
        print(f"Ensuring package '{cpi_package}' exists...")
        
        # First ensure the package exists
        package_result = self.create_package_if_not_exists(cpi_package)
        
        print(f"Checking if IFlow '{iflow_name}' exists in package '{cpi_package}'...")
        
        if self.iflow_exists_in_designtime(cpi_package, iflow_name):
            print(f"IFlow '{iflow_name}' exists. Updating existing IFlow...")
            update_result = self.update_iflow_artifact(cpi_package, iflow_name, zip_path)
            # Add package info to the result
            update_result["package_status"] = package_result
            return update_result
        else:
            print(f"IFlow '{iflow_name}' doesn't exist. Creating new IFlow...")
            create_result = self.upload_iflow_artifact(cpi_package, iflow_name, zip_path)
            # Add package info to the result
            create_result["package_status"] = package_result
            return create_result
    
    def deploy_iflow(self, cpi_package: str, iflow_name: str) -> dict:
        """Deploy IFlow to runtime"""
        url = f"{self.base_url}/api/v1/DeployIntegrationDesigntimeArtifact"
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "DataServiceVersion": "2.0"
        }
        
        data = {
            "Id": iflow_name,
            "Version": "active"
        }
        
        response = self._make_request("POST", url, headers=headers, json=data)
        if response.status_code in [200, 202]:
            return {"status": "deployed", "message": f"IFlow {iflow_name} deployed successfully"}
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to deploy IFlow: {response.text}"
            )
    
    def get_deployment_status(self, iflow_name: str) -> dict:
        """Get deployment status of an IFlow"""
        url = f"{self.base_url}/api/v1/IntegrationRuntimeArtifacts(Id='{iflow_name}')"
        headers = {
            "Accept": "application/json"
        }
        
        response = self._make_request("GET", url, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            return {"status": "not_deployed", "message": "IFlow not found in runtime"}

# GitHub Integration Class

class GitHubClient:
    """Client for interacting with GitHub API and Git operations"""
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
            "Content-Type": "application/json"
        }
    
    def create_repository_if_not_exists(self, repo_name: str, description: str = "") -> dict:
        """Create a new GitHub repository if it does not exist"""
        url = f"https://gecgithub01.walmart.com/api/v3/orgs/intech/repos"
        data = {
            "name": repo_name,
            "description": description or f"SAP CPI Package: {repo_name}",
            "private": True,
            "auto_init": True
        }
        response = requests.post(url, headers=self.headers, json=data)
        if response.status_code == 201:
            return response.json()
        elif response.status_code == 422:
            # Repository already exists
            return self.get_repository(repo_name)
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create repository: {response.text}"
            )
    
    def get_repository(self, repo_name: str) -> dict:
        """Get repository information"""
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}"
        response = requests.get(url, headers=self.headers)
        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Repository not found: {repo_name}"
            )
        return response.json()
    
    def branch_exists(self, repo_name: str, branch_name: str) -> bool:
        """Check if a branch exists in the repository"""
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/branches/{branch_name}"
        response = requests.get(url, headers=self.headers)
        return response.status_code == 200
    
    def create_branch(self, repo_name: str, branch_name: str, source_branch: str = "main") -> dict:
        """Create a new branch from source branch"""
        # First get the SHA of the source branch
        source_url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/git/refs/heads/{source_branch}"
        source_response = requests.get(source_url, headers=self.headers)
        
        if source_response.status_code != 200:
            raise HTTPException(
                status_code=source_response.status_code,
                detail=f"Source branch '{source_branch}' not found"
            )
        
        source_sha = source_response.json()["object"]["sha"]
        
        # Create new branch
        create_url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/git/refs"
        data = {
            "ref": f"refs/heads/{branch_name}",
            "sha": source_sha
        }
        
        response = requests.post(create_url, headers=self.headers, json=data)
        if response.status_code == 201:
            print(f"Branch '{branch_name}' created successfully from '{source_branch}'")
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create branch '{branch_name}': {response.text}"
            )
    
    def ensure_branch_exists(self, repo_name: str, branch_name: str, source_branch: str = "main") -> bool:
        """Ensure a branch exists, create it if it doesn't"""
        if self.branch_exists(repo_name, branch_name):
            print(f"Branch '{branch_name}' already exists")
            return False  # Branch already existed
        else:
            print(f"Branch '{branch_name}' doesn't exist, creating from '{source_branch}'")
            self.create_branch(repo_name, branch_name, source_branch)
            return True  # Branch was created
    
    def create_pull_request(self, repo_name: str, title: str, head: str, base: str = "main", body: str = "") -> dict:
        """Create a pull request with validation"""
        # Validate that both head and base branches exist
        if not self.branch_exists(repo_name, head):
            raise HTTPException(
                status_code=400,
                detail=f"Head branch '{head}' does not exist in repository '{repo_name}'"
            )
        
        if not self.branch_exists(repo_name, base):
            raise HTTPException(
                status_code=400,
                detail=f"Base branch '{base}' does not exist in repository '{repo_name}'"
            )
        
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/pulls"
        data = {
            "title": title,
            "head": head,
            "base": base,
            "body": body
        }
        
        print(f"Creating pull request: {head} -> {base}")
        response = requests.post(url, headers=self.headers, json=data)
        if response.status_code == 201:
            print(f"Pull request created successfully: {response.json()['html_url']}")
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create pull request: {response.text}"
            )
    
    def list_webhooks(self, repo_name: str) -> list:
        """List all webhooks for a repository"""
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/hooks"
        response = requests.get(url, headers=self.headers)
        
        if response.status_code == 200:
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to list webhooks: {response.text}"
            )
    
    def webhook_exists(self, repo_name: str, webhook_url: str) -> bool:
        """Check if a webhook with the given URL already exists"""
        try:
            webhooks = self.list_webhooks(repo_name)
            for webhook in webhooks:
                if webhook.get('config', {}).get('url') == webhook_url:
                    return True
            return False
        except:
            return False
    
    def create_webhook(self, repo_name: str, webhook_url: str, events: list = None, branches: list = None) -> dict:
        """Create a webhook for the repository"""
        if events is None:
            events = ["push"]
        
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/hooks"
        
        webhook_config = {
            "url": webhook_url,
            "content_type": "json",
            "insecure_ssl": "0"
        }
        
        # Add secret if available from environment
        webhook_secret = os.getenv('GITHUB_WEBHOOK_SECRET')
        if webhook_secret:
            webhook_config["secret"] = webhook_secret
        
        data = {
            "name": "web",
            "active": True,
            "events": events,
            "config": webhook_config
        }
        
        # If specific branches are specified, we need to handle this through GitHub's branch protection
        # For now, we'll create the webhook and handle branch filtering in our endpoint
        
        response = requests.post(url, headers=self.headers, json=data)
        if response.status_code == 201:
            print(f"Webhook created successfully for repository '{repo_name}'")
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create webhook: {response.text}"
            )
    
    def ensure_webhook_exists(self, repo_name: str, webhook_url: str, target_branches: list = None) -> bool:
        """Ensure webhook exists for specified branches, create if it doesn't"""
        if target_branches is None:
            target_branches = ["test", "main"]
        
        # Check if webhook already exists
        if self.webhook_exists(repo_name, webhook_url):
            print(f"Webhook already exists for repository '{repo_name}' with URL '{webhook_url}'")
            return False  # Webhook already existed
        else:
            print(f"Creating webhook for repository '{repo_name}' with URL '{webhook_url}'")
            self.create_webhook(repo_name, webhook_url, events=["push"])
            return True  # Webhook was created
    
    def setup_webhooks_for_repo(self, repo_name: str, webhook_base_url: str) -> dict:
        """Setup webhooks for test and main branches if they exist"""
        webhook_url = f"{webhook_base_url}/webhook/github"
        results = {
            "webhook_created": False,
            "branches_checked": [],
            "webhook_url": webhook_url
        }
        
        # Check if test and main branches exist and ensure webhook is created
        target_branches = ["test", "main"]
        
        webhook_created = self.ensure_webhook_exists(repo_name, webhook_url, target_branches)
        results["webhook_created"] = webhook_created
        results["message"] = f"Webhook setup completed for branches: {target_branches}"

        
        return results
    
    def clone_and_setup_repo(self, repo_name: str, branch_name: str, work_dir: str) -> str:
        """Clone repository and setup branch, handling existing branches properly"""
        repo_url = f"https://{self.token}@gecgithub01.walmart.com/intech/{repo_name}.git"
        repo_path = os.path.join(work_dir, repo_name)
        
        try:
            print(f"Cloning repository '{repo_name}' to {repo_path}")
            # Clone repository
            subprocess.run(["git", "clone", repo_url, repo_path], check=True, capture_output=True)
            
            # Change to repo directory
            os.chdir(repo_path)
            
            # Configure git user
            subprocess.run(["git", "config", "user.name", "CPI Automation"], check=True)
            subprocess.run(["git", "config", "user.email", "cpi-automation@company.com"], check=True)
            
            # Check if branch exists remotely
            try:
                result = subprocess.run(["git", "ls-remote", "--heads", "origin", branch_name], 
                                      check=True, capture_output=True, text=True)
                branch_exists_remotely = bool(result.stdout.strip())
            except subprocess.CalledProcessError:
                branch_exists_remotely = False
            
            # Create and checkout branch
            if branch_exists_remotely:
                print(f"Branch '{branch_name}' exists remotely. Checking out and pulling latest changes.")
                # Checkout existing remote branch
                subprocess.run(["git", "checkout", "-b", branch_name, f"origin/{branch_name}"], check=True, capture_output=True)
                # Pull latest changes to ensure we're up to date
                subprocess.run(["git", "pull", "origin", branch_name], check=True, capture_output=True)
            else:
                print(f"Creating new branch '{branch_name}'.")
                subprocess.run(["git", "checkout", "-b", branch_name], check=True, capture_output=True)
            
            return repo_path
            
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=500, detail=f"Git operation failed: {e}")
    
    def commit_and_push(self, repo_path: str, branch_name: str, commit_message: str):
        """Commit changes and push to remote, handling existing changes properly"""
        original_dir = os.getcwd()
        try:
            os.chdir(repo_path)
            
            # Check if there are any changes to commit
            result = subprocess.run(["git", "status", "--porcelain"], check=True, capture_output=True, text=True)
            if not result.stdout.strip():
                print("No changes to commit.")
                return
            
            # Add all changes
            subprocess.run(["git", "add", "."], check=True)
            
            # Commit changes
            subprocess.run(["git", "commit", "-m", commit_message], check=True)
            
            # Before pushing, try to pull any remote changes first
            try:
                print(f"Pulling latest changes from remote branch '{branch_name}'")
                subprocess.run(["git", "pull", "origin", branch_name, "--no-edit"], check=True, capture_output=True)
            except subprocess.CalledProcessError as pull_error:
                # If pull fails due to merge conflicts, we need to handle it
                print(f"Pull failed, might be due to conflicts or branch doesn't exist remotely: {pull_error}")
                # Check if branch exists remotely
                try:
                    subprocess.run(["git", "ls-remote", "--heads", "origin", branch_name], check=True, capture_output=True)
                    # Branch exists remotely, but pull failed due to conflicts
                    print("Branch exists remotely but pull failed. Attempting to resolve...")
                    # Reset to avoid conflicts and force push (this overwrites remote)
                    print("WARNING: Force pushing to resolve conflicts. This will overwrite remote changes.")
                    subprocess.run(["git", "push", "origin", branch_name, "--force"], check=True)
                    return
                except subprocess.CalledProcessError:
                    # Branch doesn't exist remotely, normal push should work
                    pass
            
            # Push to remote
            try:
                subprocess.run(["git", "push", "origin", branch_name], check=True)
                print(f"Successfully pushed changes to branch '{branch_name}'")
            except subprocess.CalledProcessError as push_error:
                # If normal push fails, try force push as last resort
                print(f"Normal push failed: {push_error}")
                print("Attempting force push to resolve conflicts...")
                subprocess.run(["git", "push", "origin", branch_name, "--force"], check=True)
                print(f"Force pushed changes to branch '{branch_name}'")
            
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=500, detail=f"Git commit/push failed: {e}")
        finally:
            os.chdir(original_dir)
    
    def download_repository_contents(self, repo_name: str, branch_name: str, download_dir: str) -> str:
        """Download repository contents as ZIP and extract to directory"""
        try:
            # Download repository archive
            url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/zipball/{branch_name}"
            headers = {
                "Authorization": f"token {self.token}",
                "Accept": "application/vnd.github.v3+json"
            }
            
            response = requests.get(url, headers=headers, stream=True)
            response.raise_for_status()
            
            # Save ZIP file
            zip_path = os.path.join(download_dir, f"{repo_name}-{branch_name}.zip")
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Extract ZIP file
            extract_dir = os.path.join(download_dir, f"{repo_name}-extracted")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # GitHub ZIP files are extracted to a subdirectory with format: owner-repo-commitsha
            # Find the actual extracted directory
            extracted_items = os.listdir(extract_dir)
            if extracted_items:
                actual_repo_dir = os.path.join(extract_dir, extracted_items[0])
                return actual_repo_dir
            else:
                raise HTTPException(status_code=500, detail="Failed to extract repository contents")
                
        except requests.RequestException as e:
            raise HTTPException(status_code=500, detail=f"Failed to download repository: {str(e)}")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error processing repository download: {str(e)}")

# Utility Functions

def extract_zip_file(zip_path: str, extract_to: str, iflow_name: str) -> str:
    """Extract ZIP file to specified directory"""
    iflow_dir = os.path.join(extract_to, iflow_name)
    os.makedirs(iflow_dir, exist_ok=True)
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(iflow_dir)
    
    return iflow_dir

def create_metadata_file(repo_path: str, iflow_name: str, metadata: dict):
    """Create metadata file with deployment information"""
    metadata_content = f"""# Deployment Metadata

Package: {metadata['package']}
IFlow: {metadata['iflow']}
Environment: {metadata['environment']}
Downloaded: {metadata['timestamp']}
Source: {metadata['source_url']}

## Deployment History
- {metadata['timestamp']}: Deployed from {metadata['environment']} environment
"""
    
    metadata_path = os.path.join(repo_path, iflow_name, "metadata.txt")
    os.makedirs(os.path.dirname(metadata_path), exist_ok=True)
    
    with open(metadata_path, 'w') as f:
        f.write(metadata_content)

def validate_environment(environment: str) -> bool:
    """Validate if environment is supported"""
    return environment in CPI_TENANTS

def cleanup_temp_directory(temp_dir: str):
    """Clean up temporary directory"""
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

# FastAPI Application

# Initialize FastAPI app
app = FastAPI(
    title="SAP CPI to GitHub Deployment API",
    description="Automated deployment of SAP CPI artifacts to GitHub repositories",
    version="1.0.0"
)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.get("/proxy-config-info")
async def proxy_config_info():
    """Get information about proxy configuration options"""
    return {
        "proxy_configuration": {
            "description": "HTTP Proxy support for CPI OData API calls",
            "configuration_method": "Global configuration in code",
            "global_config": {
                "description": "Set GLOBAL_PROXY_CONFIG in the code to configure proxy for all CPI API calls",
                "location": "GLOBAL_PROXY_CONFIG dictionary at the top of the file",
                "parameters": {
                    "enabled": "Set to True to enable proxy",
                    "proxy_url": "Your proxy server URL (e.g., proxy.company.com:8080)",
                    "proxy_username": "Proxy username (optional, set if authentication required)",
                    "proxy_password": "Proxy password (optional, set if authentication required)",
                    "proxy_type": "Proxy type (http/https)"
                }
            },
            "current_status": {
                "enabled": GLOBAL_PROXY_CONFIG.get("enabled", False),
                "proxy_url": GLOBAL_PROXY_CONFIG.get("proxy_url") if GLOBAL_PROXY_CONFIG.get("enabled") else "Not configured",
                "authentication": "Configured" if GLOBAL_PROXY_CONFIG.get("proxy_username") else "No authentication"
            },
            "fallback_environment_variables": {
                "description": "For webhook deployments, proxy can also be configured via environment variables as fallback",
                "variables": {
                    "CPI_PROXY_URL": "HTTP Proxy URL",
                    "CPI_PROXY_USERNAME": "Proxy Username (optional)",
                    "CPI_PROXY_PASSWORD": "Proxy Password (optional)"
                }
            },
            "configuration_example": {
                "code": """
GLOBAL_PROXY_CONFIG = {
    "enabled": True,
    "proxy_url": "proxy.company.com:8080",
    "proxy_username": "your_username",  # Optional
    "proxy_password": "your_password",  # Optional
    "proxy_type": "http"
}
                """.strip()
            }
        }
    }

@app.post("/gitUpload", response_model=GitUploadResponse)
async def upload_cpi_iFlow_to_github(request: GitUploadRequest):
    """
    Deploy SAP CPI IFlow artifact to GitHub repository
    
    This endpoint:
    1. Downloads IFlow artifact from SAP CPI
    2. Creates/accesses GitHub repository
    3. Creates environment-specific branch
    4. Commits artifact to repository
    5. Creates pull request for review
    """

    print(f"Received request: {request}")
    temp_dir = None
    original_dir = os.getcwd()
    print(f"Original working directory: {original_dir}")
    try:
        # Validate environment
        if not validate_environment(request.cpi_environment):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid environment. Supported: {list(CPI_TENANTS.keys())}"
            )
        
        # Get CPI tenant URL
        cpi_base_url = CPI_TENANTS[request.cpi_environment]
        print(f"Using CPI base URL: {cpi_base_url}")
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        if proxy_config and proxy_config.is_enabled():
            print(f"Global proxy configuration enabled: {GLOBAL_PROXY_CONFIG['proxy_url']}")
        
        # Create temporary working directory
        temp_dir = tempfile.mkdtemp()
        
        # Initialize CPI client with global proxy configuration
        cpi_client = CPIClient(cpi_base_url, request.s_user, request.s_password, proxy_config)
        
        # Step 1: Get IFlow details (validation)
        iflow_details = cpi_client.get_iflow_details(request.cpi_package, request.iflow_name)

        print(f"IFlow Details:", iflow_details)
        
        # Step 2: Download IFlow artifact
        zip_path = cpi_client.download_iflow_artifact(request.cpi_package, request.iflow_name, temp_dir)
        
        print(f"IFlow :", zip_path)

        # Step 3: Initialize GitHub client
        github_client = GitHubClient(request.github_token)

        repo_name = f"{request.cpi_package}-{request.iflow_name}"
        # Step 4: Create or get repository (check existence first)
        repo_info = github_client.create_repository_if_not_exists(
            repo_name,
            f"SAP CPI Package: {request.cpi_package}"
        )

        # Step 5: Clone repository and setup branch
        repo_path = github_client.clone_and_setup_repo(
            repo_name,
            request.cpi_environment,
            temp_dir
        )

        # Step 6: Extract artifact to repository
        extract_zip_file(zip_path, repo_path, request.iflow_name)

        # Step 7: Create metadata file
        metadata = {
            "package": request.cpi_package,
            "iflow": request.iflow_name,
            "environment": request.cpi_environment,
            "timestamp": datetime.now().isoformat(),
            "source_url": cpi_base_url
        }
        create_metadata_file(repo_path, request.iflow_name, metadata)

        # Step 7.1: Create empty kitt.yml file for dev environment
        if request.cpi_environment == "dev":
            kitt_yml_path = os.path.join(repo_path, "kitt.yml")
            try:
                with open(kitt_yml_path, 'w', encoding='utf-8') as f:
                    f.write("")  # Create empty file
                print(f"Created empty kitt.yml file at {kitt_yml_path}")
            except Exception as e:
                print(f"Failed to create kitt.yml file: {e}")

        # Step 8: Commit and push changes
        commit_message = f"Upload {repo_name} from {request.cpi_environment} environment"
        github_client.commit_and_push(repo_path, request.cpi_environment, commit_message)

        # Step 9: Create pull request
        pr_title = f"Deploy {repo_name} from {request.cpi_environment} environment"
        pr_body = f"""## Deployment Details

- **Package**: {request.cpi_package}
- **IFlow**: {request.iflow_name}
- **Environment**: {request.cpi_environment}
- **Source**: {cpi_base_url}
- **Deployed**: {datetime.now().isoformat()}

This pull request contains the latest version of the IFlow artifact from the {request.cpi_environment} environment.
"""
        
        # Determine base branch and ensure it exists
        if request.cpi_environment == "dev":
            pr_base_branch = "test"
            # Ensure test branch exists before creating PR from dev
            print(f"Environment is 'dev', ensuring 'test' branch exists as base for PR")
            github_client.ensure_branch_exists(repo_name, "test", "main")
            # Step 10: Setup webhooks for test and main branches if they exist
            webhook_base_url = os.getenv('WEBHOOK_BASE_URL', 'http://localhost:8000')
            try:
                webhook_results = github_client.setup_webhooks_for_repo(repo_name, webhook_base_url)
                print(f"Webhook setup results: {webhook_results}")
            except Exception as e:
                print(f"Warning: Failed to setup webhooks: {str(e)}")
                # Don't fail the entire deployment if webhook setup fails
        else:
            # Default to main for any other environment
            print(f"Environment is 'test', creating PR to 'main' branch")
            pr_base_branch = "main"
        print(f"Creating pull request from '{request.cpi_environment}' to '{pr_base_branch}'")
        pr_info = github_client.create_pull_request(
            repo_name,
            pr_title,
            request.cpi_environment,
            pr_base_branch,
            pr_body
        )


        return GitUploadResponse(
            status="success",
            message="IFlow uploaded successfully to GitHub",
            repository_url=repo_info["html_url"],
            branch_name=request.cpi_environment,
            pull_request_url=pr_info["html_url"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error during deployment: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")
    
    finally:
        # Cleanup
        if temp_dir:
            cleanup_temp_directory(temp_dir)
        os.chdir(original_dir)

# Additional API Endpoints and Error Handling

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Custom HTTP exception handler"""
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail, "status_code": exc.status_code}
    )

@app.get("/environments")
async def get_supported_environments():
    """Get list of supported CPI environments"""
    return {
        "environments": list(CPI_TENANTS.keys()),
        "tenant_urls": {env: url for env, url in CPI_TENANTS.items()}
    }

class WebhookSetupRequest(BaseModel):
    github_token: str = Field(..., description="GitHub Personal Access Token")
    repo_name: str = Field(..., description="Repository name")
    webhook_base_url: str = Field(default="http://localhost:8000", description="Base URL for webhook endpoint")

@app.post("/setup-webhooks")
async def setup_webhooks_for_repository(request: WebhookSetupRequest):
    """Manually setup webhooks for a repository's test and main branches"""
    try:
        # Initialize GitHub client
        github_client = GitHubClient(request.github_token)
        
        # Setup webhooks for the repository
        webhook_results = github_client.setup_webhooks_for_repo(
            request.repo_name, 
            request.webhook_base_url
        )
        
        return {
            "status": "success",
            "message": "Webhook setup completed",
            "results": webhook_results
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to setup webhooks: {str(e)}"
        )

@app.post("/validate-cpi-connection")
async def validate_cpi_connection(request: CPIConnectionRequest):
    """Validate CPI connection and credentials with detailed diagnostics"""
    try:
        if not validate_environment(request.environment):
            raise HTTPException(status_code=400, detail="Invalid environment")
        
        cpi_base_url = CPI_TENANTS[request.environment]
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        if proxy_config and proxy_config.is_enabled():
            print(f"Global proxy configuration enabled for validation: {GLOBAL_PROXY_CONFIG['proxy_url']}")
        
        cpi_client = CPIClient(cpi_base_url, request.s_user, request.s_password, proxy_config)
        
        # Test connection using the new method with retry logic
        connection_result = cpi_client.test_connection()
        
        if connection_result["status"] == "success":
            return {
                "status": "success", 
                "message": "CPI connection validated successfully",
                "details": connection_result
            }
        else:
            raise HTTPException(
                status_code=connection_result.get("status_code", 500), 
                detail=f"Connection validation failed: {connection_result.get('error', 'Unknown error')}"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Connection validation failed: {str(e)}")

@app.post("/validate-api-compliance")
async def validate_api_compliance(
    environment: str,
    s_user: str,
    s_password: str
):
    """Validate that all CPI OData API calls comply with SAP specifications"""
    try:
        if not validate_environment(environment):
            raise HTTPException(status_code=400, detail="Invalid environment")
        
        cpi_base_url = CPI_TENANTS[environment]
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        cpi_client = CPIClient(cpi_base_url, s_user, s_password, proxy_config)
        
        validation_result = cpi_client.validate_api_endpoints()
        
        return {
            "status": "completed",
            "environment": environment,
            "validation_results": validation_result,
            "api_compliance": "All endpoints follow SAP CPI OData API specifications" if validation_result["all_valid"] else "Some endpoints need attention"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"API compliance validation failed: {str(e)}")

@app.get("/iflows/{environment}")
async def list_iflows(
    environment: str,
    s_user: str,
    s_password: str,
    package_id: Optional[str] = None
):
    """List available IFlows in a CPI environment"""
    try:
        if not validate_environment(environment):
            raise HTTPException(status_code=400, detail="Invalid environment")
        
        cpi_base_url = CPI_TENANTS[environment]
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        cpi_client = CPIClient(cpi_base_url, s_user, s_password, proxy_config)
        
        # Build URL with optional package filter
        if package_id:
            url = f"{cpi_base_url}/api/v1/IntegrationDesigntimeArtifacts?$filter=PackageId eq '{package_id}'"
        else:
            url = f"{cpi_base_url}/api/v1/IntegrationDesigntimeArtifacts"
        
        headers = {
            "Authorization": cpi_client.auth_header,
            "Accept": "application/json"
        }
        
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            iflows = []
            if 'd' in data and 'results' in data['d']:
                for item in data['d']['results']:
                    iflows.append({
                        "id": item.get("Id"),
                        "name": item.get("Name"),
                        "package_id": item.get("PackageId"),
                        "version": item.get("Version"),
                        "type": item.get("Type")
                    })
            return {"iflows": iflows, "count": len(iflows)}
        else:
            raise HTTPException(status_code=response.status_code, detail="Failed to fetch IFlows")
            
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Request failed: {str(e)}")

class TestUploadRequest(BaseModel):
    cpi_environment: str = Field(..., description="CPI Environment (dev/test/prod)")
    cpi_package: str = Field(..., description="SAP CPI Package Name")
    iflow_name: str = Field(..., description="IFlow Name")
    s_user: str = Field(..., description="S-User ID for CPI authentication")
    s_password: str = Field(..., description="Password for CPI authentication")
    github_token: str = Field(..., description="GitHub Personal Access Token")

@app.post("/test-upload-update")
async def test_upload_update_iflow(request: TestUploadRequest):
    """Test endpoint to upload or update IFlow from GitHub to CPI"""
    temp_dir = None
    
    try:
        # Validate environment
        if request.cpi_environment not in CPI_TENANTS:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid environment. Supported: {list(CPI_TENANTS.keys())}"
            )
        
        cpi_base_url = CPI_TENANTS[request.cpi_environment]
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        if proxy_config and proxy_config.is_enabled():
            print(f"Global proxy configuration enabled for test upload: {GLOBAL_PROXY_CONFIG['proxy_url']}")
        
        # Create temporary working directory
        temp_dir = tempfile.mkdtemp()
        
        # Initialize clients
        cpi_client = CPIClient(cpi_base_url, request.s_user, request.s_password, proxy_config)
        github_client = GitHubClient(request.github_token)
        
        # Construct repository name
        repo_name = f"{request.cpi_package}-{request.iflow_name}"
        
        # Clone repository and get the latest code
        repo_path = github_client.clone_and_setup_repo(repo_name, "main", temp_dir)
        
        # Find IFlow directory
        iflow_dir = os.path.join(repo_path, request.iflow_name)
        if not os.path.exists(iflow_dir):
            # Try to find the iflow directory
            for item in os.listdir(repo_path):
                item_path = os.path.join(repo_path, item)
                if os.path.isdir(item_path) and item != '.git':
                    iflow_dir = item_path
                    break
        
        if not os.path.exists(iflow_dir):
            raise HTTPException(status_code=404, detail=f"IFlow directory not found in repository")
        
        # Create ZIP file for upload
        zip_path = os.path.join(temp_dir, f"{request.iflow_name}.zip")
        shutil.make_archive(zip_path[:-4], 'zip', iflow_dir)
        
        # Upload or update in CPI
        upload_result = cpi_client.upload_or_update_iflow_artifact(
            request.cpi_package, request.iflow_name, zip_path
        )
        
        # Deploy the iflow
        deploy_result = cpi_client.deploy_iflow(request.cpi_package, request.iflow_name)
        
        return {
            "status": "success",
            "environment": request.cpi_environment,
            "package": request.cpi_package,
            "iflow": request.iflow_name,
            "upload_result": upload_result,
            "deploy_result": deploy_result,
            "timestamp": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Test upload failed: {str(e)}")
    
    finally:
        # Cleanup
        if temp_dir:
            cleanup_temp_directory(temp_dir)

# Webhook Functions and Endpoints

def verify_webhook_signature(payload_body: bytes, signature_header: str, secret: str) -> bool:
    """Verify GitHub webhook signature"""
    if not signature_header:
        return False
    
    try:
        hash_object = hmac.new(secret.encode('utf-8'), msg=payload_body, digestmod=hashlib.sha256)
        expected_signature = "sha256=" + hash_object.hexdigest()
        return hmac.compare_digest(expected_signature, signature_header)
    except Exception:
        return False

def extract_package_and_iflow_from_repo(repo_name: str, modified_files: list) -> tuple:
    """Extract package and iflow names from repository and modified files"""
    # The package name is typically the repository name
    package_name = repo_name
    
    # Try to find iflow name from modified files
    iflow_name = None
    for file_path in modified_files:
        # Look for META-INF/MANIFEST.MF or other characteristic files
        if 'META-INF/MANIFEST.MF' in file_path:
            # Extract the parent directory name as iflow name
            parts = file_path.split('/')
            if len(parts) >= 2:
                iflow_name = parts[0]  # First directory is usually the iflow name
                break
    
    # If no iflow found in files, try to infer from repo structure
    if not iflow_name:
        # Default to package name or look for common patterns
        iflow_name = package_name
    
    return package_name, iflow_name

def determine_environment_from_branch(branch_name: str) -> str:
    """Determine CPI environment from branch name"""
    if branch_name == "main":
        return "prod"
    elif branch_name == "test":
        return "test"
    elif branch_name == "dev":
        return "dev"
    else:
        return "dev"  # Default to dev for feature branches

async def deploy_to_cpi_from_webhook(repo_name: str, branch_name: str, 
                                   commit_info: dict) -> Dict[str, Any]:
    """Deploy integration flow to CPI based on webhook data - processes entire repository"""
    try:
        # Extract package and iflow information from repository structure
        # Since we're processing the entire repo, we'll determine the structure after cloning
        package_name = None
        iflow_name = None
        
        # Determine target environment
        environment = determine_environment_from_branch(branch_name)
        
        if environment not in CPI_TENANTS:
            raise HTTPException(status_code=400, detail=f"Unsupported environment: {environment}")
        
        cpi_base_url = CPI_TENANTS[environment]
        
        # For webhook deployment, we need to get credentials from environment variables
        # In production, these should be securely stored
        s_user = 'S0025971220'
        s_password = '**********'
        github_token = '*********************************'
        
        # Get proxy configuration: Try global config first, then environment variables
        proxy_config = get_global_proxy_config()
        
        if not proxy_config or not proxy_config.is_enabled():
            # Fallback to environment variables if global config is not enabled
            proxy_url = os.getenv("CPI_PROXY_URL")
            proxy_username = os.getenv("CPI_PROXY_USERNAME")
            proxy_password = os.getenv("CPI_PROXY_PASSWORD")
            
            if proxy_url:
                proxy_config = ProxyConfig(
                    proxy_url=proxy_url,
                    proxy_username=proxy_username,
                    proxy_password=proxy_password
                )
                print(f"Environment variable proxy configuration enabled for webhook: {proxy_url}")
        else:
            print(f"Global proxy configuration enabled for webhook: {GLOBAL_PROXY_CONFIG['proxy_url']}")
        
        if not all([s_user, s_password, github_token]):
            raise HTTPException(
                status_code=500, 
                detail="Missing CPI credentials or GitHub token in environment variables"
            )
        
        # Create temporary directory for cloning
        temp_dir = tempfile.mkdtemp()
        
        try:
            # Initialize clients
            cpi_client = CPIClient(cpi_base_url, s_user, s_password, proxy_config)
            github_client = GitHubClient(github_token)
            
            # Option 1: Clone the repository (maintains git history)
            # Option 2: Download repository contents as ZIP (faster, no git required)
            # Using clone method for now, but download method is available as alternative
            
            try:
                # Try cloning first (preferred method for git operations)
                repo_path = github_client.clone_and_setup_repo(repo_name, branch_name, temp_dir)
                print(f"✅ Repository cloned successfully using Git")
            except Exception as clone_error:
                print(f"⚠️ Git clone failed: {clone_error}")
                print(f"🔄 Attempting to download repository contents as fallback...")
                try:
                    repo_path = github_client.download_repository_contents(repo_name, branch_name, temp_dir)
                    print(f"✅ Repository downloaded successfully as ZIP")
                except Exception as download_error:
                    raise HTTPException(
                        status_code=500, 
                        detail=f"Failed to obtain repository contents. Clone error: {clone_error}. Download error: {download_error}"
                    )
            
            
            # Extract package and iflow names directly from repository name
            # Repository naming convention: package_name-iflow_name
            repo_parts = repo_name.split('-', 1)  # Split on first hyphen only
            if len(repo_parts) < 2:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Repository name '{repo_name}' does not follow the expected format: package_name-iflow_name"
                )
            
            package_name = repo_parts[0]
            iflow_name = repo_parts[1]
            
            print(f"📦 Package Name (from repo): {package_name}")
            print(f"📄 IFlow Name (from repo): {iflow_name}")
                            
            # Create ZIP file for upload
            zip_path = os.path.join(temp_dir, f"{iflow_name}.zip")
            shutil.make_archive(zip_path[:-4], 'zip')
            
            # Upload or update in CPI (check if exists first)
            upload_result = cpi_client.upload_or_update_iflow_artifact(package_name, iflow_name, zip_path)
            
            # Deploy the iflow
            deploy_result = cpi_client.deploy_iflow(package_name, iflow_name)
            
            return {
                "status": "success",
                "environment": environment,
                "package": package_name,
                "iflow": iflow_name,
                "deployment_details": {
                    "upload_result": upload_result,
                    "deploy_result": deploy_result,
                    "commit_id": commit_info.get("id"),
                    "commit_message": commit_info.get("message"),
                    "timestamp": datetime.now().isoformat()
                }
            }
            
        finally:
            # Cleanup temp directory
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

@app.post("/webhook/github", response_model=DeploymentResponse)
async def github_webhook(request: Request, x_github_event: str = Header(None), 
                        x_hub_signature_256: str = Header(None)):
    """
    GitHub webhook endpoint for automatic deployment to CPI
    
    This endpoint:
    1. Validates webhook signature for security
    2. Processes push events to test/main branches
    3. Extracts integration flow from repository
    4. Deploys to appropriate CPI environment
    5. Returns deployment status
    """
    try:

        # Get request body
        body = await request.body()
        
        # Verify webhook signature (comment out for testing)
        # if not verify_webhook_signature(body, x_hub_signature_256, WEBHOOK_SECRET):
        #     raise HTTPException(status_code=401, detail="Invalid webhook signature")
        
        # Parse JSON payload
        try:
            payload = json.loads(body.decode('utf-8'))
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON payload")
        
        # Only process push events
        if x_github_event != "push":
            return JSONResponse(
                status_code=200, 
                content={"status": "ignored", "message": f"Event type '{x_github_event}' not processed"}
            )
        
        # Parse webhook data
        try:
            webhook_data = WebhookPush(**payload)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid webhook payload: {str(e)}")
        
        # Extract branch name from ref (refs/heads/branch-name)
        branch_name = webhook_data.ref.replace("refs/heads/", "")
        
        # Only process pushes to test and main branches
        if branch_name not in ["test", "main"]:
            return JSONResponse(
                status_code=200,
                content={
                    "status": "ignored", 
                    "message": f"Branch '{branch_name}' not configured for automatic deployment"
                }
            )
        
        # Get repository name
        repo_name = webhook_data.repository.name
        
        # Get head commit info
        head_commit = webhook_data.head_commit or {}
        
        print(f"🔄 Processing webhook: {repo_name} -> {branch_name}")
        print(f"� Processing entire repository contents for deployment")
        
        # Deploy to CPI (process entire repository, not just modified files)
        deployment_result = await deploy_to_cpi_from_webhook(
            repo_name, branch_name, head_commit
        )
        
        return DeploymentResponse(**deployment_result)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Webhook processing failed: {str(e)}")

@app.get("/webhook/status")
async def webhook_status():
    """Check webhook endpoint status and configuration"""
    return {
        "status": "active",
        "endpoint": "/webhook/github",
        "supported_events": ["push"],
        "target_branches": ["test", "main"],
        "processing_mode": "entire_repository",
        "description": "Processes entire repository contents on each push, not just modified files",
        "environment_mapping": {
            "main": "prod",
            "test": "test"
        },
        "timestamp": datetime.now().isoformat()
    }

# Server Startup and Testing Functions

def print_startup_info():
    """Print startup information"""
    print("""
    🚀 SAP CPI to GitHub Deployment API
    
    📋 Available Endpoints:
    
    1. POST /gitUpload
       - Deploy CPI IFlow to GitHub
       - Creates repo, branch, and pull request
       - Automatically sets up webhooks for test/main branches
    
    2. GET /health
       - Health check endpoint
    
    3. GET /environments
       - Get supported CPI environments
    
    4. POST /setup-webhooks
       - Manually setup webhooks for existing repositories
       - Creates webhooks for test and main branches
    
    5. POST /validate-cpi-connection
       - Validate CPI credentials and connection
    
    6. GET /iflows/{environment}
       - List available IFlows in environment
    
    7. POST /test-upload-update
       - Test endpoint to upload or update IFlow from GitHub to CPI
       - Checks if IFlow exists and updates/creates accordingly
    
    � Webhook Endpoints:
    
    6. POST /webhook/github
       - GitHub webhook for automatic CPI deployment
       - Triggers on push to test/main branches
       - Automatically deploys to corresponding CPI environment
    
    7. GET /webhook/status
       - Check webhook configuration and status
    
    🔄 CI/CD Flow:
    
    1. Developer pushes IFlow to dev branch → Creates PR to test
    2. PR approved and merged to test → Webhook deploys to CPI test environment
    3. Test validated, PR created test → main → Webhook deploys to CPI prod environment
    
    �🔧 Usage Examples:
    
    # Test deployment (replace with your values)
    curl -X POST "http://localhost:8000/gitUpload" \\
         -H "Content-Type: application/json" \\
         -d '{
           "cpi_package": "MyPackage",
           "iflow_name": "MyIFlow",
           "cpi_environment": "dev",
           "s_user": "S0001234567",
           "s_password": "your-password",
           "github_token": "your-github-token",
           "github_org": "your-org"
         }'
    
    📝 Configuration:
    - Update CPI_TENANTS dictionary with your actual tenant URLs
    - Ensure Git and GitHub CLI are installed
    - Set up proper authentication for GitHub
    
    � Webhook Configuration:
    - Set environment variables for webhook deployment:
      * CPI_DEV_USER, CPI_DEV_PASSWORD (for dev environment)
      * CPI_TEST_USER, CPI_TEST_PASSWORD (for test environment)
      * CPI_PROD_USER, CPI_PROD_PASSWORD (for prod environment)
      * GITHUB_TOKEN (for repository access)
      * GITHUB_WEBHOOK_SECRET (for webhook verification)
    
    - Configure GitHub webhook:
      * URL: http://your-server:8000/webhook/github
      * Events: Push events
      * Secret: Set GITHUB_WEBHOOK_SECRET value
    
    �🔒 Security Notes:
    - Store credentials securely (environment variables, secrets management)
    - Use HTTPS in production
    - Implement proper authentication/authorization
    - Validate and sanitize all inputs
    - Enable webhook signature verification in production
    """)

def get_local_ip_address():
    """Get the local IP address of the machine"""
    try:
        # Create a socket connection to determine the local IP
        # This doesn't actually connect, just determines the route
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # Connect to a remote address (doesn't need to be reachable)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            return local_ip
    except Exception as e:
        print(f"Warning: Could not determine local IP address: {e}")
        # Fallback to localhost
        return "127.0.0.1"
    

# if __name__ == "__main__":

#     cpi_base_url = CPI_TENANTS['dev']
#     print(f"Using CPI base URL: {cpi_base_url}")
    
#     # Initialize CPI client
#     cpi_client = CPIClient(cpi_base_url, 'S0025971220', '*********')
#     exists = cpi_client.package_exists('Absences')
#     print(f"Package 'Absences' exists: {exists}")




if __name__ == "__main__":
    # print_startup_info()
    # print(f"\n🔧 Configuration Status:")
    # print(f"✅ Supported Environments: {list(CPI_TENANTS.keys())}")
    # print("⚠️  Remember to update CPI_TENANTS with your actual tenant URLs!")
    
    # Setup webhook secret environment variable if not already set
    webhook_secret = os.getenv('GITHUB_WEBHOOK_SECRET')
    if not webhook_secret:
        # Generate a random webhook secret if not provided
        webhook_secret = secrets.token_hex(32)
        os.environ['GITHUB_WEBHOOK_SECRET'] = webhook_secret
        print(f"\n🔑 Generated webhook secret: {webhook_secret}")
        print("💡 Set GITHUB_WEBHOOK_SECRET environment variable to use a custom secret")
    else:
        print(f"\n🔑 Using webhook secret from environment variable")
    
    # Setup default webhook base URL if not set
    webhook_base_url = os.getenv('WEBHOOK_BASE_URL')
    if not webhook_base_url:
        # Get the current machine's IP address
        local_ip = get_local_ip_address()
        webhook_base_url = f'http://{local_ip}:8000'
        os.environ['WEBHOOK_BASE_URL'] = webhook_base_url
        print(f"🌐 Auto-detected IP and set webhook base URL: {webhook_base_url}")
        print(f"💡 Set WEBHOOK_BASE_URL environment variable to use a custom URL")
    else:
        print(f"🌐 Using webhook base URL from environment: {webhook_base_url}")
    
    # Get local IP for display purposes
    local_ip = get_local_ip_address()
    
    # print(f"\n🚀 Starting SAP CPI to GitHub Deployment API server...")
    # print(f"📡 Local IP Address: {local_ip}")
    # print(f"🌐 Server accessible at:")
    # print(f"   - Local: http://localhost:8000")
    # print(f"   - Network: http://{local_ip}:8000")
    # print(f"📚 API Documentation: http://{local_ip}:8000/docs")
    # print(f"📋 OpenAPI Schema: http://{local_ip}:8000/openapi.json")
    # print(f"🔗 Webhook URL for GitHub: {webhook_base_url}/webhook/github")
    
    # Start the server
    uvicorn.run(app, host="0.0.0.0", port=8000)
