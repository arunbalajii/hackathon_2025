#!/usr/bin/env python3
"""
SAP CPI to GitHub Deployment API
Converted from Jupyter Notebook

This Python API provides automated deployment of SAP Cloud Platform Integration (CPI) 
artifacts to GitHub repositories.

Features:
1. Download IFlow artifacts from SAP CPI using OData API
2. Create/manage GitHub repositories named after CPI packages
3. Environment-specific branching (dev, test, prod)
4. Automated pull request creation for code review
5. RESTful API built with FastAPI
6. HTTP Proxy support for CPI API calls with authentication

Requirements:
- SAP CPI access with valid S-User credentials
- GitHub personal access token with repo permissions
- Python packages: fastapi, requests, uvicorn, pydantic, python-multipart
- Git CLI and GitHub CLI (gh) installed

Proxy Configuration:
- Supports HTTP/HTTPS proxies with optional authentication
- Can be configured per request or via environment variables for webhooks
- Environment variables: CPI_PROXY_URL, CPI_PROXY_USERNAME, CPI_PROXY_PASSWORD
"""

from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import requests
import base64
import os
import tempfile
import shutil
import json
import subprocess
import socket
import time
import hmac
import hashlib
import uvicorn
import zipfile
import subprocess
import logging
import json
import hmac
import hashlib
import socket
import secrets
import time
import uuid
from datetime import datetime
from typing import Optional, Dict, Any
import uvicorn
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import httpx
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA256
from dataclasses import dataclass
import logging
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor
import uuid

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# Configuration and Data Models

# CPI tenant URLs for different environments
CPI_TENANTS = {
    "dev": "https://l5968-tmn.hci.us2.hana.ondemand.com",
    "test": "https://l5967-tmn.hci.us2.hana.ondemand.com", 
    "prod": "https://your-prod-tenant.hci.eu1.hana.ondemand.com"
}

# Connection configuration for troubleshooting
CONNECTION_CONFIG = {
    "connect_timeout": 60,  # Seconds to wait for connection
    "read_timeout": 1000,    # Seconds to wait for response
    "max_retries": 3,       # Number of retry attempts
    "backoff_factor": 1,    # Wait time multiplier between retries
    "verify_ssl": True,     # Set to False if SSL issues (NOT recommended for production)
    "chunk_size": 8192      # Chunk size for file downloads
}

# Global HTTP Proxy Configuration for CPI API calls
# Set these values to configure proxy for all CPI OData API requests
GLOBAL_PROXY_CONFIG = {
    "enabled": True,  # Set to True to enable proxy
    "proxy_url": "proxy-intlho.wal-mart.com:8080",  # Your proxy server URL
    "proxy_username": "k0j0abt",  # Proxy username (set if authentication required)
    "proxy_password": "StrongestPassw0rd!",  # Proxy password (set if authentication required)
    "proxy_type": "http"     # Proxy type (http/https)
}

LLM_CONFIG = {
    "llm_model": "gpt-4.1-mini",
    "llm_api_version": "2024-10-21",
    "llm_gateway_url": "https://wmtllmgateway.stage.walmart.com/wmtllmgateway/v1/openai",
    "llm_gateway_consumer_id": "0d9e66a3-c1d5-4f58-a84d-13e2817e14aa",
    "llm_gateway_pvt_key_base64":"MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCk1Ws5i6nteyNKQnmNsiMi8xaDNIV5M7UlLuSM5kIcHE53RF6FWJXIIjQQ0ri6DDmaWe30gDT7vcQZh+VmfQpUwkG2b4W5wPXkxP5dXPerT/DVqJF3MfoIoc9pgdG6uJvxxq18PRIqOxLNoF41dEH4qr/GEKSmnpy7QXts6IRUMYWs83fbD9HZ8WcA+WMze5sARG1zus1DgE34bc2JdhQkyLMl/wShyKjhf6PrhF19YMQcLq2m/P/CyoQ2j5B19d1GARqD7C9mrA4W2tQYfXMKAXTDl/ckpnwVWOds71+68zwCRrhco2KCD8/VcJyGRY8VKs0Fk7pIKvcgxRZYdy9xAgMBAAECggEBAIy0wfs1hbD7VHynkiuqzOOgrq8Bvo5f3VoIVYERbY2hfDnDWwxpOjLFP7y8pIPsu59O9Rmp95CNxUAmCWUbiB4iVQXu3TBbz4uhvaDlI2ZRrzwz0Tj2qIGF3xApiWbi//u7pYxQdZknJD3zj3gB7e7fkyT4QBUbgJ84nquxMITNAjhDmFHervcuU7ZvXBa5i6deM1WzeL9G7lvK0TyGVP+cJDmXRVNzsIB4dOlyoU2FNBonYD8DU4ComfDqGwD5f0H/yRwMauiV1Ifakqpljlw+StyzFB75ueNs+qwTh8/ZwDqr3Kki4ZC42wFv5l6oPKbGqEChDXDN/J0uM3qDFaECgYEA16Ct/Rf3p0IQgEneF0p6rA2hMira5PkQOvqvNWUxCug9yeINqSBJd6BI8iDw1ztrENMe9nmb+fK+cq78T794k96TsYe9eNLXC1b5bF6go6wSkadfQKZMLkkfSK3h/GJMYFQtJKk72Q1eNeYXcsw70lUgeqzS76LEmeyzIRj5e9MCgYEAw7IdpbcEr+SVsfD4SaY0bhVVY/mWS7SjoQ303GsucSO3l5EPWCl8id0fddrxMRtO+ttnhvjLI0zvWxrUsKVo0mAS09zuNvBfsfdYhCXRkWGb+VqvLDcyUu+X97xQnoapM19pF7keDV/tCSPB+QINa2lfu4+7fgRYbaA76GU0MSsCgYBNahGtQTKXqR9Vf6+tuv6p0MbjxQELnePW2POYfvkJinHMjk0LQF1ABprJ20u8ake5JaMDKIv4Q89eSzaoxvxaUlnCLhK3UzMDjjlEUADqYjfUdTu8cTf+kiAaLttoij4Tg4UlmWC0P5loTnBytaJwlEFx6aRdhpmBDbsOEfJYIwKBgQCDHSI59h5AztDw0Hc5uQ6ltstoWT+2Z0e+T0CAMZuDGCAYf4sdUWZsY+eBKfixIw/OiROa3bQUaaZwjtBzrc9GLDJRGlPMIU6sSQFYQJJhall7PqPg5vZjlL1nsRb+r1BL6B/cUh3tbhi9J+T9Nb/R+F64prtC2hx5DoM02CGY0wKBgQDUKpnbo+aO88rfZHYLSu+CO7aJZR4vV981KLb+QDLATXOQfs48DRBS7N/cImzUsq6WmxYdQ07NU/yIa7KR/QWNvrE22DtJoAuUc4eyNIIlLTZDoQCqkr3EyyU2p4NsScrgh8LvcpMrWOnl062EndoZX4SB8MYKCV7hvw49I5ewNQ==",
    "llm_gateway_key_version": 1,
    "llm_gateway_env": "stage",
    "llm_gateway_cert_path": "/Users/a0p09kj/VsCode/cpi-cicd/walmart-combined.crt"
}

# Email Configuration for Code Review Reports
EMAIL_CONFIG = {
    "smtp_server": "smtp-gw1.wal-mart.com",  # Walmart's SMTP server
    "smtp_port": 25,  # Standard submission port with STARTTLS
    "sender_email": "kalpit.jain@walmart.com",  # System sender email
    "recipient_email": "Successfactors-CPI-E@walmart.com",  # Target recipient
}

# Proxy configuration class
class ProxyConfig:
    """HTTP Proxy configuration for CPI API calls"""
    def __init__(self, 
                 proxy_url: Optional[str] = None,
                 proxy_username: Optional[str] = None, 
                 proxy_password: Optional[str] = None,
                 proxy_type: str = "http"):
        self.proxy_url = proxy_url
        self.proxy_username = proxy_username
        self.proxy_password = proxy_password
        self.proxy_type = proxy_type.lower()
    
    def get_proxies(self) -> Optional[Dict[str, str]]:
        """Get proxy configuration for requests"""
        if not self.proxy_url:
            return None
        
        # Build proxy URL with authentication if provided
        if self.proxy_username and self.proxy_password:
            # Format: http://username:password@proxy_host:port
            proxy_parts = self.proxy_url.split("://")
            if len(proxy_parts) == 2:
                scheme, host_port = proxy_parts
                proxy_url = f"{scheme}://{self.proxy_username}:{self.proxy_password}@{host_port}"
            else:
                # Assume no scheme provided, default to http
                proxy_url = f"http://{self.proxy_username}:{self.proxy_password}@{self.proxy_url}"
        else:
            proxy_url = self.proxy_url
        
        return {
            "http": proxy_url,
            "https": proxy_url
        }
    
    def is_enabled(self) -> bool:
        """Check if proxy is configured"""
        return bool(self.proxy_url)

def get_global_proxy_config() -> Optional[ProxyConfig]:
    """Get global proxy configuration based on GLOBAL_PROXY_CONFIG settings"""
    if not GLOBAL_PROXY_CONFIG.get("enabled", False):
        return None
    
    return ProxyConfig(
        proxy_url=GLOBAL_PROXY_CONFIG.get("proxy_url"),
        proxy_username=GLOBAL_PROXY_CONFIG.get("proxy_username"),
        proxy_password=GLOBAL_PROXY_CONFIG.get("proxy_password"),
        proxy_type=GLOBAL_PROXY_CONFIG.get("proxy_type", "http")
    )

# Request model for deployment
class GitUploadRequest(BaseModel):
    package_id: str = Field(..., description="SAP CPI Package Name")
    iflow_id: str = Field(..., description="IFlow Name")
    from_environment: str = Field(..., description="Environment (dev/test/prod)")
    #s_user: str = Field(..., description="SAP S-User ID")
    #s_password: str = Field(..., description="SAP S-User Password")
    #github_token: str = Field(..., description="GitHub Personal Access Token")

# Response model
class GitUploadResponse(BaseModel):
    status: str
    message: str
    repository_url: Optional[str] = None
    branch_name: Optional[str] = None
    pull_request_url: Optional[str] = None
    
# Error response model
class ErrorResponse(BaseModel):
    error: str
    details: Optional[str] = None

# CPI Connection validation request model
class CPIConnectionRequest(BaseModel):
    environment: str = Field(..., description="Environment (dev/test/prod)")
    s_user: str = Field(..., description="SAP S-User ID")
    s_password: str = Field(..., description="SAP S-User Password")

class WebhookRepository(BaseModel):
    name: str
    full_name: str
    clone_url: str

class WebhookCommit(BaseModel):
    id: str
    message: str
    timestamp: str
    author: Dict[str, Any]
    modified: list = []
    added: list = []
    removed: list = []

class WebhookPush(BaseModel):
    ref: str
    before: str
    after: str
    repository: WebhookRepository
    commits: list = []
    head_commit: Optional[WebhookCommit] = None

class DeploymentResponse(BaseModel):
    status: str
    message: str
    environment: str
    package: Optional[str] = None
    iflow: Optional[str] = None
    deployment_details: Optional[Dict[str, Any]] = None

# Configuration for webhook secret (should be environment variable in production)
WEBHOOK_SECRET = os.getenv("GITHUB_WEBHOOK_SECRET", "your-webhook-secret-here")

# Async Code Review Models and Infrastructure
class CodeReviewStatus(BaseModel):
    review_id: str
    iflow_id: str
    status: str  # "pending", "in_progress", "completed", "failed"
    output_directory: Optional[str] = None
    error_message: Optional[str] = None
    timestamp: str
    review_files: Optional[Dict[str, str]] = None

# Global storage for code review status (in production, use Redis or database)
code_review_status_store: Dict[str, CodeReviewStatus] = {}

# Thread pool for background code reviews
code_review_executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="code_review")

# SAP CPI Integration Class

class CPIClient:
    """Client for interacting with SAP CPI OData API"""
    
    def __init__(self, base_url: str, username: str, password: str, proxy_config: Optional[ProxyConfig] = None):
        self.base_url = base_url.rstrip('/')
        self.auth_header = self._create_auth_header(username, password)
        self.proxy_config = proxy_config
        self.session = self._create_session_with_retry()
        self._csrf_token = None  # Cache CSRF token for v1 API
        self._workspace_csrf_token = None  # Cache CSRF token for workspace service API
    
    def _create_auth_header(self, username: str, password: str) -> str:
        """Create basic authentication header"""
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        return f"Basic {encoded_credentials}"
    
    def _create_session_with_retry(self) -> requests.Session:
        """Create a requests session with retry strategy"""
        session = requests.Session()
        
        # Configure proxy if provided
        if self.proxy_config and self.proxy_config.is_enabled():
            proxies = self.proxy_config.get_proxies()
            if proxies:
                session.proxies.update(proxies)
                print(f"🌐 Proxy configured: {self.proxy_config.proxy_url}")
        
        # Define retry strategy - updated for newer urllib3 versions
        retry_strategy = Retry(
            total=3,  # Total number of retries
            status_forcelist=[429, 500, 502, 503, 504],  # HTTP status codes to retry
            allowed_methods=["HEAD", "GET", "PUT", "DELETE", "OPTIONS", "TRACE", "POST"],  # Updated parameter name
            backoff_factor=2,  # Increased backoff time between retries
            raise_on_redirect=False,
            raise_on_status=False
        )
        
        # Mount adapter with retry strategy
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,
            pool_maxsize=20
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Configure session to mimic browser behavior
        session.verify = True  # Keep SSL verification enabled
        session.stream = False  # Don't stream by default
        
        return session
    
    def _get_csrf_token(self) -> str:
        """Get CSRF token for POST/PUT operations"""
        if self._csrf_token:
            return self._csrf_token
            
        # Fetch CSRF token using a HEAD request to any endpoint
        url = f"{self.base_url}/api/v1/"
        headers = {
            "Authorization": self.auth_header,
            "X-CSRF-Token": "Fetch",  # Request CSRF token
            "Accept": "application/json"
        }
        
        try:
            print("🔑 Fetching CSRF token...")
            response = self.session.head(url, headers=headers, verify=False, timeout=(30, 60))
            
            if response.status_code in [200, 404]:  # 404 is also acceptable for token fetch
                csrf_token = response.headers.get('X-CSRF-Token')
                if csrf_token:
                    self._csrf_token = csrf_token
                    print(f"✅ CSRF token obtained: {csrf_token[:20]}...")
                    return csrf_token
                else:
                    print("⚠️ No CSRF token in response headers")
                    return None
            else:
                print(f"❌ Failed to fetch CSRF token: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ Error fetching CSRF token: {str(e)}")
            return None
    
    def _refresh_csrf_token(self):
        """Refresh CSRF token (invalidate cache)"""
        self._csrf_token = None
        return self._get_csrf_token()
    
    def _get_csrf_token_workspace(self) -> str:
        """
        Get CSRF token specifically for workspace service API operations
        Based on the workspace service endpoint
        """

        # Use a separate token cache for workspace service
        if hasattr(self, '_workspace_csrf_token') and self._workspace_csrf_token:
            return self._workspace_csrf_token
            
        # Fetch CSRF token using workspace service endpoint
        url = f"{self.base_url}/itspaces/odata/1.0/workspace.svc"
        headers = {
            "Authorization": self.auth_header,
            "X-CSRF-Token": "FETCH",  # Request CSRF token
            "Content-Type": "application/xml",
            "Accept": "application/xml"
        }
        
        try:
            print("🔑 Fetching CSRF token for workspace service...")
            response = self.session.get(url, headers=headers, verify=False, timeout=(30, 60))
            
            if response.status_code in [200, 404]:  # 404 is also acceptable for token fetch
                csrf_token = response.headers.get('X-CSRF-Token')
                if csrf_token and csrf_token != "FETCH":
                    self._workspace_csrf_token = csrf_token
                    print(f"✅ Workspace CSRF token acquired: {csrf_token[:20]}...")
                    return csrf_token
                else:
                    print("⚠️ No CSRF token found in workspace service response headers")
                    print(f"Response headers: {dict(response.headers)}")
                    return None
            else:
                print(f"❌ Failed to fetch workspace CSRF token: {response.status_code}")
                print(f"Response: {response.text}")
                return None
                
        except Exception as e:
            print(f"❌ Error fetching workspace CSRF token: {str(e)}")
            return None
    
    def _refresh_workspace_csrf_token(self):
        """Refresh workspace CSRF token (invalidate cache)"""
        self._workspace_csrf_token = None
        return self._get_csrf_token_workspace()
    
    def _make_request(self, method: str, url: str, headers: dict = None, **kwargs) -> requests.Response:
        """Make HTTP request with error handling and retries"""
        if headers is None:
            headers = {}
        
        # Add headers that mimic Postman/browser requests
        headers = {
            "Authorization": self.auth_header,
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            **headers  # Merge with any provided headers
        }
        
        # Add CSRF token for POST, PUT, DELETE operations
        if method.upper() in ['POST', 'PUT', 'DELETE']:
            # Check if this is a workspace service request
            if '/itspaces/odata/1.0/workspace.svc' in url:
                csrf_token = self._get_csrf_token_workspace()
                if csrf_token:
                    headers["X-CSRF-Token"] = csrf_token
                    print(f"🔑 Added workspace CSRF token to {method} request")
                else:
                    print(f"⚠️ No workspace CSRF token available for {method} request")
            else:
                # Use regular CSRF token for v1 API
                csrf_token = self._get_csrf_token()
                if csrf_token:
                    headers["X-CSRF-Token"] = csrf_token
                    print(f"🔑 Added CSRF token to {method} request")
                else:
                    print(f"⚠️ No CSRF token available for {method} request")

        request_options = {
            "verify": False,  # Verify SSL certificates
            "allow_redirects": True,
            "timeout": (60, 1000),  # (connect_timeout, read_timeout)
        }
        request_options.update(kwargs)
        
        print(f"🔍 Making {method} request to: {url}")
        # Add small delay to avoid overwhelming the server
        time.sleep(0.5)  # 500ms delay between requests
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                **request_options
            )
            
            print(f"📊 Response: {response.status_code} - {response.reason}")
            
            # Check if CSRF token is invalid (typically 403 Forbidden)
            if response.status_code == 403 and method.upper() in ['POST', 'PUT', 'DELETE']:
                print("🔄 CSRF token might be invalid, refreshing...")
                # Check if this is a workspace service request
                if '/itspaces/odata/1.0/workspace.svc' in url:
                    csrf_token = self._refresh_workspace_csrf_token()
                    if csrf_token:
                        headers["X-CSRF-Token"] = csrf_token
                        print("🔄 Retrying workspace request with new CSRF token...")
                        response = self.session.request(
                            method=method,
                            url=url,
                            headers=headers,
                            **request_options
                        )
                        print(f"📊 Workspace Retry Response: {response.status_code} - {response.reason}")
                else:
                    csrf_token = self._refresh_csrf_token()
                    if csrf_token:
                        headers["X-CSRF-Token"] = csrf_token
                        print("🔄 Retrying request with new CSRF token...")
                        response = self.session.request(
                            method=method,
                            url=url,
                            headers=headers,
                            **request_options
                        )
                        print(f"📊 Retry Response: {response.status_code} - {response.reason}")
            
            # Log response headers for debugging
            print(f"📥 Response Headers: {dict(response.headers)}")
            
            return response
            
        except requests.exceptions.ConnectionError as e:
            error_msg = f"Connection error to CPI server: {str(e)}"
            print(f"❌ {error_msg}")
            raise HTTPException(status_code=503, detail=error_msg)
            
        except requests.exceptions.Timeout as e:
            error_msg = f"Request timeout to CPI server: {str(e)}"
            print(f"⏰ {error_msg}")
            raise HTTPException(status_code=504, detail=error_msg)
            
        except requests.exceptions.SSLError as e:
            error_msg = f"SSL error connecting to CPI server: {str(e)}"
            print(f"🔒 {error_msg}")
            raise HTTPException(status_code=495, detail=error_msg)
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Request failed to CPI server: {str(e)}"
            print(f"🚫 {error_msg}")
            raise HTTPException(status_code=500, detail=error_msg)
    
    def get_iflow_details(self, cpi_package: str, iflow_id: str) -> dict:
        """Get IFlow details from CPI"""
        url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')"
        headers = {
            "Accept": "application/json"
        }
        print(f"🔍 Fetching IFlow details from: {url}")
        
        response = self._make_request("GET", url, headers=headers)
        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to get IFlow details: {response.text}"
            )
        print(f"ODATA API Response:", response.content)
        return response.content if response.content else {}
    
    def download_iflow_artifact(self, cpi_package: str, iflow_id: str, download_path: str) -> str:
        """Download IFlow artifact as ZIP file"""
        url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')/$value"
        headers = {
            "Accept": "application/zip"
        }
        
        print(f"🔄 Downloading IFlow artifact from: {url}")
        response = self._make_request("GET", url, headers=headers, stream=True)
        
        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to download IFlow artifact: {response.text}"
            )
        
        # Save the ZIP file
        zip_path = os.path.join(download_path, f"{iflow_id}.zip")
        print(f"💾 Saving ZIP file to: {zip_path}")
        
        try:
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:  # Filter out keep-alive chunks
                        f.write(chunk)
            
            file_size = os.path.getsize(zip_path)
            print(f"✅ Download completed. File size: {file_size} bytes")
            return zip_path
            
        except Exception as e:
            # Clean up partial file if download fails
            if os.path.exists(zip_path):
                os.remove(zip_path)
            raise HTTPException(
                status_code=500,
                detail=f"Failed to save downloaded file: {str(e)}"
            )

    def iflow_exists_in_designtime(self, cpi_package: str, iflow_id: str) -> bool:
        try:
            url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')"
            headers = {
                "Accept": "application/json"
            }
            
            response = self._make_request("GET", url, headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            print(f"Error checking IFlow existence: {str(e)}")
            return False
    
    def get_iflow_info_if_exists(self, cpi_package: str, iflow_id: str) -> dict:
        """Get IFlow information if it exists, return None if not found"""
        try:
            iflow_details = self.get_iflow_details(cpi_package, iflow_id)
            return {
                "exists": True,
                "details": iflow_details
            }
        except HTTPException as e:
            if e.status_code == 404:
                return {
                    "exists": False,
                    "details": None
                }
            else:
                raise e
    
    def package_exists(self, cpi_package: str) -> bool:
        """Check if integration package exists"""
        try:
            print(f"🔍 Checking if package '{cpi_package}' exists...")
            url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')"
            headers = {
                "Accept": "application/json"
            }
            response = self._make_request("GET", url, headers=headers)
            return response.status_code == 200
        except Exception as e:
            print(f"Error checking package existence: {str(e)}")
            return False
    
    def create_package_if_not_exists(self, cpi_package: str, description: str = "") -> dict:
        """Create integration package if it doesn't exist"""
        if self.package_exists(cpi_package):
            print(f"Package '{cpi_package}' exists")
            return {"status": "exists", "message": f"Package {cpi_package} already exists"}
        short_text = "This package contain a sample iFlow to demo the CICD pipeline for SAP CPI"
        self.create_content_package_workspace(technical_name=cpi_package, display_name=cpi_package, short_text=short_text)

        # url = f"{self.base_url}/api/v1/IntegrationPackages"
        # headers = {
        #     "Accept": "application/json",
        #     "Content-Type": "application/json",
        #     "DataServiceVersion": "2.0"
        # }
        
        # data = {
        #     "Id": cpi_package,
        #     "Name": cpi_package,
        #     "Description": description or f"Auto-created package for {cpi_package}",
        #     "ShortText": cpi_package
        # }
        
        # response = self._make_request("POST", url, headers=headers, json=data)
        # if response.status_code in [201, 202]:
        #     print(f"Package '{cpi_package}' created successfully")
        #     return {
        #         "status": "created",
        #         "message": f"Package {cpi_package} created successfully",
        #         "data": response.json() if response.content else {}
        #     }
        # else:
        #     raise HTTPException(
        #         status_code=response.status_code,
        #         detail=f"Failed to create package: {response.text}"
        #     )
    
    def create_content_package_workspace(self, technical_name: str, display_name: str = None, 
                                       short_text: str = None, category: str = "Integration") -> dict:
        """
        Create integration package using workspace service API
        Based on the workspace.svc/ContentPackages endpoint
        """

        # if self.package_exists_workspace(technical_name):

        #     return {"status": "exists", "message": f"Package {technical_name} already exists"}
        
        url = f"{self.base_url}/itspaces/odata/1.0/workspace.svc/ContentPackages"
        headers = {
            "Content-Type": "application/xml",
            "Accept": "application/xml"
        }
        
        # Set default values
        display_name = display_name or technical_name
        short_text = short_text or f"Integration package for {technical_name}"
        
        # Create XML payload based on the cURL example
        xml_payload = f'''<?xml version="1.0" encoding="utf-8"?>
<entry xmlns="http://www.w3.org/2005/Atom"
       xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata"
       xmlns:d="http://schemas.microsoft.com/ado/2007/08/dataservices">
    <content type="application/xml">
        <m:properties>
            <d:TechnicalName>{technical_name}</d:TechnicalName>
            <d:DisplayName>{display_name}</d:DisplayName>
            <d:ShortText>{short_text}</d:ShortText>
            <d:Category>{category}</d:Category>
            <d:SupportedPlatforms>SAP HANA Cloud Integration</d:SupportedPlatforms>
        </m:properties>
    </content>
</entry>'''
        
        print(f"🔄 Creating package '{technical_name}' using workspace service...")
        response = self._make_request("POST", url, headers=headers, data=xml_payload.encode('utf-8'))
        
        if response.status_code in [201, 202]:
            print(f"✅ Package '{technical_name}' created successfully via workspace service")
            return {
                "status": "created",
                "message": f"Package {technical_name} created successfully via workspace service",
                "technical_name": technical_name,
                "display_name": display_name,
                "response_content": response.text if response.content else ""
            }
        else:
            print(f"❌ Failed to create package via workspace service: {response.status_code}")
            print(f"Response: {response.text}")
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create package via workspace service: {response.text}"
            )
    
    def package_exists_workspace(self, technical_name: str) -> bool:
        """Check if integration package exists using workspace service"""
        try:
            print(f"🔍 Checking if package '{technical_name}' exists via workspace service...")
            url = f"{self.base_url}/itspaces/odata/1.0/workspace.svc/ContentPackages('{technical_name}')"
            headers = {
                "Accept": "application/xml"
            }
            response = self._make_request("GET", url, headers=headers)
            exists = response.status_code == 200
            print(f"📋 Package '{technical_name}' exists: {exists}")
            return exists
        except Exception as e:
            print(f"Error checking package existence via workspace service: {str(e)}")
            return False
    
    def update_iflow_artifact(self, cpi_package: str, iflow_id: str, zip_path: str) -> dict:
        """Update existing IFlow artifact in CPI"""
        url = f"{self.base_url}/api/v1/IntegrationPackages(Id='{cpi_package}')/IntegrationDesigntimeArtifacts(Id='{iflow_id}',Version='active')/$value"
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/zip"
        }
        
        # Read the ZIP file content
        with open(zip_path, 'rb') as f:
            zip_content = f.read()
            
        response = self._make_request("PUT", url, headers=headers, data=zip_content)
        
        if response.status_code in [200, 202, 204]:
            return {
                "status": "updated",
                "message": f"IFlow {iflow_id} updated successfully",
                "action": "update"
            }
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to update IFlow artifact: {response.text}"
            )

    def upload_iflow_artifact(self, cpi_package: str, iflow_id: str, zip_path: str) -> dict:
        """Create new IFlow artifact in CPI"""
        url = f"{self.base_url}/api/v1/IntegrationDesigntimeArtifacts"
        # Note: Do not set Content-Type for multipart/form-data - requests will set it automatically with boundary
        headers = {
            "Accept": "application/json"
        }
        
        # Read the ZIP file content
        with open(zip_path, 'rb') as f:
            files = {
                'file': (f"{iflow_id}.zip", f, 'application/zip')
            }
            data = {
                'Id': iflow_id,
                'Name': iflow_id,
                'PackageId': cpi_package
            }
            
            response = self._make_request("POST", url, headers=headers, files=files, data=data)
            
        if response.status_code in [201, 202]:
            return {
                "status": "created",
                "message": f"IFlow {iflow_id} created successfully",
                "action": "create",
                "data": response.json() if response.content else {}
            }
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to upload IFlow artifact: {response.text}"
            )
    
    def upload_or_update_iflow_artifact(self, cpi_package: str, iflow_id: str, zip_path: str) -> dict:
        """Upload or update IFlow artifact - check if exists first"""
        print(f"Ensuring package '{cpi_package}' exists...")
        
        # First ensure the package exists
        package_result = self.create_package_if_not_exists(cpi_package)
        
        print(f"Checking if IFlow '{iflow_id}' exists in package '{cpi_package}'...")
        
        if self.iflow_exists_in_designtime(cpi_package, iflow_id):
            print(f"IFlow '{iflow_id}' exists. Updating existing IFlow...")
            update_result = self.update_iflow_artifact(cpi_package, iflow_id, zip_path)
            # Add package info to the result
            update_result["package_status"] = package_result
            return update_result
        else:
            print(f"IFlow '{iflow_id}' doesn't exist. Creating new IFlow...")
            create_result = self.upload_iflow_artifact(cpi_package, iflow_id, zip_path)
            # Add package info to the result
            create_result["package_status"] = package_result
            return create_result
    
    def deploy_iflow(self, cpi_package: str, iflow_id: str) -> dict:
        """Deploy IFlow to runtime"""
        url = f"{self.base_url}/api/v1/DeployIntegrationDesigntimeArtifact"
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "DataServiceVersion": "2.0"
        }
        
        data = {
            "Id": iflow_id,
            "Version": "active"
        }
        
        response = self._make_request("POST", url, headers=headers, json=data)
        if response.status_code in [200, 202]:
            return {"status": "deployed", "message": f"IFlow {iflow_id} deployed successfully"}
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to deploy IFlow: {response.text}"
            )
    
    def get_deployment_status(self, iflow_id: str) -> dict:
        """Get deployment status of an IFlow"""
        url = f"{self.base_url}/api/v1/IntegrationRuntimeArtifacts(Id='{iflow_id}')"
        headers = {
            "Accept": "application/json"
        }
        
        response = self._make_request("GET", url, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            return {"status": "not_deployed", "message": "IFlow not found in runtime"}

# GitHub Integration Class

class GitHubClient:
    """Client for interacting with GitHub API and Git operations"""
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
            "Content-Type": "application/json"
        }
    
    def create_repository_if_not_exists(self, repo_name: str, description: str = "") -> dict:
        """Create a new GitHub repository if it does not exist"""
        url = f"https://gecgithub01.walmart.com/api/v3/orgs/intech/repos"
        data = {
            "name": repo_name,
            "description": description,
            "private": True,
            "auto_init": True
        }
        response = requests.post(url, headers=self.headers, json=data)
        if response.status_code == 201:
            return response.json()
        elif response.status_code == 422:
            # Repository already exists
            return self.get_repository(repo_name)
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create repository: {response.text}"
            )
    
    def get_repository(self, repo_name: str) -> dict:
        """Get repository information"""
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}"
        response = requests.get(url, headers=self.headers)
        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Repository not found: {repo_name}"
            )
        return response.json()
    
    def branch_exists(self, repo_name: str, branch_name: str) -> bool:
        """Check if a branch exists in the repository"""
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/branches/{branch_name}"
        response = requests.get(url, headers=self.headers)
        return response.status_code == 200
    
    def create_branch(self, repo_name: str, branch_name: str, source_branch: str = "main") -> dict:
        """Create a new branch from source branch"""
        # First get the SHA of the source branch
        source_url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/git/refs/heads/{source_branch}"
        source_response = requests.get(source_url, headers=self.headers)
        
        if source_response.status_code != 200:
            raise HTTPException(
                status_code=source_response.status_code,
                detail=f"Source branch '{source_branch}' not found"
            )
        
        source_sha = source_response.json()["object"]["sha"]
        
        # Create new branch
        create_url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/git/refs"
        data = {
            "ref": f"refs/heads/{branch_name}",
            "sha": source_sha
        }
        
        response = requests.post(create_url, headers=self.headers, json=data)
        if response.status_code == 201:
            print(f"Branch '{branch_name}' created successfully from '{source_branch}'")
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create branch '{branch_name}': {response.text}"
            )
    
    def ensure_branch_exists(self, repo_name: str, branch_name: str, source_branch: str = "main") -> bool:
        """Ensure a branch exists, create it if it doesn't"""
        if self.branch_exists(repo_name, branch_name):
            print(f"Branch '{branch_name}' already exists")
            return False  # Branch already existed
        else:
            print(f"Branch '{branch_name}' doesn't exist, creating from '{source_branch}'")
            self.create_branch(repo_name, branch_name, source_branch)
            return True  # Branch was created
    
    def create_pull_request(self, repo_name: str, title: str, head: str, base: str = "main", body: str = "") -> dict:
        """Create a pull request with validation"""
        # Validate that both head and base branches exist
        if not self.branch_exists(repo_name, head):
            raise HTTPException(
                status_code=400,
                detail=f"Head branch '{head}' does not exist in repository '{repo_name}'"
            )
        
        if not self.branch_exists(repo_name, base):
            raise HTTPException(
                status_code=400,
                detail=f"Base branch '{base}' does not exist in repository '{repo_name}'"
            )
        
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/pulls"
        data = {
            "title": title,
            "head": head,
            "base": base,
            "body": body
        }
        
        print(f"Creating pull request: {head} -> {base}")
        response = requests.post(url, headers=self.headers, json=data)
        if response.status_code == 201:
            print(f"Pull request created successfully: {response.json()['html_url']}")
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create pull request: {response.text}"
            )
    
    def list_webhooks(self, repo_name: str) -> list:
        """List all webhooks for a repository"""
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/hooks"
        response = requests.get(url, headers=self.headers)
        
        if response.status_code == 200:
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to list webhooks: {response.text}"
            )
    
    def webhook_exists(self, repo_name: str, webhook_url: str) -> bool:
        """Check if a webhook with the given URL already exists"""
        try:
            webhooks = self.list_webhooks(repo_name)
            for webhook in webhooks:
                if webhook.get('config', {}).get('url') == webhook_url:
                    return True
            return False
        except:
            return False
    
    def create_webhook(self, repo_name: str, webhook_url: str, events: list = None, branches: list = None) -> dict:
        """Create a webhook for the repository"""
        if events is None:
            events = ["push"]
        
        url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/hooks"
        
        webhook_config = {
            "url": webhook_url,
            "content_type": "json",
            "insecure_ssl": "0"
        }
        
        # Add secret if available from environment
        webhook_secret = os.getenv('GITHUB_WEBHOOK_SECRET')
        if webhook_secret:
            webhook_config["secret"] = webhook_secret
        
        data = {
            "name": "web",
            "active": True,
            "events": events,
            "config": webhook_config
        }
        
        # If specific branches are specified, we need to handle this through GitHub's branch protection
        # For now, we'll create the webhook and handle branch filtering in our endpoint
        
        response = requests.post(url, headers=self.headers, json=data)
        if response.status_code == 201:
            print(f"Webhook created successfully for repository '{repo_name}'")
            return response.json()
        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Failed to create webhook: {response.text}"
            )
    
    def ensure_webhook_exists(self, repo_name: str, webhook_url: str, target_branches: list = None) -> bool:
        """Ensure webhook exists for specified branches, create if it doesn't"""
        if target_branches is None:
            target_branches = ["test", "main"]
        
        # Check if webhook already exists
        if self.webhook_exists(repo_name, webhook_url):
            print(f"Webhook already exists for repository '{repo_name}' with URL '{webhook_url}'")
            return False  # Webhook already existed
        else:
            print(f"Creating webhook for repository '{repo_name}' with URL '{webhook_url}'")
            self.create_webhook(repo_name, webhook_url, events=["push"])
            return True  # Webhook was created
    
    def setup_webhooks_for_repo(self, repo_name: str, webhook_base_url: str) -> dict:
        """Setup webhooks for test and main branches if they exist"""
        webhook_url = f"{webhook_base_url}/webhook/github"
        results = {
            "webhook_created": False,
            "branches_checked": [],
            "webhook_url": webhook_url
        }
        
        # Check if test and main branches exist and ensure webhook is created
        target_branches = ["test", "main"]
        
        webhook_created = self.ensure_webhook_exists(repo_name, webhook_url, target_branches)
        results["webhook_created"] = webhook_created
        results["message"] = f"Webhook setup completed for branches: {target_branches}"

        
        return results
    
    def clone_and_setup_repo(self, repo_name: str, branch_name: str, work_dir: str) -> str:
        """Clone repository and setup branch, handling existing branches properly"""
        repo_url = f"https://{self.token}@gecgithub01.walmart.com/intech/{repo_name}.git"
        repo_path = os.path.join(work_dir, repo_name)
        
        try:
            print(f"Cloning repository '{repo_name}' to {repo_path}")
            # Clone repository
            subprocess.run(["git", "clone", repo_url, repo_path], check=True, capture_output=True)
            
            # Change to repo directory
            os.chdir(repo_path)
            
            # Configure git user
            subprocess.run(["git", "config", "user.name", "CPI Automation"], check=True)
            subprocess.run(["git", "config", "user.email", "cpi-automation@company.com"], check=True)
            
            # Check if branch exists remotely
            try:
                result = subprocess.run(["git", "ls-remote", "--heads", "origin", branch_name], 
                                      check=True, capture_output=True, text=True)
                branch_exists_remotely = bool(result.stdout.strip())
            except subprocess.CalledProcessError:
                branch_exists_remotely = False
            
            # Create and checkout branch
            if branch_exists_remotely:
                print(f"Branch '{branch_name}' exists remotely. Checking out and pulling latest changes.")
                # Checkout existing remote branch
                subprocess.run(["git", "checkout", "-b", branch_name, f"origin/{branch_name}"], check=True, capture_output=True)
                # Pull latest changes to ensure we're up to date
                subprocess.run(["git", "pull", "origin", branch_name], check=True, capture_output=True)
            else:
                print(f"Creating new branch '{branch_name}'.")
                subprocess.run(["git", "checkout", "-b", branch_name], check=True, capture_output=True)
            
            return repo_path
            
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=500, detail=f"Git operation failed: {e}")
    
    def commit_and_push(self, repo_path: str, branch_name: str, commit_message: str):
        """Commit changes and push to remote, handling existing changes properly"""
        original_dir = os.getcwd()
        try:
            os.chdir(repo_path)
            
            # Check if there are any changes to commit
            result = subprocess.run(["git", "status", "--porcelain"], check=True, capture_output=True, text=True)
            if not result.stdout.strip():
                print("No changes to commit.")
                return
            
            # Add all changes
            subprocess.run(["git", "add", "."], check=True)
            
            # Commit changes
            subprocess.run(["git", "commit", "-m", commit_message], check=True)
            
            # Before pushing, try to pull any remote changes first
            try:
                print(f"Pulling latest changes from remote branch '{branch_name}'")
                subprocess.run(["git", "pull", "origin", branch_name, "--no-edit"], check=True, capture_output=True)
            except subprocess.CalledProcessError as pull_error:
                # If pull fails due to merge conflicts, we need to handle it
                print(f"Pull failed, might be due to conflicts or branch doesn't exist remotely: {pull_error}")
                # Check if branch exists remotely
                try:
                    subprocess.run(["git", "ls-remote", "--heads", "origin", branch_name], check=True, capture_output=True)
                    # Branch exists remotely, but pull failed due to conflicts
                    print("Branch exists remotely but pull failed. Attempting to resolve...")
                    # Reset to avoid conflicts and force push (this overwrites remote)
                    print("WARNING: Force pushing to resolve conflicts. This will overwrite remote changes.")
                    subprocess.run(["git", "push", "origin", branch_name, "--force"], check=True)
                    return
                except subprocess.CalledProcessError:
                    # Branch doesn't exist remotely, normal push should work
                    pass
            
            # Push to remote
            try:
                subprocess.run(["git", "push", "origin", branch_name], check=True)
                print(f"Successfully pushed changes to branch '{branch_name}'")
            except subprocess.CalledProcessError as push_error:
                # If normal push fails, try force push as last resort
                print(f"Normal push failed: {push_error}")
                print("Attempting force push to resolve conflicts...")
                subprocess.run(["git", "push", "origin", branch_name, "--force"], check=True)
                print(f"Force pushed changes to branch '{branch_name}'")
            
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=500, detail=f"Git commit/push failed: {e}")
        finally:
            os.chdir(original_dir)
    
    def download_repository_contents(self, repo_name: str, branch_name: str, download_dir: str) -> str:
        """Download repository contents as ZIP and extract to directory"""
        try:
            # Download repository archive
            url = f"https://gecgithub01.walmart.com/api/v3/repos/intech/{repo_name}/zipball/{branch_name}"
            headers = {
                "Authorization": f"token {self.token}",
                "Accept": "application/vnd.github.v3+json"
            }
            
            response = requests.get(url, headers=headers, stream=True)
            response.raise_for_status()
            
            # Save ZIP file
            zip_path = os.path.join(download_dir, f"{repo_name}-{branch_name}.zip")
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Extract ZIP file
            extract_dir = os.path.join(download_dir, f"{repo_name}-extracted")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # GitHub ZIP files are extracted to a subdirectory with format: owner-repo-commitsha
            # Find the actual extracted directory
            extracted_items = os.listdir(extract_dir)
            if extracted_items:
                actual_repo_dir = os.path.join(extract_dir, extracted_items[0])
                return actual_repo_dir
            else:
                raise HTTPException(status_code=500, detail="Failed to extract repository contents")
                
        except requests.RequestException as e:
            raise HTTPException(status_code=500, detail=f"Failed to download repository: {str(e)}")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error processing repository download: {str(e)}")

@dataclass
class LLMConfig:
    
    # LLM Configuration (Walmart Gateway)
    llm_model: str = "gpt-4.1-mini"
    llm_api_version: str = "2024-10-21"
    llm_gateway_url: str = "https://wmtllmgateway.stage.walmart.com/wmtllmgateway/v1/openai"
    llm_gateway_consumer_id: str = "0d9e66a3-c1d5-4f58-a84d-13e2817e14aa"
    llm_gateway_pvt_key_base64: str = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCk1Ws5i6nteyNKQnmNsiMi8xaDNIV5M7UlLuSM5kIcHE53RF6FWJXIIjQQ0ri6DDmaWe30gDT7vcQZh+VmfQpUwkG2b4W5wPXkxP5dXPerT/DVqJF3MfoIoc9pgdG6uJvxxq18PRIqOxLNoF41dEH4qr/GEKSmnpy7QXts6IRUMYWs83fbD9HZ8WcA+WMze5sARG1zus1DgE34bc2JdhQkyLMl/wShyKjhf6PrhF19YMQcLq2m/P/CyoQ2j5B19d1GARqD7C9mrA4W2tQYfXMKAXTDl/ckpnwVWOds71+68zwCRrhco2KCD8/VcJyGRY8VKs0Fk7pIKvcgxRZYdy9xAgMBAAECggEBAIy0wfs1hbD7VHynkiuqzOOgrq8Bvo5f3VoIVYERbY2hfDnDWwxpOjLFP7y8pIPsu59O9Rmp95CNxUAmCWUbiB4iVQXu3TBbz4uhvaDlI2ZRrzwz0Tj2qIGF3xApiWbi//u7pYxQdZknJD3zj3gB7e7fkyT4QBUbgJ84nquxMITNAjhDmFHervcuU7ZvXBa5i6deM1WzeL9G7lvK0TyGVP+cJDmXRVNzsIB4dOlyoU2FNBonYD8DU4ComfDqGwD5f0H/yRwMauiV1Ifakqpljlw+StyzFB75ueNs+qwTh8/ZwDqr3Kki4ZC42wFv5l6oPKbGqEChDXDN/J0uM3qDFaECgYEA16Ct/Rf3p0IQgEneF0p6rA2hMira5PkQOvqvNWUxCug9yeINqSBJd6BI8iDw1ztrENMe9nmb+fK+cq78T794k96TsYe9eNLXC1b5bF6go6wSkadfQKZMLkkfSK3h/GJMYFQtJKk72Q1eNeYXcsw70lUgeqzS76LEmeyzIRj5e9MCgYEAw7IdpbcEr+SVsfD4SaY0bhVVY/mWS7SjoQ303GsucSO3l5EPWCl8id0fddrxMRtO+ttnhvjLI0zvWxrUsKVo0mAS09zuNvBfsfdYhCXRkWGb+VqvLDcyUu+X97xQnoapM19pF7keDV/tCSPB+QINa2lfu4+7fgRYbaA76GU0MSsCgYBNahGtQTKXqR9Vf6+tuv6p0MbjxQELnePW2POYfvkJinHMjk0LQF1ABprJ20u8ake5JaMDKIv4Q89eSzaoxvxaUlnCLhK3UzMDjjlEUADqYjfUdTu8cTf+kiAaLttoij4Tg4UlmWC0P5loTnBytaJwlEFx6aRdhpmBDbsOEfJYIwKBgQCDHSI59h5AztDw0Hc5uQ6ltstoWT+2Z0e+T0CAMZuDGCAYf4sdUWZsY+eBKfixIw/OiROa3bQUaaZwjtBzrc9GLDJRGlPMIU6sSQFYQJJhall7PqPg5vZjlL1nsRb+r1BL6B/cUh3tbhi9J+T9Nb/R+F64prtC2hx5DoM02CGY0wKBgQDUKpnbo+aO88rfZHYLSu+CO7aJZR4vV981KLb+QDLATXOQfs48DRBS7N/cImzUsq6WmxYdQ07NU/yIa7KR/QWNvrE22DtJoAuUc4eyNIIlLTZDoQCqkr3EyyU2p4NsScrgh8LvcpMrWOnl062EndoZX4SB8MYKCV7hvw49I5ewNQ=="
    llm_gateway_key_version: int = 1
    llm_gateway_env: str = "stage"
    llm_gateway_cert_path: str = "/Users/a0p09kj/VsCode/cpi-cicd/walmart-combined.crt"
    
    
# Initialize configuration
config = LLMConfig()

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class LLMManager:
    """LLM manager for querying LLM and response generation"""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        self._client: Optional[httpx.AsyncClient] = None
        
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.disconnect()
    
    async def connect(self) -> None:
        """Initialize HTTP client"""
        if self.config.llm_gateway_cert_path:
            os.environ['SSL_CERT_FILE'] = self.config.llm_gateway_cert_path
            os.environ['REQUESTS_CA_BUNDLE'] = self.config.llm_gateway_cert_path
        
        self._client = httpx.AsyncClient(
            verify=self.config.llm_gateway_cert_path,
            timeout=httpx.Timeout(30.0),
            limits=httpx.Limits(max_keepalive_connections=5, max_connections=10)
        )
    
    async def disconnect(self) -> None:
        """Close HTTP client"""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    def _generate_signature(self) -> Dict[str, str]:
        """Generate Walmart authentication signature"""
        try:
            rsa_pem = base64.b64decode(self.config.llm_gateway_pvt_key_base64)
            timestamp = int(time.time()) * 1000
            data = f"{self.config.llm_gateway_consumer_id}\n{timestamp}\n{self.config.llm_gateway_key_version}\n"
            
            rsa_key = RSA.importKey(rsa_pem)
            signer = PKCS1_v1_5.new(rsa_key)
            digest = SHA256.new()
            digest.update(data.encode("utf-8"))
            signature = signer.sign(digest)
            signature_b64 = base64.b64encode(signature).decode("utf-8")
            
            return {
                "WM_CONSUMER.ID": str(self.config.llm_gateway_consumer_id),
                "WM_SVC.NAME": "WMTLLMGATEWAY",
                "WM_SVC.ENV": self.config.llm_gateway_env,
                "WM_SEC.KEY_VERSION": str(self.config.llm_gateway_key_version),
                "WM_SEC.AUTH_SIGNATURE": signature_b64,
                "WM_CONSUMER.INTIMESTAMP": str(timestamp),
                "Content-Type": "application/json"
            }
        except Exception as e:
            logger.error(f"Failed to generate signature: {e}")
            raise
    
    async def query_llm(self, user_prompt: str, system_message: str) -> str:
        """Query the LLM"""
        try:
            # Ensure client is connected
            if self._client is None:
                await self.connect()
            print(f"Client connected: {self._client is not None}")
            headers = self._generate_signature()
            payload = {
                "model": self.config.llm_model,
                "api-version": self.config.llm_api_version,
                "task": "chat/completions",
                "model-params": {
                    "messages": [
                        {"role": "system", "content": system_message},
                        {"role": "user", "content": user_prompt}
                    ],
                    "temperature": 0.2,
                    "max_tokens": 2000,
                    "seed": 1234567
                }
            }
            
            response = await self._client.post(
                self.config.llm_gateway_url, 
                headers=headers, 
                json=payload
            )
            response.raise_for_status()
            result = response.json()
            
            if "choices" in result and len(result["choices"]) > 0:
                return result["choices"][0]["message"]["content"]
            
            return "I couldn't generate a response for your query."
            
        except Exception as e:
            logger.error(f"LLM query failed: {e}")
            return f"An error occurred: {str(e)}"
    
   

class CPICodeReviewer:
    """
    Comprehensive code reviewer for SAP CPI artifacts using LLM
    Performs automated code review and generates detailed review reports
    """
    
    def __init__(self, llm_manager: LLMManager):
        self.llm_manager = llm_manager
        self.review_criteria = {
            'security': [
                'Hardcoded credentials or sensitive data',
                'Input validation and sanitization',
                'Error message information leakage',
                'Authentication and authorization checks'
            ],
            'performance': [
                'Resource usage optimization',
                'Memory management',
                'Loop efficiency',
                'Database query optimization',
                'Thread safety considerations'
            ],
            'best_practices': [
                'Code structure and organization',
                'Variable naming conventions',
                'Error handling patterns',
                'Documentation and comments',
                'Reusability and modularity'
            ],
            'maintainability': [
                'Code complexity',
                'Dependency management',
                'Configuration management',
                'Testing considerations',
                'Debugging capabilities'
            ]
        }

    async def perform_code_review(self, iflow_id: str, zip_path: str, 
                                         output_dir: str = "code_review") -> Dict[str, Any]:
        """
        Perform comprehensive automated code review of CPI iFlow
        """
        try:
            print(f"🔍 Starting automated code review for : {iflow_id}")
            
            # Create output directory
            os.makedirs(output_dir, exist_ok=True)
            
            # Step 1: Download and extract artifacts
            print("📦 Extracting iFlow artifacts...")
            artifacts = self._extract_artifacts_for_review(zip_path)
            
            # Step 2: Perform individual component reviews
            print("🔍 Reviewing individual components...")
            component_reviews = await self._review_components(artifacts)

            # Step 6: Save review reports
            review_files = await self._save_review_reports(
                {
                    'component_reviews': component_reviews
                },
                iflow_id,
                output_dir
            )
            
            print("✅ Automated code review completed!")
            
            return {
                'iflow_id': iflow_id,
                'component_reviews': component_reviews,
                'review_files': review_files,
                'output_directory': output_dir
            }
            
        except Exception as e:
            print(f"❌ Code review failed: {str(e)}")
            raise
    
    def _extract_artifacts_for_review(self, zip_path: str) -> Dict[str, Any]:
        """Extract artifacts specifically for code review analysis"""
        artifacts = {
            'scripts': [],
            'mappings': [],
            'configurations': {},
            'bpmn_content': None,
            'iflow_content': None,
            'metadata': {}
        }
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                file_list = zip_ref.namelist()
                
                for file_name in file_list:
                    file_content = zip_ref.read(file_name)
                    
                    if file_name.endswith('.iflw'):
                        artifacts['iflow_content'] = file_content.decode('utf-8', errors='ignore')
                    elif file_name.endswith(('.bpmn2', '.bpmn')):
                        artifacts['bpmn_content'] = file_content.decode('utf-8', errors='ignore')
                    elif file_name.endswith(('.groovy', '.js')):
                        artifacts['scripts'].append({
                            'name': file_name,
                            'type': 'groovy' if file_name.endswith('.groovy') else 'javascript',
                            'content': file_content.decode('utf-8', errors='ignore'),
                            'size': len(file_content)
                        })
                    elif file_name.endswith(('.xsl', '.xslt')):
                        artifacts['mappings'].append({
                            'name': file_name,
                            'type': 'xslt',
                            'content': file_content.decode('utf-8', errors='ignore'),
                            'size': len(file_content)
                        })
                    elif file_name.endswith('.properties'):
                        artifacts['configurations'][file_name] = file_content.decode('utf-8', errors='ignore')
            
            return artifacts
            
        except Exception as e:
            print(f"❌ Error extracting artifacts for review: {str(e)}")
            raise
    
    async def _review_components(self, artifacts: Dict[str, Any]) -> Dict[str, Any]:
        """Review individual components (scripts, mappings, etc.)"""
        reviews = {
            'scripts': [],
            'mappings': [],
            'configurations': []
        }
        
        # Review scripts
        for script in artifacts.get('scripts', []):
            print(f"  📜 Reviewing script: {script['name']}")
            script_review = await self._review_script(script)
            reviews['scripts'].append(script_review)
        
        # Review mappings
        for mapping in artifacts.get('mappings', []):
            print(f"  🗺️ Reviewing mapping: {mapping['name']}")
            mapping_review = await self._review_mapping(mapping)
            reviews['mappings'].append(mapping_review)
        
        # Review configurations
        for config_name, config_content in artifacts.get('configurations', {}).items():
            print(f"  ⚙️ Reviewing configuration: {config_name}")
            config_review = await self._review_configuration(config_name, config_content)
            reviews['configurations'].append(config_review)
        
        return reviews
    
    async def _review_script(self, script: Dict[str, Any]) -> Dict[str, Any]:
        """Perform detailed review of a script"""
        
        review_prompt = f"""
        As an expert SAP CPI code reviewer, analyze the following {script['type']} script and provide a comprehensive review:
        
        SCRIPT NAME: {script['name']}
        SCRIPT TYPE: {script['type']}
        SCRIPT SIZE: {script['size']} bytes
        
        SCRIPT CONTENT:
        {script['content']}
        
        Please provide a detailed code review covering:
        
        1. SECURITY ISSUES:
           - Hardcoded credentials or sensitive data
           - Input validation and sanitization
           - SQL injection or script injection vulnerabilities
           - Error handling that might leak information
        
        2. PERFORMANCE CONCERNS:
           - Resource usage efficiency
           - Memory management
           - Loop optimization
           - Database query efficiency
           - Potential performance bottlenecks
        
        3. BEST PRACTICES:
           - Code structure and organization
           - Variable naming conventions
           - Error handling patterns
           - Documentation and comments quality
           - Code reusability
        
        4. MAINTAINABILITY:
           - Code complexity assessment
           - Dependency management
           - Testing considerations
           - Debugging capabilities
        
        5. SAP CPI SPECIFIC:
           - Proper use of CPI APIs
           - Message processing efficiency
           - Adapter usage best practices
           - Integration flow patterns
        
        For each category, provide:
        - Specific issues found (with line references if possible)
        - Severity level (Critical, High, Medium, Low)
        - Recommended fixes or improvements
        - Best practice suggestions
        
        Format the response as a structured review with clear sections and actionable recommendations.
        """
        
        system_message = """You are a senior SAP CPI developer and code reviewer with expertise in:
        - SAP Cloud Platform Integration best practices
        - Groovy and JavaScript optimization
        - Integration security patterns
        - Performance optimization
        - Code quality standards
        
        Provide thorough, actionable code review feedback with specific examples and recommendations."""
        
        review_result = await self.llm_manager.query_llm(review_prompt, system_message)
        
        return {
            'script_name': script['name'],
            'script_type': script['type'],
            'script_size': script['size'],
            'review_content': review_result,
            'timestamp': datetime.now().isoformat()
        }
    
    async def _review_mapping(self, mapping: Dict[str, Any]) -> Dict[str, Any]:
        """Perform detailed review of a data mapping"""
        
        review_prompt = f"""
        As an expert data mapping reviewer, analyze the following {mapping['type']} mapping and provide a comprehensive review:
        
        MAPPING NAME: {mapping['name']}
        MAPPING TYPE: {mapping['type']}
        MAPPING SIZE: {mapping['size']} bytes
        
        MAPPING CONTENT:
        {mapping['content'][:3000]}  # Truncate for review
        
        Please provide a detailed mapping review covering:
        
        1. DATA TRANSFORMATION LOGIC:
           - Correctness of transformation rules
           - Data type handling
           - Null/empty value handling
           - Default value assignments
        
        2. PERFORMANCE CONSIDERATIONS:
           - XPath efficiency (for XSLT)
           - Memory usage for large datasets
           - Processing complexity
           - Optimization opportunities
        
        3. ERROR HANDLING:
           - Exception handling patterns
           - Data validation rules
           - Recovery mechanisms
           - Error message clarity
        
        4. MAINTAINABILITY:
           - Code organization and structure
           - Documentation and comments
           - Reusability of components
           - Complexity assessment
        
        5. BEST PRACTICES:
           - Industry standard patterns
           - SAP CPI mapping conventions
           - Security considerations
           - Testing approach
        
        For each area, provide specific findings with severity levels and improvement recommendations.
        """
        
        system_message = """You are an expert in data transformation and mapping technologies including XSLT, XPath, and SAP CPI mapping patterns. 
        Provide detailed, technical review feedback focused on correctness, performance, and maintainability."""
        
        review_result = await self.llm_manager.query_llm(review_prompt, system_message)
        
        return {
            'mapping_name': mapping['name'],
            'mapping_type': mapping['type'],
            'mapping_size': mapping['size'],
            'review_content': review_result,
            'timestamp': datetime.now().isoformat()
        }
    
    async def _review_configuration(self, config_name: str, config_content: str) -> Dict[str, Any]:
        """Review configuration files"""
        
        review_prompt = f"""
        Review the following configuration file for an SAP CPI integration:
        
        CONFIGURATION FILE: {config_name}
        
        CONTENT:
        {config_content}
        
        Please analyze:
        1. Configuration completeness and correctness
        2. Security implications of configuration values
        3. Performance-related settings
        4. Best practice compliance
        5. Potential configuration issues
        
        Provide specific recommendations for improvements.
        """
        
        system_message = """You are an SAP CPI configuration expert. Review configuration files for security, performance, and best practice compliance."""
        
        review_result = await self.llm_manager.query_llm(review_prompt, system_message)
        
        return {
            'config_name': config_name,
            'review_content': review_result,
            'timestamp': datetime.now().isoformat()
        }
    

    async def _send_consolidated_review_email(self, iflow_id: str, consolidated_file_path: str, 
                                            total_scripts: int, total_mappings: int, total_configs: int) -> bool:
        """Send consolidated code review report via email"""
        try:
            print(f"📧 Preparing to send code review email for {iflow_id}...")
            
            # Create email message
            msg = MIMEMultipart()
            msg['From'] = EMAIL_CONFIG['sender_email']
            msg['To'] = EMAIL_CONFIG['recipient_email']
            msg['Subject'] = f"SAP CPI Code Review Report - {iflow_id} - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            
            # Email body
            email_body = f"""
Dear SuccessFactors CPI Team,

Please find attached the automated code review report for the SAP CPI iFlow: {iflow_id}

Review Summary:
• Scripts Reviewed: {total_scripts}
• Mappings Reviewed: {total_mappings}  
• Configuration Files Reviewed: {total_configs}
• Review Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
• Generated by: CPI CICD Automation System

The attached report contains detailed analysis covering:
- Security vulnerabilities and best practices
- Performance optimization recommendations
- Code quality and maintainability assessment
- SAP CPI specific compliance checks

Please review the findings and implement the recommended improvements before deployment to production.

Best regards,
CPI CICD Automation System

---
This is an automated message generated by the SAP CPI to GitHub Deployment API.
For questions or support, please contact the CPI development team.
"""
            
            msg.attach(MIMEText(email_body, 'plain'))
            
            # Attach the consolidated review file
            if os.path.exists(consolidated_file_path):
                with open(consolidated_file_path, "rb") as attachment:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(attachment.read())
                    encoders.encode_base64(part)
                    
                    filename = os.path.basename(consolidated_file_path)
                    part.add_header(
                        'Content-Disposition',
                        f'attachment; filename= {filename}'
                    )
                    msg.attach(part)
                    print(f"📎 Attached file: {filename}")
            else:
                print(f"⚠️ Warning: Attachment file not found: {consolidated_file_path}")
                return False
            
            print(f"SMTP Server: {EMAIL_CONFIG['smtp_server']}")
            # Send email
            server = smtplib.SMTP(EMAIL_CONFIG['smtp_server'], EMAIL_CONFIG['smtp_port'])

            text = msg.as_string()
            server.sendmail(EMAIL_CONFIG['sender_email'], EMAIL_CONFIG['recipient_email'], text)
            server.quit()
            
            print(f"✅ Code review email sent successfully to {EMAIL_CONFIG['recipient_email']}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to send code review email: {str(e)}")
            return False
    
    
    async def _save_review_reports(self, reviews: Dict, iflow_id: str, output_dir: str) -> Dict[str, str]:
        """Save consolidated review report and send via email"""
        review_files = {}
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        try:

            # Ensure output directory exists
            os.makedirs(output_dir, exist_ok=True)
            print(f"📁 Created output directory: {output_dir}")
            
            # Create consolidated report file
            consolidated_filename = f"{iflow_id}_Consolidated_Code_Review_Report_{timestamp}.txt"
            consolidated_filepath = os.path.join(output_dir, consolidated_filename)
            
            print(f"📝 Creating consolidated code review report: {consolidated_filepath}")
            
            # Counters for summary
            total_scripts = 0
            total_mappings = 0
            total_configs = 0
            
            with open(consolidated_filepath, 'w', encoding='utf-8') as consolidated_file:
                # Write header
                consolidated_file.write("=" * 80 + "\n")
                consolidated_file.write("SAP CPI AUTOMATED CODE REVIEW REPORT - CONSOLIDATED\n")
                consolidated_file.write("=" * 80 + "\n\n")
                
                consolidated_file.write(f"iFlow ID: {iflow_id}\n")
                consolidated_file.write(f"Review Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                consolidated_file.write(f"Generated by: CPI CICD Automation System\n\n")
                
                # Process component reviews
                if reviews.get('component_reviews'):
                    
                    # Write Executive Summary
                    consolidated_file.write("EXECUTIVE SUMMARY\n")
                    consolidated_file.write("-" * 40 + "\n\n")
                    
                    scripts = reviews['component_reviews'].get('scripts', [])
                    mappings = reviews['component_reviews'].get('mappings', [])
                    configs = reviews['component_reviews'].get('configurations', [])
                    
                    total_scripts = len(scripts)
                    total_mappings = len(mappings)
                    total_configs = len(configs)
                    
                    consolidated_file.write(f"• Scripts Reviewed: {total_scripts}\n")
                    consolidated_file.write(f"• Mappings Reviewed: {total_mappings}\n")
                    consolidated_file.write(f"• Configuration Files Reviewed: {total_configs}\n")
                    consolidated_file.write(f"• Total Components: {total_scripts + total_mappings + total_configs}\n\n")
                    
                    consolidated_file.write("REVIEW SCOPE\n")
                    consolidated_file.write("-" * 40 + "\n")
                    consolidated_file.write("This automated review covers:\n")
                    consolidated_file.write("• Security vulnerabilities and best practices\n")
                    consolidated_file.write("• Performance optimization opportunities\n")
                    consolidated_file.write("• Code quality and maintainability\n")
                    consolidated_file.write("• SAP CPI specific compliance checks\n")
                    consolidated_file.write("• Configuration validation\n\n")
                    
                    # Script Reviews Section
                    if scripts:
                        consolidated_file.write("=" * 80 + "\n")
                        consolidated_file.write("SCRIPT REVIEWS\n")
                        consolidated_file.write("=" * 80 + "\n\n")
                        
                        for i, script_review in enumerate(scripts, 1):
                            consolidated_file.write(f"SCRIPT REVIEW #{i}\n")
                            consolidated_file.write("-" * 50 + "\n\n")
                            consolidated_file.write(f"Script Name: {script_review['script_name']}\n")
                            consolidated_file.write(f"Script Type: {script_review['script_type']}\n")
                            consolidated_file.write(f"Script Size: {script_review['script_size']} bytes\n")
                            consolidated_file.write(f"Review Date: {script_review['timestamp']}\n\n")
                            consolidated_file.write("DETAILED ANALYSIS:\n")
                            consolidated_file.write("-" * 30 + "\n\n")
                            consolidated_file.write(script_review['review_content'])
                            consolidated_file.write("\n\n" + "=" * 60 + "\n\n")
                    
                    # Mapping Reviews Section
                    if mappings:
                        consolidated_file.write("=" * 80 + "\n")
                        consolidated_file.write("MAPPING REVIEWS\n")
                        consolidated_file.write("=" * 80 + "\n\n")
                        
                        for i, mapping_review in enumerate(mappings, 1):
                            consolidated_file.write(f"MAPPING REVIEW #{i}\n")
                            consolidated_file.write("-" * 50 + "\n\n")
                            consolidated_file.write(f"Mapping Name: {mapping_review['mapping_name']}\n")
                            consolidated_file.write(f"Mapping Type: {mapping_review['mapping_type']}\n")
                            consolidated_file.write(f"Mapping Size: {mapping_review['mapping_size']} bytes\n")
                            consolidated_file.write(f"Review Date: {mapping_review['timestamp']}\n\n")
                            consolidated_file.write("DETAILED ANALYSIS:\n")
                            consolidated_file.write("-" * 30 + "\n\n")
                            consolidated_file.write(mapping_review['review_content'])
                            consolidated_file.write("\n\n" + "=" * 60 + "\n\n")
                    
                    # Configuration Reviews Section
                    if configs:
                        consolidated_file.write("=" * 80 + "\n")
                        consolidated_file.write("CONFIGURATION REVIEWS\n")
                        consolidated_file.write("=" * 80 + "\n\n")
                        
                        for i, config_review in enumerate(configs, 1):
                            consolidated_file.write(f"CONFIGURATION REVIEW #{i}\n")
                            consolidated_file.write("-" * 50 + "\n\n")
                            consolidated_file.write(f"Configuration File: {config_review['config_name']}\n")
                            consolidated_file.write(f"Review Date: {config_review['timestamp']}\n\n")
                            consolidated_file.write("DETAILED ANALYSIS:\n")
                            consolidated_file.write("-" * 30 + "\n\n")
                            consolidated_file.write(config_review['review_content'])
                            consolidated_file.write("\n\n" + "=" * 60 + "\n\n")
                
                # Write footer
                consolidated_file.write("=" * 80 + "\n")
                consolidated_file.write("END OF CONSOLIDATED CODE REVIEW REPORT\n")
                consolidated_file.write("=" * 80 + "\n\n")
                consolidated_file.write("Generated by: SAP CPI to GitHub Deployment API\n")
                consolidated_file.write(f"Report ID: {iflow_id}_{timestamp}\n")
                consolidated_file.write(f"Generation Time: {datetime.now().isoformat()}\n")
            
            print(f"✅ Consolidated code review report created: {consolidated_filepath}")
            review_files['consolidated_report'] = consolidated_filepath
            
            # Send email with consolidated report
            print(f"📧 Sending consolidated code review report via email...")
            email_sent = await self._send_consolidated_review_email(
                iflow_id, 
                consolidated_filepath, 
                total_scripts, 
                total_mappings, 
                total_configs
            )
            
            if email_sent:
                review_files['email_status'] = 'sent'
                print(f"✅ Code review report emailed successfully!")
            else:
                review_files['email_status'] = 'failed'
                print(f"⚠️ Failed to send email, but report saved locally")
            
            return review_files
            
        except Exception as e:
            print(f"❌ Error creating consolidated review report: {str(e)}")
            print(f"❌ Output directory was: {output_dir}")
            print(f"❌ Current working directory: {os.getcwd()}")
            raise
    

# Utility Functions

def extract_zip_file(zip_path: str, extract_to: str, iflow_id: str) -> str:
    """Extract ZIP file to specified directory"""
    iflow_dir = os.path.join(extract_to, iflow_id)
    os.makedirs(iflow_dir, exist_ok=True)
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(iflow_dir)
    
    return iflow_dir

def create_metadata_file(repo_path: str, iflow_id: str, metadata: dict):
    """Create metadata file with deployment information"""
    metadata_content = f"""# Deployment Metadata

Package: {metadata['package']}
IFlow: {metadata['iflow']}
Environment: {metadata['environment']}
Downloaded: {metadata['timestamp']}
Source: {metadata['source_url']}

## Deployment History
- {metadata['timestamp']}: Deployed from {metadata['environment']} environment
"""
    
    metadata_path = os.path.join(repo_path, iflow_id, "metadata.txt")
    os.makedirs(os.path.dirname(metadata_path), exist_ok=True)
    
    with open(metadata_path, 'w') as f:
        f.write(metadata_content)

def validate_environment(environment: str) -> bool:
    """Validate if environment is supported"""
    return environment in CPI_TENANTS

def create_track_yml_file(repo_path: str):
    """Create track.yml file using content from property file"""
    track_yml_path = os.path.join(repo_path, "track.yml")
    
    # Read content from property file
    property_file_path = os.path.join(os.path.dirname(__file__), "property")
    
    try:
        if os.path.exists(property_file_path):
            with open(property_file_path, 'r', encoding='utf-8') as property_file:
                property_content = property_file.read()
            
            # Write the property content to track.yml
            with open(track_yml_path, 'w', encoding='utf-8') as track_file:
                track_file.write(property_content)
            
            print(f"✅ Created track.yml file with content from property file at {track_yml_path}")
        else:
            # Fallback: create empty file if property file doesn't exist
            with open(track_yml_path, 'w', encoding='utf-8') as track_file:
                track_file.write("")
            print(f"⚠️ Property file not found, created empty track.yml file at {track_yml_path}")
            
    except Exception as e:
        print(f"❌ Failed to create track.yml file: {e}")
        raise

def cleanup_temp_directory(temp_dir: str):
    """Clean up temporary directory"""
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

# Async Code Review Functions

async def perform_async_code_review(review_id: str, iflow_id: str, zip_path: str) -> None:
    """
    Perform code review asynchronously in background
    Updates status store with progress and results
    """
    try:
        # Update status to in_progress
        code_review_status_store[review_id] = CodeReviewStatus(
            review_id=review_id,
            iflow_id=iflow_id,
            status="in_progress",
            timestamp=datetime.now().isoformat()
        )
        
        print(f"🔍 Starting async code review for {iflow_id} (ID: {review_id})")
        
        # Initialize code review components
        llm_config = LLMConfig()
        llm_manager = LLMManager(llm_config)
        reviewer = CPICodeReviewer(llm_manager)
        
        output_dir = f"code_review_{iflow_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Perform the actual code review
        results = await reviewer.perform_code_review(iflow_id, zip_path, output_dir)
        
        # Update status to completed
        code_review_status_store[review_id] = CodeReviewStatus(
            review_id=review_id,
            iflow_id=iflow_id,
            status="completed",
            output_directory=results['output_directory'],
            review_files=results.get('review_files', {}),
            timestamp=datetime.now().isoformat()
        )
        
        print(f"✅ Async code review completed for {iflow_id} (ID: {review_id})")
        print(f"📁 Output Directory: {results['output_directory']}")
        
    except Exception as e:
        error_message = f"Code review failed: {str(e)}"
        print(f"❌ {error_message} (Review ID: {review_id})")
        
        # Update status to failed
        code_review_status_store[review_id] = CodeReviewStatus(
            review_id=review_id,
            iflow_id=iflow_id,
            status="failed",
            error_message=error_message,
            timestamp=datetime.now().isoformat()
        )

def start_background_code_review(review_id: str, iflow_id: str, zip_path: str) -> None:
    """
    Start code review in background thread using asyncio
    """
    def run_async_review():
        # Create new event loop for this thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(perform_async_code_review(review_id, iflow_id, zip_path))
        finally:
            loop.close()
    
    # Submit to thread pool
    code_review_executor.submit(run_async_review)

# FastAPI Application

# Initialize FastAPI app
app = FastAPI(
    title="SAP CPI to GitHub Deployment API",
    description="Automated deployment of SAP CPI artifacts to GitHub repositories",
    version="1.0.0"
)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.get("/proxy-config-info")
async def proxy_config_info():
    """Get information about proxy configuration options"""
    return {
        "proxy_configuration": {
            "description": "HTTP Proxy support for CPI OData API calls",
            "configuration_method": "Global configuration in code",
            "global_config": {
                "description": "Set GLOBAL_PROXY_CONFIG in the code to configure proxy for all CPI API calls",
                "location": "GLOBAL_PROXY_CONFIG dictionary at the top of the file",
                "parameters": {
                    "enabled": "Set to True to enable proxy",
                    "proxy_url": "Your proxy server URL (e.g., proxy.company.com:8080)",
                    "proxy_username": "Proxy username (optional, set if authentication required)",
                    "proxy_password": "Proxy password (optional, set if authentication required)",
                    "proxy_type": "Proxy type (http/https)"
                }
            },
            "current_status": {
                "enabled": GLOBAL_PROXY_CONFIG.get("enabled", False),
                "proxy_url": GLOBAL_PROXY_CONFIG.get("proxy_url") if GLOBAL_PROXY_CONFIG.get("enabled") else "Not configured",
                "authentication": "Configured" if GLOBAL_PROXY_CONFIG.get("proxy_username") else "No authentication"
            },
            "fallback_environment_variables": {
                "description": "For webhook deployments, proxy can also be configured via environment variables as fallback",
                "variables": {
                    "CPI_PROXY_URL": "HTTP Proxy URL",
                    "CPI_PROXY_USERNAME": "Proxy Username (optional)",
                    "CPI_PROXY_PASSWORD": "Proxy Password (optional)"
                }
            },
            "configuration_example": {
                "code": """
GLOBAL_PROXY_CONFIG = {
    "enabled": True,
    "proxy_url": "proxy.company.com:8080",
    "proxy_username": "your_username",  # Optional
    "proxy_password": "your_password",  # Optional
    "proxy_type": "http"
}
                """.strip()
            }
        }
    }

@app.post("/cpi/migrateiFlow", response_model=GitUploadResponse)
async def upload_cpi_iFlow_to_github(request: GitUploadRequest):
    """
    Deploy SAP CPI IFlow artifact to GitHub repository
    
    This endpoint:
    1. Downloads IFlow artifact from SAP CPI
    2. Creates/accesses GitHub repository
    3. Creates environment-specific branchx
    4. Commits artifact to repository
    5. Creates pull request for review
    """

    print(f"Received request: {request}")
    temp_dir = None
    original_dir = os.getcwd()
    print(f"Original working directory: {original_dir}")
    try:
        # Validate environment
        if not validate_environment(request.from_environment):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid environment. Supported: {list(CPI_TENANTS.keys())}"
            )
        
        # Get CPI tenant URL
        cpi_base_url = CPI_TENANTS[request.from_environment]
        print(f"Using CPI base URL: {cpi_base_url}")
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        if proxy_config and proxy_config.is_enabled():
            print(f"Global proxy configuration enabled: {GLOBAL_PROXY_CONFIG['proxy_url']}")
        
        # Create temporary working directory
        temp_dir = tempfile.mkdtemp()

        s_user = 'S0026451687'
        s_password = 'HappyAug2024'
        github_token = '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'
        
        # Initialize CPI client with global proxy configuration
        cpi_client = CPIClient(cpi_base_url, s_user, s_password, proxy_config)
        
        # Step 1: Get IFlow details (validation)
        iflow_details = cpi_client.get_iflow_details(request.package_id, request.iflow_id)

        print(f"IFlow Details:", iflow_details)
        
        # Step 2: Download IFlow artifact
        zip_path = cpi_client.download_iflow_artifact(request.package_id, request.iflow_id, temp_dir)
        
        print(f"IFlow :", zip_path)

        # Step 3: Initialize GitHub client
        github_client = GitHubClient(github_token)

        repo_name = f"{request.package_id}-{request.iflow_id}"
        # Step 4: Create or get repository (check existence first)
        repo_info = github_client.create_repository_if_not_exists(
            repo_name,
            f"SAP CPI Package: {request.package_id}  IFlow: {request.iflow_id}"
        )

        # Step 5: Clone repository and setup branch
        repo_path = github_client.clone_and_setup_repo(
            repo_name,
            request.from_environment,
            temp_dir
        )

        # Step 6: Extract artifact to repository
        extract_zip_file(zip_path, repo_path, request.iflow_id)

        # Step 7: Create metadata file
        metadata = {
            "package": request.package_id,
            "iflow": request.iflow_id,
            "environment": request.from_environment,
            "timestamp": datetime.now().isoformat(),
            "source_url": cpi_base_url
        }
        create_metadata_file(repo_path, request.iflow_id, metadata)

        # Step 7.1: Create track.yml file using content from property file
        create_track_yml_file(repo_path)

        # Step 8: Commit and push changes
        commit_message = f"Upload {repo_name} from {request.from_environment} environment"
        github_client.commit_and_push(repo_path, request.from_environment, commit_message)

        # Step 9: Create pull request
        pr_title = f"Deploy {repo_name} from {request.from_environment} environment"
        pr_body = f"""## Deployment Details

- **Package**: {request.package_id}
- **IFlow**: {request.iflow_id}
- **Environment**: {request.from_environment}
- **Source**: {cpi_base_url}
- **Deployed**: {datetime.now().isoformat()}

This pull request contains the latest version of the IFlow artifact from the {request.from_environment} environment.
"""
        
        # Determine base branch and ensure it exists
        if request.from_environment == "dev":
            pr_base_branch = "test"
            # Ensure test branch exists before creating PR from dev
            print(f"Environment is 'dev', ensuring 'test' branch exists as base for PR")
            github_client.ensure_branch_exists(repo_name, "test", "main")
            # Step 10: Setup webhooks for test and main branches if they exist
            webhook_base_url = os.getenv('WEBHOOK_BASE_URL', 'http://localhost:8000')
            try:
                webhook_results = github_client.setup_webhooks_for_repo(repo_name, webhook_base_url)
                print(f"Webhook setup results: {webhook_results}")
            except Exception as e:
                print(f"Warning: Failed to setup webhooks: {str(e)}")
                # Don't fail the entire deployment if webhook setup fails
        else:
            # Default to main for any other environment
            print(f"Environment is 'test', creating PR to 'main' branch")
            pr_base_branch = "main"
        print(f"Creating pull request from '{request.from_environment}' to '{pr_base_branch}'")
        
        # Generate unique review ID
        review_id = f"review_{request.iflow_id}_{int(time.time())}_{secrets.token_hex(4)}"
        
        # Update PR body to include review ID
        pr_body = f"""## Deployment Details

- **Package**: {request.package_id}
- **IFlow**: {request.iflow_id}
- **Environment**: {request.from_environment}
- **Source**: {cpi_base_url}
- **Deployed**: {datetime.now().isoformat()}
- **Code Review ID**: {review_id}

This pull request contains the latest version of the IFlow artifact from the {request.from_environment} environment.

🔍 **Automated Code Review**: In progress (ID: {review_id})
Check status at: `/code-review/status/{review_id}`
"""
        
        pr_info = github_client.create_pull_request(
            repo_name,
            pr_title,
            request.from_environment,
            pr_base_branch,
            pr_body
        )

        # Step 10: Start ASYNC Code Review Process
        print(f"🚀 Starting asynchronous code review process (ID: {review_id})")
        
        # Initialize status as pending
        code_review_status_store[review_id] = CodeReviewStatus(
            review_id=review_id,
            iflow_id=request.iflow_id,
            status="pending",
            timestamp=datetime.now().isoformat()
        )
        
        # Copy ZIP file to persistent location for background processing
        persistent_zip_dir = "temp_code_reviews"
        os.makedirs(persistent_zip_dir, exist_ok=True)
        persistent_zip_path = os.path.join(persistent_zip_dir, f"{review_id}_{request.iflow_id}.zip")
        print(f'{persistent_zip_path} will be used for background code review')
        shutil.copy2(zip_path, persistent_zip_path)
        print(f"Copied ZIP file to persistent location: {persistent_zip_path}")
        
        # Start background code review (non-blocking)
        start_background_code_review(review_id, request.iflow_id, persistent_zip_path)
        
        print(f"✅ Migration completed successfully! Code review running in background.")

        # Return response immediately without waiting for code review
        return GitUploadResponse(
            status="success",
            message=f"IFlow uploaded successfully to GitHub. Code review started (ID: {review_id})",
            repository_url=repo_info["html_url"],
            branch_name=request.from_environment,
            pull_request_url=pr_info["html_url"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error during deployment: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")
    
    finally:
        # Cleanup
        if temp_dir:
            cleanup_temp_directory(temp_dir)
        os.chdir(original_dir)

# Additional API Endpoints and Error Handling

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Custom HTTP exception handler"""
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail, "status_code": exc.status_code}
    )

@app.get("/environments")
async def get_supported_environments():
    """Get list of supported CPI environments"""
    return {
        "environments": list(CPI_TENANTS.keys()),
        "tenant_urls": {env: url for env, url in CPI_TENANTS.items()}
    }

class WebhookSetupRequest(BaseModel):
    github_token: str = Field(..., description="GitHub Personal Access Token")
    repo_name: str = Field(..., description="Repository name")
    webhook_base_url: str = Field(default="http://localhost:8000", description="Base URL for webhook endpoint")

@app.post("/setup-webhooks")
async def setup_webhooks_for_repository(request: WebhookSetupRequest):
    """Manually setup webhooks for a repository's test and main branches"""
    try:
        # Initialize GitHub client
        github_client = GitHubClient(request.github_token)
        
        # Setup webhooks for the repository
        webhook_results = github_client.setup_webhooks_for_repo(
            request.repo_name, 
            request.webhook_base_url
        )
        
        return {
            "status": "success",
            "message": "Webhook setup completed",
            "results": webhook_results
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to setup webhooks: {str(e)}"
        )

@app.get("/iflows/{environment}")
async def list_iflows(
    environment: str,
    s_user: str,
    s_password: str,
    package_id: Optional[str] = None
):
    """List available IFlows in a CPI environment"""
    try:
        if not validate_environment(environment):
            raise HTTPException(status_code=400, detail="Invalid environment")
        
        cpi_base_url = CPI_TENANTS[environment]
        
        # Get global proxy configuration
        proxy_config = get_global_proxy_config()
        cpi_client = CPIClient(cpi_base_url, s_user, s_password, proxy_config)
        
        # Build URL with optional package filter
        if package_id:
            url = f"{cpi_base_url}/api/v1/IntegrationDesigntimeArtifacts?$filter=PackageId eq '{package_id}'"
        else:
            url = f"{cpi_base_url}/api/v1/IntegrationDesigntimeArtifacts"
        
        headers = {
            "Authorization": cpi_client.auth_header,
            "Accept": "application/json"
        }
        
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            iflows = []
            if 'd' in data and 'results' in data['d']:
                for item in data['d']['results']:
                    iflows.append({
                        "id": item.get("Id"),
                        "name": item.get("Name"),
                        "package_id": item.get("PackageId"),
                        "version": item.get("Version"),
                        "type": item.get("Type")
                    })
            return {"iflows": iflows, "count": len(iflows)}
        else:
            raise HTTPException(status_code=response.status_code, detail="Failed to fetch IFlows")
            
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Request failed: {str(e)}")

# Webhook Functions and Endpoints

def verify_webhook_signature(payload_body: bytes, signature_header: str, secret: str) -> bool:
    """Verify GitHub webhook signature"""
    if not signature_header:
        return False
    
    try:
        hash_object = hmac.new(secret.encode('utf-8'), msg=payload_body, digestmod=hashlib.sha256)
        expected_signature = "sha256=" + hash_object.hexdigest()
        return hmac.compare_digest(expected_signature, signature_header)
    except Exception:
        return False

def extract_package_and_iflow_from_repo(repo_name: str, modified_files: list) -> tuple:
    """Extract package and iflow names from repository and modified files"""
    # The package name is typically the repository name
    package_id = repo_name
    
    # Try to find iflow name from modified files
    iflow_id = None
    for file_path in modified_files:
        # Look for META-INF/MANIFEST.MF or other characteristic files
        if 'META-INF/MANIFEST.MF' in file_path:
            # Extract the parent directory name as iflow name
            parts = file_path.split('/')
            if len(parts) >= 2:
                iflow_id = parts[0]  # First directory is usually the iflow name
                break
    
    # If no iflow found in files, try to infer from repo structure
    if not iflow_id:
        # Default to package name or look for common patterns
        iflow_id = package_id
    
    return package_id, iflow_id

def determine_environment_from_branch(branch_name: str) -> str:
    """Determine CPI environment from branch name"""
    if branch_name == "main":
        return "prod"
    elif branch_name == "test":
        return "test"
    elif branch_name == "dev":
        return "dev"
    else:
        return "dev"  # Default to dev for feature branches

async def deploy_to_cpi_from_webhook(repo_name: str, branch_name: str, 
                                   commit_info: dict) -> Dict[str, Any]:
    """Deploy integration flow to CPI based on webhook data - processes entire repository"""
    try:
        # Extract package and iflow information from repository structure
        # Since we're processing the entire repo, we'll determine the structure after cloning
        package_id = None
        iflow_id = None
        
        # Determine target environment
        environment = determine_environment_from_branch(branch_name)
        
        if environment not in CPI_TENANTS:
            raise HTTPException(status_code=400, detail=f"Unsupported environment: {environment}")
        
        cpi_base_url = CPI_TENANTS[environment]
        
        # For webhook deployment, we need to get credentials from environment variables
        # In production, these should be securely stored
        s_user = 'S0026451687'
        s_password = 'HappyAug2024'
        github_token = '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'
        
        # Get proxy configuration: Try global config first, then environment variables
        proxy_config = get_global_proxy_config()
        
        if not proxy_config or not proxy_config.is_enabled():
            # Fallback to environment variables if global config is not enabled
            proxy_url = os.getenv("CPI_PROXY_URL")
            proxy_username = os.getenv("CPI_PROXY_USERNAME")
            proxy_password = os.getenv("CPI_PROXY_PASSWORD")
            
            if proxy_url:
                proxy_config = ProxyConfig(
                    proxy_url=proxy_url,
                    proxy_username=proxy_username,
                    proxy_password=proxy_password
                )
                print(f"Environment variable proxy configuration enabled for webhook: {proxy_url}")
        else:
            print(f"Global proxy configuration enabled for webhook: {GLOBAL_PROXY_CONFIG['proxy_url']}")
        
        if not all([s_user, s_password, github_token]):
            raise HTTPException(
                status_code=500, 
                detail="Missing CPI credentials or GitHub token in environment variables"
            )
        
        # Create temporary directory for cloning
        temp_dir = tempfile.mkdtemp()
        
        try:
            # Initialize clients
            cpi_client = CPIClient(cpi_base_url, s_user, s_password, proxy_config)
            github_client = GitHubClient(github_token)
            
            # Option 1: Clone the repository (maintains git history)
            # Option 2: Download repository contents as ZIP (faster, no git required)
            # Using clone method for now, but download method is available as alternative
            
            try:
                # Try cloning first (preferred method for git operations)
                repo_path = github_client.clone_and_setup_repo(repo_name, branch_name, temp_dir)
                print(f"✅ Repository cloned successfully using Git")
            except Exception as clone_error:
                print(f"⚠️ Git clone failed: {clone_error}")
                print(f"🔄 Attempting to download repository contents as fallback...")
                try:
                    repo_path = github_client.download_repository_contents(repo_name, branch_name, temp_dir)
                    print(f"✅ Repository downloaded successfully as ZIP")
                except Exception as download_error:
                    raise HTTPException(
                        status_code=500, 
                        detail=f"Failed to obtain repository contents. Clone error: {clone_error}. Download error: {download_error}"
                    )
            
            
            # Extract package and iflow names directly from repository name
            # Repository naming convention: package_id-iflow_id
            repo_parts = repo_name.split('-', 1)  # Split on first hyphen only
            if len(repo_parts) < 2:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Repository name '{repo_name}' does not follow the expected format: package_id-iflow_id"
                )
            
            package_id = repo_parts[0]
            iflow_id = repo_parts[1]
            
            print(f"📦 Package Name (from repo): {package_id}")
            print(f"📄 IFlow Name (from repo): {iflow_id}")
                            
            # Create ZIP file for upload
            zip_path = os.path.join(temp_dir, f"{iflow_id}.zip")
            shutil.make_archive(zip_path[:-4], 'zip')
            
            # Upload or update in CPI (check if exists first)
            upload_result = cpi_client.upload_or_update_iflow_artifact(package_id, iflow_id, zip_path)
            
            # Deploy the iflow
            deploy_result = cpi_client.deploy_iflow(package_id, iflow_id)
            
            return {
                "status": "success",
                "environment": environment,
                "package": package_id,
                "iflow": iflow_id,
                "deployment_details": {
                    "upload_result": upload_result,
                    "deploy_result": deploy_result,
                    "commit_id": commit_info.get("id"),
                    "commit_message": commit_info.get("message"),
                    "timestamp": datetime.now().isoformat()
                }
            }
            
        finally:
            # Cleanup temp directory
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

@app.post("/webhook/github", response_model=DeploymentResponse)
async def github_webhook(request: Request, x_github_event: str = Header(None), 
                        x_hub_signature_256: str = Header(None)):
    """
    GitHub webhook endpoint for automatic deployment to CPI
    
    This endpoint:
    1. Validates webhook signature for security
    2. Processes push events to test/main branches
    3. Extracts integration flow from repository
    4. Deploys to appropriate CPI environment
    5. Returns deployment status
    """
    try:

        # Get request body
        body = await request.body()
        
        # Verify webhook signature (comment out for testing)
        # if not verify_webhook_signature(body, x_hub_signature_256, WEBHOOK_SECRET):
        #     raise HTTPException(status_code=401, detail="Invalid webhook signature")
        
        # Parse JSON payload
        try:
            payload = json.loads(body.decode('utf-8'))
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON payload")
        
        # Only process push events
        if x_github_event != "push":
            return JSONResponse(
                status_code=200, 
                content={"status": "ignored", "message": f"Event type '{x_github_event}' not processed"}
            )
        
        # Parse webhook data
        try:
            webhook_data = WebhookPush(**payload)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid webhook payload: {str(e)}")
        
        # Extract branch name from ref (refs/heads/branch-name)
        branch_name = webhook_data.ref.replace("refs/heads/", "")
        
        # Only process pushes to test and main branches
        if branch_name not in ["test", "main"]:
            return JSONResponse(
                status_code=200,
                content={
                    "status": "ignored", 
                    "message": f"Branch '{branch_name}' not configured for automatic deployment"
                }
            )
        
        # Get repository name
        repo_name = webhook_data.repository.name
        
        # Get head commit info
        head_commit = webhook_data.head_commit or {}
        
        print(f"🔄 Processing webhook: {repo_name} -> {branch_name}")
        print(f"� Processing entire repository contents for deployment")
        
        # Deploy to CPI (process entire repository, not just modified files)
        deployment_result = await deploy_to_cpi_from_webhook(
            repo_name, branch_name, head_commit
        )
        
        return DeploymentResponse(**deployment_result)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Webhook processing failed: {str(e)}")

@app.get("/webhook/status")
async def webhook_status():
    """Check webhook endpoint status and configuration"""
    return {
        "status": "active",
        "endpoint": "/webhook/github",
        "supported_events": ["push"],
        "target_branches": ["test", "main"],
        "processing_mode": "entire_repository",
        "description": "Processes entire repository contents on each push, not just modified files",
        "environment_mapping": {
            "main": "prod",
            "test": "test"
        },
        "timestamp": datetime.now().isoformat()
    }

# Code Review Status Endpoints

@app.get("/code-review/status/{review_id}")
async def get_code_review_status(review_id: str):
    """Get the status of an asynchronous code review"""
    if review_id not in code_review_status_store:
        raise HTTPException(status_code=404, detail="Code review not found")
    
    status = code_review_status_store[review_id]
    return {
        "review_id": status.review_id,
        "iflow_id": status.iflow_id,
        "status": status.status,
        "timestamp": status.timestamp,
        "message": status.message,
        "output_directory": status.output_directory,
        "error": status.error
    }

@app.get("/code-review/list")
async def list_code_reviews():
    """List all code reviews with their current status"""
    return {
        "reviews": [
            {
                "review_id": status.review_id,
                "iflow_id": status.iflow_id,
                "status": status.status,
                "timestamp": status.timestamp,
                "message": status.message
            }
            for status in code_review_status_store.values()
        ],
        "total_count": len(code_review_status_store)
    }

@app.delete("/code-review/cleanup/{review_id}")
async def cleanup_code_review(review_id: str):
    """Clean up code review artifacts and remove from status store"""
    if review_id not in code_review_status_store:
        raise HTTPException(status_code=404, detail="Code review not found")
    
    status = code_review_status_store[review_id]
    
    # Clean up files
    cleaned_files = []
    
    # Remove persistent ZIP file
    persistent_zip_path = f"temp_code_reviews/{review_id}_{status.iflow_id}.zip"
    if os.path.exists(persistent_zip_path):
        os.remove(persistent_zip_path)
        cleaned_files.append(persistent_zip_path)
    
    # Remove output directory if it exists
    if status.output_directory and os.path.exists(status.output_directory):
        shutil.rmtree(status.output_directory)
        cleaned_files.append(status.output_directory)
    
    # Remove from status store
    del code_review_status_store[review_id]
    
    return {
        "message": f"Code review {review_id} cleaned up successfully",
        "cleaned_files": cleaned_files
    }

# Server Startup and Testing Functions

def print_startup_info():
    """Print startup information"""
    print("""
    🚀 SAP CPI to GitHub Deployment API
    
    📋 Available Endpoints:
    
    1. POST /gitUpload
       - Deploy CPI IFlow to GitHub
       - Creates repo, branch, and pull request
       - Automatically sets up webhooks for test/main branches
    
    2. GET /health
       - Health check endpoint
    
    3. GET /environments
       - Get supported CPI environments
    
    4. POST /setup-webhooks
       - Manually setup webhooks for existing repositories
       - Creates webhooks for test and main branches
    
    5. POST /validate-cpi-connection
       - Validate CPI credentials and connection
    
    6. GET /iflows/{environment}
       - List available IFlows in environment
    
    7. POST /test-upload-update
       - Test endpoint to upload or update IFlow from GitHub to CPI
       - Checks if IFlow exists and updates/creates accordingly
    
    � Webhook Endpoints:
    
    6. POST /webhook/github
       - GitHub webhook for automatic CPI deployment
       - Triggers on push to test/main branches
       - Automatically deploys to corresponding CPI environment
    
    7. GET /webhook/status
       - Check webhook configuration and status
    
    🔄 CI/CD Flow:
    
    1. Developer pushes IFlow to dev branch → Creates PR to test
    2. PR approved and merged to test → Webhook deploys to CPI test environment
    3. Test validated, PR created test → main → Webhook deploys to CPI prod environment
    
    �🔧 Usage Examples:
    
    # Test deployment (replace with your values)
    curl -X POST "http://localhost:8000/gitUpload" \\
         -H "Content-Type: application/json" \\
         -d '{
           "cpi_package": "MyPackage",
           "iflow_id": "MyIFlow",
           "cpi_environment": "dev",
           "s_user": "S0001234567",
           "s_password": "your-password",
           "github_token": "your-github-token",
           "github_org": "your-org"
         }'
    
    📝 Configuration:
    - Update CPI_TENANTS dictionary with your actual tenant URLs
    - Ensure Git and GitHub CLI are installed
    - Set up proper authentication for GitHub
    
    � Webhook Configuration:
    - Set environment variables for webhook deployment:
      * CPI_DEV_USER, CPI_DEV_PASSWORD (for dev environment)
      * CPI_TEST_USER, CPI_TEST_PASSWORD (for test environment)
      * CPI_PROD_USER, CPI_PROD_PASSWORD (for prod environment)
      * GITHUB_TOKEN (for repository access)
      * GITHUB_WEBHOOK_SECRET (for webhook verification)
    
    - Configure GitHub webhook:
      * URL: http://your-server:8000/webhook/github
      * Events: Push events
      * Secret: Set GITHUB_WEBHOOK_SECRET value
    
    �🔒 Security Notes:
    - Store credentials securely (environment variables, secrets management)
    - Use HTTPS in production
    - Implement proper authentication/authorization
    - Validate and sanitize all inputs
    - Enable webhook signature verification in production
    """)

def get_local_ip_address():
    """Get the local IP address of the machine"""
    try:
        # Create a socket connection to determine the local IP
        # This doesn't actually connect, just determines the route
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # Connect to a remote address (doesn't need to be reachable)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            return local_ip
    except Exception as e:
        print(f"Warning: Could not determine local IP address: {e}")
        # Fallback to localhost
        return "127.0.0.1"
    

# if __name__ == "__main__":

#     cpi_base_url = CPI_TENANTS['dev']
#     print(f"Using CPI base URL: {cpi_base_url}")
    
#     # Initialize CPI client
#     cpi_client = CPIClient(cpi_base_url, 'S0025971220', '')
#     exists = cpi_client.package_exists('Absences')
#     print(f"Package 'Absences' exists: {exists}")

if __name__ == "__main__":
    # print_startup_info()
    # print(f"\n🔧 Configuration Status:")
    # print(f"✅ Supported Environments: {list(CPI_T    # Setup webhook secret environment variable if not already set
    webhook_secret = os.getenv('GITHUB_WEBHOOK_SECRET')
    if not webhook_secret:
        # Generate a random webhook secret if not provided
        webhook_secret = secrets.token_hex(32)
        os.environ['GITHUB_WEBHOOK_SECRET'] = webhook_secret
        print(f"\n🔑 Generated webhook secret: {webhook_secret}")
        print("💡 Set GITHUB_WEBHOOK_SECRET environment variable to use a custom secret")
    else:
        print(f"\n🔑 Using webhook secret from environment variable")
    
    # Setup default webhook base URL if not set
    webhook_base_url = os.getenv('WEBHOOK_BASE_URL')
    if not webhook_base_url:
        # Get the current machine's IP address
        local_ip = get_local_ip_address()
        webhook_base_url = f'http://{local_ip}:8000'
        os.environ['WEBHOOK_BASE_URL'] = webhook_base_url
        print(f"🌐 Auto-detected IP and set webhook base URL: {webhook_base_url}")
        print(f"💡 Set WEBHOOK_BASE_URL environment variable to use a custom URL")
    else:
        print(f"🌐 Using webhook base URL from environment: {webhook_base_url}")
    
    # Get local IP for display purposes
    local_ip = get_local_ip_address()
    
    # print(f"\n🚀 Starting SAP CPI to GitHub Deployment API server...")
    # print(f"📡 Local IP Address: {local_ip}")
    # print(f"🌐 Server accessible at:")
    # print(f"   - Local: http://localhost:8000")
    # print(f"   - Network: http://{local_ip}:8000")
    # print(f"📚 API Documentation: http://{local_ip}:8000/docs")
    # print(f"📋 OpenAPI Schema: http://{local_ip}:8000/openapi.json")
    # print(f"🔗 Webhook URL for GitHub: {webhook_base_url}/webhook/github")
    
    # Start the server
    uvicorn.run(app, host="0.0.0.0", port=8000)