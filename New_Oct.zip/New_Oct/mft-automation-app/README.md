# mft-automation-app

Add below VM args with auth.yml file with process credentials:

`-Dspring.config.additional-location=file:/Users/c0u00b1/secrets/auth.yml`

Pre-requisites for the mft-server

Install cron job in all the servers to get the available agents.
Cron job to be added for **ibmusr** 

`*/5 * * * * nohup  /<path to script>/get-available-agent.sh [region] &`

Place below scripts in the MFT servers. (For now its placed in /tmp location to be changed later) 

`ftf-stage-1.sh`

`verifyMonitor.sh`
