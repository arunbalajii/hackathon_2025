package com.walmart.intech.mft.automation.app.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.commons.exceptions.MFTException;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.RegionClusters.Cluster;
import com.walmart.intech.mft.automation.commons.notification.NotificationInvoker;
import com.walmart.intech.mft.automation.commons.notification.NotificationUtils;
import com.walmart.intech.mft.automation.commons.notification.models.Notification;
import com.walmart.intech.mft.automation.commons.services.ScpUploader;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MftUtil {

	@Autowired
	private NotificationInvoker notificationUtility;
	@Autowired
	private NotificationUtils notificationUtils;

	public void logAndAlert(List<String> errorServers, List<String> successServers, List<Cluster> clusters,
			CommandBody mftRequest) throws MFTException {
		if (errorServers.isEmpty()) {
			log.info("{} - Successfully created monitors on all clusters : {}", mftRequest.getRitmNumber(),
					successServers);

			// alert status of xml/monitor creation
			alert(mftRequest, String.format("%s has been created on all the servers - %s at - %s",
					environmentMessage(mftRequest), successServers, ScpUploader.getFileLocation()));

		} else if (errorServers.size() < clusters.size()) {
			log.error("{} - Failed to create monitors on few of the clusters - {}", mftRequest.getRitmNumber(),
					errorServers);

			// alert status of xml/monitor creation
			alert(mftRequest,
					String.format("Created %s on the servers - %s at - %s and \n Failed to create on the servers - %s",
							environmentMessage(mftRequest), successServers, ScpUploader.getFileLocation(),
							errorServers));

		} else if (errorServers.size() == clusters.size()) {
			log.error("{} - Failed to create monitors on all the clusters {}", mftRequest.getRitmNumber(), clusters);

			// alert status of xml/monitor creation
			alert(mftRequest, String.format("Failed to create %s on all servers - %s", environmentMessage(mftRequest),
					errorServers));
		}
	}

	private void alert(CommandBody mftRequest, String message) throws MFTException {
		Notification notificationEvent = new Notification(mftRequest.getEnvironment().toString(),
				mftRequest.getScenarioName(), mftRequest.getCountryCode(), Integer.valueOf(mftRequest.getInstanceId()),
				mftRequest.getRegion(), message);
		notificationUtility.invokeNotificationApi(notificationUtils.buildEvent(notificationEvent));
	}

	private String environmentMessage(CommandBody mftRequest) {
		if (mftRequest.getEnvironment().equals(MFTEnvironment.PROD)) {
			return "XML";
		}
		return "Monitor";
	}
}
