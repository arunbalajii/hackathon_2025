package com.walmart.intech.mft.automation.app.model;

import javax.validation.constraints.NotNull;

import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class CommandBody {

	private String sourcePath;
	private String targetPath;
	private String user;
	@NotNull
	private MonitorType monitorType;
	@NotNull
	private String scenarioName;
	@NotNull
	private String countryCode;
	@NotNull
	private String instanceId;
	private String filePattern;
	private String triggerPattern;
	private String excludePattern;
	private String inputFileName;
	private String outputFileName;
	private String timestampFormat;
	private boolean timestampAsPartOfFile;
	private boolean archive;
	private boolean create;
	private boolean fileLocking;
	@NotNull
	private String region;
	private String volume;
	private String size;
	private String ritmNumber;
	@NotNull
	private MFTEnvironment environment;
	
}
