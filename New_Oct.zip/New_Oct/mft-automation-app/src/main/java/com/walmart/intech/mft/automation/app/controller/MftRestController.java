package com.walmart.intech.mft.automation.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.processor.RunRemoteCommand;
import com.walmart.intech.mft.automation.app.util.ApiService;
import com.walmart.intech.mft.automation.commons.exceptions.MFTException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class MftRestController {

	@Autowired
	private RunRemoteCommand runRmtCmd;

	@Autowired
	private ApiService apiService;

	@Operation(summary = "Create a new MFT Monitor")
	@ApiResponses(value = { @ApiResponse(responseCode = "202", description = "Accepted"),
			@ApiResponse(responseCode = "400", description = "Bad Request") })
	@PostMapping("/cmd")
	public ResponseEntity<String> postCommand(@Valid @RequestBody CommandBody commands) throws MFTException {

		log.info("Request received:: " + commands);

		if (apiService.validateScenario(commands)) {

			runRmtCmd.runFTFForRegion(commands);

			return ResponseEntity.accepted()
					.body("Request to create monitor on the region-environment servers is in progress");

		} else {
			return ResponseEntity.badRequest()
					.body("Interface not configured in Stronghold with provided 3 key fields");
		}

	}

}
