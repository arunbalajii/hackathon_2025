package com.walmart.intech.mft.automation.app.constants;

public abstract class MftConstants {

    public static final String AGENT_PREFIX               = "AG_LO_";
    public static final String MONITOR_NAME               = "%s_%s_%s_SP_MONITOR";
    public static final String CAT_AGENT_JSON_PATH        = "cat /u/users/ibmusr/agent.json && echo \"exitStatus:0\"";
    public static final String CRT_MONITOR                = "/opt/mqm/bin/fteCreateMonitor -ix %s/%s | grep -i \"The request has successfully completed\" && echo \"exitStatus:0\"";
    public static final String CRT_MONITOR_WITH_LCK       = "/opt/mqm/bin/fteCreateMonitor -ix %s/%s -mmd \"fileLock=FileExtension:.lck\" | grep -i \"The request has successfully completed\" && echo \"exitStatus:0\"";
    public static final String AVG_AGENT_REGEX            = "^%s[0-9]+$";
    public static final String NON_AVG_AGENT_REGEX        = "^%s";
    public static final String FTF_STG_1_CMD              = "/u/users/ibmusr/ftf-stage-1.sh %s %s %s %s";
    public static final String FTF_STG_2_CMD              = "/u/users/ibmusr/verifyMonitor.sh %s";
    public static final String TMP_MFT_XML_CONFIG_PATH    = "/tmp/configs";
    public static final String MFT_XML_CONFIG_PATH        = "/u/mft_app/mft_automation/mft_monitors";
    public static final String XML_CONFIG_FILE            = "agent-config.xml";
    public static final String EXCUDE_XML_CONFIG_FILE     = "agent-config-excludePattern.xml";
    public static final String LIST_MONITOR               = "Monitor Information";
    public static final String MONITOR_CREATED            = "The request has successfully completed";
    public static final String TMP_FILE_MOVE              = "Moved file from ";
    public static final String CUR_TIMESTAMP              = "${CurrentTimeStamp}";
    public static final String SRC_DST_FILE_PATTERN_SUFFIX__WITH_TMSTP       = "%s.%s";
    public static final String SRC_DST_FILE_SUFFIX_PATTERN                   = ".%s";

    public static final String ARCHIVE_COMPRESS_METADATA_FORMAT    = "ARCHIVE|%s_success/#{FileName}%s|COPY|#{SPATH}~COMPRESS|%s_success/#{FileName}%s|.gz";
    public static final String COMPRESS_METADATA_FORMAT            = "COMPRESS|%s_success/#{FileName}%s|.gz";
    public static final String DELETE_METADATA_FORMAT              = "DELETE|${FilePath}";
    public static final String CREATE_METADATA_FORMAT              = "CREATE|#{DPATH}|.trg|Y";




    //====================================XML File Configs==========================================

    public static final String XPATH_SRC_DIR = "/monitor/tasks/task/transfer/request/managedTransfer/transferSet/item/source/file";
    public static final String XPATH_DST_DIR = "/monitor/tasks/task/transfer/request/managedTransfer/transferSet/item/destination/file";

   
    private MftConstants() {
		
	}


}
