package com.walmart.intech.mft.automation.app.processor;

import static com.walmart.intech.mft.automation.app.constants.MftConstants.ARCHIVE_COMPRESS_METADATA_FORMAT;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.CREATE_METADATA_FORMAT;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.CUR_TIMESTAMP;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.DELETE_METADATA_FORMAT;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.EXCUDE_XML_CONFIG_FILE;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.MONITOR_NAME;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.SRC_DST_FILE_PATTERN_SUFFIX__WITH_TMSTP;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.SRC_DST_FILE_SUFFIX_PATTERN;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.XML_CONFIG_FILE;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.XPATH_DST_DIR;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.XPATH_SRC_DIR;
import static javax.xml.xpath.XPathConstants.NODE;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.walmart.intech.mft.automation.app.exception.XMLCreationException;
import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.commons.models.MonitorType;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class XMLConfigGenerator {

	static Document doc = null;
	private static CommandBody mftRequest = null;

	private XMLConfigGenerator() {

	}

	public Map<String, String> getXmlAsString(CommandBody mftreq, String agentName, String serverName,
			String qmgr) throws XMLCreationException {
		mftRequest = mftreq;
		String jobName = String.format("%s.%s.%s", mftRequest.getCountryCode(), mftRequest.getScenarioName(),
				mftRequest.getInstanceId());
		String orgHstname = serverName + ".";
		String monitorName = String.format(MONITOR_NAME, mftRequest.getCountryCode(), mftRequest.getScenarioName(),
				mftRequest.getMonitorType());

		String[] destAgntList = agentName.split("_");
		StringBuilder destAgentName = new StringBuilder();
		// TODO update names here
		for (int i = 0; i < destAgntList.length - 1; i++) {
			destAgentName.append(String.format("%s_", destAgntList[i]));
		}
		destAgentName.append("DEST_");
		destAgentName.append(destAgntList[destAgntList.length - 1]);

		Map<String, String> xmlKvMap = new HashMap<>();

		xmlKvMap.put("/monitor/name", monitorName);
		xmlKvMap.put("/monitor/agent", agentName);
		xmlKvMap.put("/monitor/resources/directory", mftRequest.getSourcePath());
		xmlKvMap.put("/monitor/triggerMatch/conditions/allOf/condition/fileMatch/pattern",
				mftRequest.getTriggerPattern());
		if (mftRequest.getExcludePattern() != null && !mftRequest.getExcludePattern().equals("")) {
			xmlKvMap.put("/monitor/triggerMatch/conditions/allOf/condition/fileMatch/exclude",
					mftRequest.getExcludePattern());
		}
		xmlKvMap.put("/monitor/tasks/task/transfer/request/managedTransfer/originator/hostName", orgHstname);
		if (mftRequest.getInputFileName().matches("." + mftRequest.getTriggerPattern())) {
			xmlKvMap.put(XPATH_SRC_DIR, "${FilePath}");
		} else {
			xmlKvMap.put(XPATH_SRC_DIR, getFileNamePatternFromFileName(mftRequest.getInputFileName()));
		}

		if (mftreq.isFileLocking()) {
			xmlKvMap.put(XPATH_SRC_DIR, xmlKvMap.get(XPATH_SRC_DIR) + ".lck");
		}

		xmlKvMap.put(XPATH_DST_DIR,
				mftRequest.getTargetPath() + "/" + getDestFileNamePatternFromFileName(mftRequest.getOutputFileName(),
						mftRequest.isTimestampAsPartOfFile()));
		xmlKvMap.put("/monitor/tasks/task/transfer/request/managedTransfer/job/name", jobName);
		xmlKvMap.put("/monitor/originator/hostName", orgHstname);

		// Change the XML attributes value for source agent
		Map<String, String> xmlAttribKvMap = new HashMap<>();
		xmlAttribKvMap.put("QMgr", qmgr);
		xmlAttribKvMap.put("agent", agentName);

		try {

			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream is = classloader.getResourceAsStream(XML_CONFIG_FILE);
			if(mftRequest.getExcludePattern()!= null && mftRequest.getExcludePattern()!= "") 
				is = classloader.getResourceAsStream(EXCUDE_XML_CONFIG_FILE);

			DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();

			// To protect Java XML parsers from XXE attacks
			f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");

			DocumentBuilder b = f.newDocumentBuilder();
			doc = b.parse(is);
			Node node = editXmlWithXpath(xmlKvMap);
			Node attrbNode = editXmlAttributes("/monitor/tasks/task/transfer/request/managedTransfer/sourceAgent",
					xmlAttribKvMap);
			xmlAttribKvMap.put("agent", destAgentName.toString());
			attrbNode = editXmlAttributes("/monitor/tasks/task/transfer/request/managedTransfer/destinationAgent",
					xmlAttribKvMap);

			if (mftRequest.isArchive()) {
				xmlKvMap.clear();
				xmlKvMap.put("/monitor/tasks/task/transfer/request/managedTransfer/transferSet/metaDataSet/metaData",
						getUserExitMetadata());
				node = editXmlWithXpath(xmlKvMap);
				xmlAttribKvMap.clear();
				xmlAttribKvMap.put("key", "PostDst");
				attrbNode = editXmlAttributes(
						"/monitor/tasks/task/transfer/request/managedTransfer/transferSet/metaDataSet/metaData",
						xmlAttribKvMap);
			}

			if (!mftRequest.getFilePattern().equals(mftRequest.getTriggerPattern())) {
				xmlKvMap.clear();
				addXmlElement(xmlKvMap, "metaData");
				xmlAttribKvMap.clear();
				xmlAttribKvMap.put("key", "PostDst");
				attrbNode = editXmlAttributes(
						"/monitor/tasks/task/transfer/request/managedTransfer/transferSet/metaDataSet[1]/metaData",
						xmlAttribKvMap);
			}

			xmlAttribKvMap.clear();
			if (mftRequest.getMonitorType().toString().equalsIgnoreCase(MonitorType.FTF.toString())) {
				xmlAttribKvMap.put("disposition", "delete");
			} else {
				xmlAttribKvMap.put("disposition", "leave");
			}
			attrbNode = editXmlAttributes(
					"/monitor/tasks/task/transfer/request/managedTransfer/transferSet/item/source", xmlAttribKvMap);

			DOMSource domSource = new DOMSource(doc);

			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();

			// To protect Java XML parsers from XXE attacks
			tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(domSource, result);
			String res = writer.toString();
			Map<String, String> xmlConfigDtl = new HashMap<>();
			xmlConfigDtl.put(monitorName + ".xml", res);
			return xmlConfigDtl;

		} catch (IOException | ParserConfigurationException | SAXException | TransformerException
				| XPathExpressionException e) {
			log.error("Error creating XML file due to {}", e.getMessage());
			throw new XMLCreationException("Failed to build XML", e);
		}

	}

	private static Node editXmlWithXpath(Map<String, String> xmlKvMap) throws XPathExpressionException {
		Node xmlNode = null;
		if (xmlKvMap != null) {
			for (Map.Entry<String, String> entry : xmlKvMap.entrySet()) {
				XPath xPath = XPathFactory.newInstance().newXPath();
				xmlNode = (Node) xPath.compile(entry.getKey()).evaluate(doc, NODE);
				xmlNode.setTextContent(entry.getValue());
			}
		}
		return xmlNode;
	}

	private static Node addXmlElement(Map<String, String> xmlKvMap, String element) throws XPathExpressionException {
		Node xmlNode = null;
		if (xmlKvMap != null) {

			XPath xpath = null;
			Node newNode = null;
			Element newElement = null;

			for (Map.Entry<String, String> entry : xmlKvMap.entrySet()) {
				xpath = XPathFactory.newInstance().newXPath();
				newNode = (Node) xpath.evaluate(entry.getKey(), doc, NODE);
				newElement = doc.createElement(element);
				newElement.appendChild(doc.createTextNode(entry.getValue()));
				newNode.appendChild(newElement);

			}
		}
		return xmlNode;
	}

	private static Node editXmlAttributes(String xPth, Map<String, String> attrbKvMap) throws XPathExpressionException {
		Node xmlNode = null;
		if (attrbKvMap != null) {
			for (Map.Entry<String, String> entry : attrbKvMap.entrySet()) {
				XPath xPath = XPathFactory.newInstance().newXPath();
				xmlNode = (Node) xPath.compile(xPth).evaluate(doc, NODE);
				Node attrbNode = xmlNode.getAttributes().getNamedItem(entry.getKey());
				attrbNode.setTextContent(entry.getValue());
			}
		}
		return xmlNode;
	}

	private static String getFileNamePatternFromFileName(String filename) {

		StringBuilder finalFileName = new StringBuilder();
		String[] tokenSeprator = new String[0];
		if (filename != null) {
			tokenSeprator = filename.split("\\.");

			for (int i = 0; i < tokenSeprator.length - 1; i++) {
				if (finalFileName.length() == 0) {
					finalFileName.append(String.format("${FilePath{token=%d}{separator=.}}", i + 1));
				} else {
					finalFileName.append(String.format(".${FilePath{token=%d}{separator=.}}", i + 1));
				}
			}
		}
		
		finalFileName.append(String.format(SRC_DST_FILE_SUFFIX_PATTERN, tokenSeprator[tokenSeprator.length - 1]));
		return finalFileName.toString();
	}

	private static String getDestFileNamePatternFromFileName(String filename, boolean isTimestampAsPartOfFile) {

		StringBuilder finalFileName = new StringBuilder();
		String[] tokenSeprator = new String[0];
		if (filename != null) {
			tokenSeprator = filename.split("\\.");

			for (int i = 0; i < tokenSeprator.length - 1; i++) {
				if (finalFileName.length() == 0) {
					finalFileName.append(String.format("${FileName{token=%d}{separator=.}}", i + 1));
				} else {
					finalFileName.append(String.format(".${FileName{token=%d}{separator=.}}", i + 1));
				}
			}
		}

		finalFileName.append(isTimestampAsPartOfFile
				? String.format(SRC_DST_FILE_PATTERN_SUFFIX__WITH_TMSTP, CUR_TIMESTAMP,
						tokenSeprator[tokenSeprator.length - 1])
				: String.format(SRC_DST_FILE_SUFFIX_PATTERN, tokenSeprator[tokenSeprator.length - 1]));

		return finalFileName.toString();
	}

	private static String getMftTimestampVar(String tsFormat, boolean isTimestampAsPartOfFile) {

		if (isTimestampAsPartOfFile && tsFormat != null)
			return "#{" + tsFormat.toUpperCase() + "}";
		return "";

	}

	private static String getUserExitMetadata() {
		String metadata = null;

//		if (mftRequest.isCreate() && mftRequest.isArchive()) {
		if (mftRequest.isCreate()) {
			if (mftRequest.getFilePattern().equals(mftRequest.getTriggerPattern())) {
				metadata = mftRequest.isTimestampAsPartOfFile()
						? String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(
										mftRequest.getTimestampFormat(), mftRequest.isTimestampAsPartOfFile()),
								mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(mftRequest.getTimestampFormat(),
										mftRequest.isTimestampAsPartOfFile()))
						: String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(), "",
								mftRequest.getSourcePath(), "");
			} else
				metadata = mftRequest.isTimestampAsPartOfFile()
						? String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(
										mftRequest.getTimestampFormat(), mftRequest.isTimestampAsPartOfFile()),
								mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(mftRequest.getTimestampFormat(),
										mftRequest.isTimestampAsPartOfFile()))
								+ "~" + String.format(DELETE_METADATA_FORMAT)
						: String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(), "",
								mftRequest.getSourcePath(), "");

			return metadata;
		}

//		else if (mftRequest.isCreate()) {
//
//			if (mftRequest.getFilePattern().equals(mftRequest.getTriggerPattern())) {
//				metadata = mftRequest.isTimestampAsPartOfFile()
//						? String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(),
//								"_" + getMftTimestampVar(
//										mftRequest.getTimestampFormat(), mftRequest.isTimestampAsPartOfFile()),
//								mftRequest.getSourcePath(),
//								"_" + getMftTimestampVar(mftRequest.getTimestampFormat(),
//										mftRequest.isTimestampAsPartOfFile()))
//						: String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(), "",
//								mftRequest.getSourcePath(), "");
//			} else
//				metadata = mftRequest.isTimestampAsPartOfFile()
//						? String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(),
//								"_" + getMftTimestampVar(
//										mftRequest.getTimestampFormat(), mftRequest.isTimestampAsPartOfFile()),
//								mftRequest.getSourcePath(),
//								"_" + getMftTimestampVar(mftRequest.getTimestampFormat(),
//										mftRequest.isTimestampAsPartOfFile()))
//								+ "~" + String.format(DELETE_METADATA_FORMAT)
//						: String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(), "",
//								mftRequest.getSourcePath(), "");
//
//			return metadata;
//		}

//		else if (mftRequest.isArchive()) {
			if (mftRequest.getFilePattern().equals(mftRequest.getTriggerPattern())) {
				metadata = mftRequest.isTimestampAsPartOfFile()
						? String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(
										mftRequest.getTimestampFormat(), mftRequest.isTimestampAsPartOfFile()),
								mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(mftRequest.getTimestampFormat(),
										mftRequest.isTimestampAsPartOfFile()))
						: String.format(ARCHIVE_COMPRESS_METADATA_FORMAT, mftRequest.getSourcePath(), "",
								mftRequest.getSourcePath(), "");
			} else
				metadata = mftRequest.isTimestampAsPartOfFile()
						? String.format(CREATE_METADATA_FORMAT, mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(
										mftRequest.getTimestampFormat(), mftRequest.isTimestampAsPartOfFile()),
								mftRequest.getSourcePath(),
								"_" + getMftTimestampVar(mftRequest.getTimestampFormat(),
										mftRequest.isTimestampAsPartOfFile()))
								+ String.format(DELETE_METADATA_FORMAT)
						: String.format(CREATE_METADATA_FORMAT, mftRequest.getSourcePath(), "",
								mftRequest.getSourcePath(), "");

			return metadata;
//		}
//
//		return "";
	}

}
