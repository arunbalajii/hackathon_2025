package com.walmart.intech.mft.automation.app.processor;

import static com.walmart.intech.mft.automation.app.constants.MftConstants.AGENT_PREFIX;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.AVG_AGENT_REGEX;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.CAT_AGENT_JSON_PATH;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.CRT_MONITOR;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.CRT_MONITOR_WITH_LCK;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.FTF_STG_1_CMD;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.FTF_STG_2_CMD;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.LIST_MONITOR;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.MFT_XML_CONFIG_PATH;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.MONITOR_CREATED;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.MONITOR_NAME;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.NON_AVG_AGENT_REGEX;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.TMP_FILE_MOVE;
import static com.walmart.intech.mft.automation.app.constants.MftConstants.TMP_MFT_XML_CONFIG_PATH;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;
import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.util.MftUtil;
import com.walmart.intech.mft.automation.commons.exceptions.AgentLookupException;
import com.walmart.intech.mft.automation.commons.exceptions.MFTException;
import com.walmart.intech.mft.automation.commons.models.AgentDetail;
import com.walmart.intech.mft.automation.commons.models.RegionClusters.Cluster;
import com.walmart.intech.mft.automation.commons.services.AgentService;
import com.walmart.intech.mft.automation.commons.services.CommandService;
import com.walmart.intech.mft.automation.commons.services.FileService;
import com.walmart.intech.mft.automation.commons.services.RegionService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RunRemoteCommand {

	@Autowired
	private RegionService mftServerService;
	@Autowired
	private AgentService agentService;
	@Autowired
	private CommandService commandService;
	@Autowired
	private FileService fileService;
	@Autowired
	private XMLConfigGenerator xmlConfigGenerator;

	@Autowired
	private MftUtil mftUtil;

	Channel channel = null;
	Session jschSession = null;

	String remoteServer = null;
	String qmgr = null;

	String xmlFileName = null;

	@Async
	public void runFTFForRegion(CommandBody mftRequest) throws MFTException {

		// Retrieving servers based on region
		List<Cluster> clusters = mftServerService.getRemoteServers(mftRequest.getRegion(), mftRequest.getEnvironment());
		List<String> successServers = new ArrayList<>();
		List<String> errorServers = new ArrayList<>();

		for (Cluster cluster : clusters) {
			try {
				remoteServer = cluster.getServer();
				qmgr = cluster.getQmgr();
				runFTFCluster(mftRequest);
				log.info("{} - Created monitor in the cluster : {}", mftRequest.getRitmNumber(), cluster);
				successServers.add(remoteServer);
			} catch (Exception mftException) {
				log.error("{} - Failed to create monitor in the cluster : {} due to {}", mftRequest.getRitmNumber(),
						cluster, mftException.getMessage());
				errorServers.add(remoteServer);
			}
		}

		mftUtil.logAndAlert(errorServers, successServers, clusters, mftRequest);

	}

	public void runFTFCluster(CommandBody mftRequest) throws MFTException {

		log.info("Running on Server: {}", remoteServer);

		String cmd = String.format(CAT_AGENT_JSON_PATH);

		// Retrieve agent based on the volume and size
		AgentDetail agentDetail = agentService.getAgentDetail(mftRequest.getVolume(), mftRequest.getSize());

		// List all available agents on the server
		commandService.runCmd(cmd, false, remoteServer, AGENT_PREFIX);

		Map<String, Integer> agentMap = agentService.agentJsonToMap();

		String agentName = retrieveAgentName(mftRequest, agentDetail, agentMap);
		log.info("Agent is {} for the monitor in {}", agentName, remoteServer);

		runEnvironmentSpecifics(mftRequest, agentName);
	}

	/**
	 * Method to retrieve agent name
	 * 
	 * @param mftRequest
	 * @param agentDetail
	 * @param agentMap
	 * @return
	 * @throws AgentLookupException
	 */
	private String retrieveAgentName(CommandBody mftRequest, AgentDetail agentDetail, Map<String, Integer> agentMap)
			throws AgentLookupException {
		List<String> agentNameList = null;
		String a = AGENT_PREFIX + mftRequest.getRegion() + agentDetail.getAgentName();

		if (agentDetail.getAgentName().equals("_")) {
			agentNameList = agentService.agentNameLookup(String.format(AVG_AGENT_REGEX, a), agentMap);
		} else {
			agentNameList = agentService.agentNameLookup(String.format(NON_AVG_AGENT_REGEX, a), agentMap);
		}
		Optional<String> optional = agentNameList.stream().findFirst()
				.filter(n -> agentMap.get(n) <= agentDetail.getMaxMonitors());
		if (optional.isPresent()) {
			return optional.get();
		}
		throw new AgentLookupException("No valid agents found with required configuration");
	}

	/**
	 * Method to run environment specific implementation
	 * 
	 * @param mftRequest
	 * @param agentName
	 * @throws MFTException
	 */
	public void runEnvironmentSpecifics(CommandBody mftRequest, String agentName) throws MFTException {

		switch (mftRequest.getEnvironment()) {
		case PROD:
			uploadXMLFile(agentName, mftRequest);

			break;
		default:
			uploadXMLFile(agentName, mftRequest);

			// command to create monitor on the server
			createMonitor(mftRequest);

			// command to verify if monitor is created on server
			verifyMonitor(mftRequest);

			break;
		}
	}

	/**
	 * Method to create xml and upload files on the server
	 * 
	 * @param agentName
	 * @param mftRequest
	 * @param serverResponse
	 *
	 * @throws MFTException
	 */
	private void uploadXMLFile(String agentName, CommandBody mftRequest) throws MFTException {
		log.info(" Agent name: {}", agentName);

		// Build xml
		Map<String, String> xmlConfigDtl = xmlConfigGenerator.getXmlAsString(mftRequest, agentName, remoteServer, qmgr);

		String xmlFileContent = null;
		for (Map.Entry<String, String> entry : xmlConfigDtl.entrySet()) {
			xmlFileName = entry.getKey();
			xmlFileContent = entry.getValue();
		}

		fileService.uploadFile(TMP_MFT_XML_CONFIG_PATH, xmlFileName, xmlFileContent, remoteServer);

		createDirectories(mftRequest);

	}

	/**
	 * Method to create source, destination and temporary folders to place the xml
	 * file
	 * 
	 * @param mftRequest
	 * 
	 * @throws MFTException
	 */
	private void createDirectories(CommandBody mftRequest) throws MFTException {
		String cmd = String.format(FTF_STG_1_CMD, mftRequest.getRegion(), mftRequest.getSourcePath(),
				mftRequest.getTargetPath(), xmlFileName);
		commandService.runCmd(cmd, false, remoteServer, TMP_FILE_MOVE + TMP_MFT_XML_CONFIG_PATH);
	}

	/**
	 * Method to create monitor on the server
	 * 
	 * @param mftRequest
	 * @return
	 * @throws MFTException
	 */
	private void createMonitor(CommandBody mftRequest) throws MFTException {
		log.debug("Creating monitor started..");
		String cmd = mftRequest.isFileLocking() ? String.format(CRT_MONITOR_WITH_LCK, MFT_XML_CONFIG_PATH, xmlFileName)
				: String.format(CRT_MONITOR, MFT_XML_CONFIG_PATH, xmlFileName);
		commandService.runCmd(cmd, false, remoteServer, MONITOR_CREATED);
		log.info("Monitor is created for {}", mftRequest);
	}

	/**
	 * Method to verify if monitor is created on the server
	 * 
	 * @param mftRequest
	 * 
	 * @throws MFTException
	 */
	private void verifyMonitor(CommandBody mftRequest) throws MFTException {
		log.debug("Verifying monitor creation..");
		String cmd = String.format(FTF_STG_2_CMD, String.format(MONITOR_NAME, mftRequest.getCountryCode(),
				mftRequest.getScenarioName(), mftRequest.getMonitorType()));
		commandService.runCmd(cmd, false, remoteServer, LIST_MONITOR);
		log.info("Monitor creation is verified for {}", mftRequest);
	}

}
