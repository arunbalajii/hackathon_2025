package com.walmart.intech.mft.automation.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.walmart.intech.mft.automation.commons.config.RemoteServerConfig;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	private static final String[] AUTH_WHITELIST = { "/actuator", "/actuator/*", "/actuator/*/*" };

	@Autowired
	private RemoteServerConfig remoteServerConfig;

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity.csrf().disable().authorizeRequests().antMatchers(AUTH_WHITELIST).permitAll().anyRequest()
				.fullyAuthenticated().and().httpBasic();
	}

	@Autowired
	@Override
	public void configure(AuthenticationManagerBuilder authentication) throws Exception {
		String userName = remoteServerConfig.getUser();
		String password = remoteServerConfig.getBasicAuthCred();
		String encodedPassword = new BCryptPasswordEncoder().encode(password);
		authentication.inMemoryAuthentication().withUser(userName).password("{bcrypt}" + encodedPassword).roles("USER");
	}
}
