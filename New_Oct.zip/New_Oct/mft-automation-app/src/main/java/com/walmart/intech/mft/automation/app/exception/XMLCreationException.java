package com.walmart.intech.mft.automation.app.exception;

import com.walmart.intech.mft.automation.commons.exceptions.MFTException;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class XMLCreationException extends MFTException {

	public XMLCreationException(String message) {
		super(message);
	}

	public XMLCreationException(Throwable throwable) {
		super(throwable);
	}

	public XMLCreationException(String message, Throwable throwable) {
		super(message, throwable);
	}

}
