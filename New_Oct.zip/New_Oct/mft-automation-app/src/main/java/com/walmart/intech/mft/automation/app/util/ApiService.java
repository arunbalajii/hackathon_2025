package com.walmart.intech.mft.automation.app.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.commons.config.RemoteServerConfig;

@Component
public class ApiService {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private RemoteServerConfig remoteServerConfig;

	/**
	 * Method to invoke Stronghold api and validate the scenario
	 * 
	 * @param commands - input request
	 * @return responseEntity - response from Stronghold API
	 */
	public boolean validateScenario(CommandBody commands) {

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");
		HttpEntity<String> httpEntity = new HttpEntity<>(httpHeaders);

		// Stronghold api invocation to validate the 3 key fields
		ResponseEntity<String> response= restTemplate.exchange(String.format(remoteServerConfig.getValidationUri(), commands.getCountryCode(), commands.getScenarioName(),
				commands.getInstanceId()), HttpMethod.GET, httpEntity, String.class);
		if (response.getStatusCode()==HttpStatus.OK)
			return true;
		return false;

	}

}
