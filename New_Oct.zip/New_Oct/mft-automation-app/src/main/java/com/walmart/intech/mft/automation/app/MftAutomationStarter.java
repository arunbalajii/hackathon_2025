package com.walmart.intech.mft.automation.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@ComponentScan(basePackages = { "com.walmart.intech.mft.automation.app", "com.walmart.intech.mft.automation.commons" })
@SpringBootApplication
public class MftAutomationStarter {

	public static void main(String[] args) {
		SpringApplication.run(MftAutomationStarter.class, args);
	}

}
