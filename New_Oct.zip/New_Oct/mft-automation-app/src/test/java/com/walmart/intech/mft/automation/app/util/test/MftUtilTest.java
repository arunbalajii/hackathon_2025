package com.walmart.intech.mft.automation.app.util.test;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.util.MftUtil;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;
import com.walmart.intech.mft.automation.commons.models.RegionClusters.Cluster;
import com.walmart.intech.mft.automation.commons.notification.NotificationInvoker;
import com.walmart.intech.mft.automation.commons.notification.NotificationUtils;

@RunWith(SpringRunner.class)
public class MftUtilTest {
	
	@InjectMocks
	MftUtil mftUtil;
	
	@Mock
	NotificationInvoker notificationUtility;
	@Mock
	NotificationUtils notificationUtils;
	
	private CommandBody commandBody;
	
	@Test
	public void testLogAlertsFailureAlert() {
		try {
			buildCommandBody();
			List<String> errorServers = Arrays.asList("server1");
			List<String> successServers = Arrays.asList("server2");
			List<Cluster> clusters  = Arrays.asList(new Cluster("server","qmgr","cluster"));
			mftUtil.logAndAlert(errorServers, successServers, clusters, commandBody);
			assertTrue(true);
		}
		catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testLogAlertsFailureAlert2() {
		try {
			buildCommandBody();
			List<String> errorServers = Arrays.asList("server1","server2");
			List<String> successServers = Arrays.asList("server2");
			List<Cluster> clusters  = Arrays.asList(new Cluster("server","qmgr","cluster"));
			mftUtil.logAndAlert(errorServers, successServers, clusters, commandBody);
			assertTrue(true);
		}
		catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testLogAlertsSuccessAlert() {
		try {
			buildCommandBody();
			List<String> errorServers = new ArrayList();
			List<String> successServers = Arrays.asList("server2");
			List<Cluster> clusters  = Arrays.asList(new Cluster("server","qmgr","cluster"));
			mftUtil.logAndAlert(errorServers, successServers, clusters, commandBody);
			assertTrue(true);
		}
		catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testLogAlertsSuccessAlert2() {
		try {
			buildCommandBody();
			commandBody.setEnvironment(MFTEnvironment.PROD);
			List<String> errorServers = Arrays.asList("server1");
			List<String> successServers = Arrays.asList("server2");
			List<Cluster> clusters  = Arrays.asList(new Cluster("server","qmgr","cluster"),new Cluster("server","qmgr","cluster"));
			mftUtil.logAndAlert(errorServers, successServers, clusters, commandBody);
			assertTrue(true);
		}
		catch(Exception e) {
			assertTrue(false);
		}
	}
	
	private void buildCommandBody() {
		commandBody = new CommandBody();
		commandBody.setSourcePath("sourcePath");
		commandBody.setTargetPath("targetPath");
		commandBody.setUser("testUser");
		commandBody.setMonitorType(MonitorType.FTF);
		commandBody.setScenarioName("testScenario");
		commandBody.setCountryCode("WW");
		commandBody.setInstanceId("1");
		commandBody.setFilePattern("*.txt");
		commandBody.setTriggerPattern("*.trg");
		commandBody.setInputFileName("test.txt");
		commandBody.setOutputFileName("test.txt");
		commandBody.setTimestampFormat("TS1");
		commandBody.setTimestampAsPartOfFile(true);
		commandBody.setArchive(true);
		commandBody.setCreate(false);
		commandBody.setFileLocking(false);
		commandBody.setRegion("APAC");
		commandBody.setVolume("Average");
		commandBody.setSize("Average");
		commandBody.setRitmNumber("RITMtest");
		commandBody.setEnvironment(MFTEnvironment.FUT);
	}

}
