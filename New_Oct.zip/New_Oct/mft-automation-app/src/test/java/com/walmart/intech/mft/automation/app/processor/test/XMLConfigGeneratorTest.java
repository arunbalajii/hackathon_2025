package com.walmart.intech.mft.automation.app.processor.test;

import static org.junit.Assert.assertNotNull;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.intech.mft.automation.app.exception.XMLCreationException;
import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.processor.XMLConfigGenerator;
import com.walmart.intech.mft.automation.commons.config.RemoteServerConfig;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;

@SuppressWarnings("static-access")
@RunWith(SpringRunner.class)
public class XMLConfigGeneratorTest {
	
	@InjectMocks
	XMLConfigGenerator xmlConfigGenerator;
	
	@Mock
	RemoteServerConfig remoteServerConfig;
	
	private CommandBody commandBody;
	private Map<String, String> xmlMap;
	

	@Test
	public void testGetXmlAsString() throws XMLCreationException {	
		buildCommandBody();
		xmlMap = xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test
	public void testGetXmlAsString2() throws XMLCreationException {	
		buildCommandBody();
		commandBody.setTriggerPattern("*.txt");
		commandBody.setInputFileName("test.txt");
		xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test
	public void testGetXmlAsStringExcludePatternEmpty() throws XMLCreationException {	
		buildCommandBody();
		commandBody.setExcludePattern("");
		xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test
	public void testGetXmlAsStringExcludePattern() throws XMLCreationException {	
		buildCommandBody();
		commandBody.setExcludePattern("*.csv");
		xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test
	public void testGetXmlAsStringFileLocking() throws XMLCreationException {	
		buildCommandBody();
		commandBody.setFileLocking(true);
		xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test
	public void testGetXmlAsStringDestinationFileName() throws XMLCreationException {	
		buildCommandBody();
		commandBody.setTimestampAsPartOfFile(false);
		commandBody.setOutputFileName("test.abc.txt");
		xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "test_Agent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test
	public void testGetXmlAsStringInputFileName() throws XMLCreationException {	
		buildCommandBody();
		commandBody.setTimestampAsPartOfFile(false);
		commandBody.setInputFileName("test.abc.txt");
		xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "test_Agent", "testServer", "testQmgr");
		assertNotNull(xmlMap);
	}
	
	@Test(expected=NullPointerException.class)
	public void testGetXmlAsStringNullFIleName() throws XMLCreationException {
			buildCommandBody();
			commandBody.setInputFileName(null);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test(expected=ArrayIndexOutOfBoundsException.class)
	public void testGetXmlAsStringNullDestFIleName() throws XMLCreationException {
			buildCommandBody();
			commandBody.setOutputFileName(null);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveTS2() throws XMLCreationException {
			buildCommandBody();
			commandBody.setTimestampFormat(null);
			commandBody.setTriggerPattern("*.txt");
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveTSFalse() throws XMLCreationException {
			buildCommandBody();
			commandBody.setTimestampAsPartOfFile(false);
			commandBody.setTimestampFormat(null);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveTSFalse2() throws XMLCreationException {
			buildCommandBody();
			commandBody.setTriggerPattern("*.txt");
			commandBody.setTimestampAsPartOfFile(false);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataCreateTS() throws XMLCreationException {
			buildCommandBody();
			commandBody.setArchive(false);
			commandBody.setCreate(true);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataCreateTS2() throws XMLCreationException {
			buildCommandBody();
			commandBody.setArchive(false);
			commandBody.setCreate(true);
			commandBody.setTriggerPattern("*.txt");
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataCreateTSFalse() throws XMLCreationException {
			buildCommandBody();
			commandBody.setArchive(false);
			commandBody.setCreate(true);
			commandBody.setTimestampAsPartOfFile(false);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataCreateTSFalse2() throws XMLCreationException {
			buildCommandBody();
			commandBody.setArchive(false);
			commandBody.setCreate(true);
			commandBody.setTriggerPattern("*.txt");
			commandBody.setTimestampAsPartOfFile(false);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveCreateTS() throws XMLCreationException {
			buildCommandBody();
			commandBody.setCreate(true);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveCreateTS2() throws XMLCreationException {
			buildCommandBody();
			commandBody.setCreate(true);
			commandBody.setTriggerPattern("*.txt");
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveCreateTSFalse() throws XMLCreationException {
			buildCommandBody();
			commandBody.setCreate(true);
			commandBody.setTimestampAsPartOfFile(false);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveCreateTSFalse2() throws XMLCreationException {
			buildCommandBody();
			commandBody.setCreate(true);
			commandBody.setTriggerPattern("*.txt");
			commandBody.setTimestampAsPartOfFile(false);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	@Test
	public void testUserExitMetadataArchieveFalseCreateFalse() throws XMLCreationException {
			buildCommandBody();
			commandBody.setArchive(false);
			xmlMap=xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
			assertNotNull(xmlMap);
	}
	
	
//	@Test(expected=NullPointerException.class)
//	public void testGetXmlAsString2() throws XMLCreationException {	
//		buildCommandBody();
//		xmlConfigGenerator.getXmlAsString(commandBody, "test_Agent", "testServer", "testQmgr");
//	}
//	
//	@Test(expected=NullPointerException.class)
//	public void testGetXmlAsString3() throws XMLCreationException {	
//		buildCommandBody();
//		commandBody.setTriggerPattern("*.txt");
//		commandBody.setInputFileName("test.txt");
//		xmlConfigGenerator.getXmlAsString(commandBody, "test_Agent", "testServer", "testQmgr");
//	}
//	
//	@Test(expected=NullPointerException.class)
//	public void testGetXmlAsStringExcludePatternEmpty() throws XMLCreationException {	
//		buildCommandBody();
//		commandBody.setExcludePattern("");
//		xmlConfigGenerator.getXmlAsString(commandBody, "test_Agent", "testServer", "testQmgr");
//	}
//	
//	@Test(expected=NullPointerException.class)
//	public void testGetXmlAsStringExcludePatternNotEmpty() throws XMLCreationException {	
//		buildCommandBody();
//		commandBody.setExcludePattern("*.csv");
//		xmlConfigGenerator.getXmlAsString(commandBody, "test_Agent", "testServer", "testQmgr");
//	}
//	
//	@Test(expected=NullPointerException.class)
//	public void testGetXmlAsStringFileLocking() throws XMLCreationException {	
//		buildCommandBody();
//		commandBody.setFileLocking(true);
//		xmlConfigGenerator.getXmlAsString(commandBody, "testAgent", "testServer", "testQmgr");
//	}
//	
//	@Test
//	public void testEditXmlWithXpathNull() throws XPathExpressionException {	
//		assertNull(xmlConfigGenerator.editXmlWithXpath(null));
//	}
//	
//	@Test(expected=XPathExpressionException.class)
//	public void testEditXmlWithXpath() throws XPathExpressionException {	
//		Map<String, String> xmlKvMap = new HashMap<String, String>();
//		xmlKvMap.put("key", "value");
//		xmlConfigGenerator.editXmlWithXpath(xmlKvMap);
//	}
//	
//	@Test
//	public void testEditXmlAttributesNull() throws XPathExpressionException {	
//		assertNull(xmlConfigGenerator.editXmlAttributes("xPth", null));
//	}
//	
//	@Test(expected=XPathExpressionException.class)
//	public void testEditXmlAttributes() throws XPathExpressionException {	
//		Map<String, String> xmlKvMap = new HashMap<String, String>();
//		xmlKvMap.put("key", "value");
//		assertNull(xmlConfigGenerator.editXmlAttributes("xPth", xmlKvMap));
//	}
//	
//	@Test
//	public void testAddXmlElementNull() throws XPathExpressionException {	
//		assertNull(xmlConfigGenerator.addXmlElement(null, "element"));
//	}
//	
//	@Test(expected=XPathExpressionException.class)
//	public void testAddXmlElement() throws XPathExpressionException {	
//		Map<String, String> xmlKvMap = new HashMap<String, String>();
//		xmlKvMap.put("key", "value");
//		assertNull(xmlConfigGenerator.addXmlElement(xmlKvMap, "element"));
//	}
//	
//	@Test
//	public void testGetFileNamePatternFromFileName() {
//		String destFileNamePattern = xmlConfigGenerator.getFileNamePatternFromFileName("test.abc.txt", true);
//		assertEquals("${FilePath{token=1}{separator=.}}.${FilePath{token=2}{separator=.}}${CurrentTimeStamp}.txt",destFileNamePattern);
//	}
//	
//	@Test
//	public void testGetFileNamePatternFromFileName2() {
//		String destFileNamePattern = xmlConfigGenerator.getFileNamePatternFromFileName("test.abc.txt", false);
//		assertEquals("${FilePath{token=1}{separator=.}}.${FilePath{token=2}{separator=.}}.txt",destFileNamePattern);
//	}
//	
//	@Test(expected=ArrayIndexOutOfBoundsException.class)
//	public void testGetFileNamePatternFromFileNameException() {
//		xmlConfigGenerator.getFileNamePatternFromFileName(null, false);		
//	}
//	
//	@Test
//	public void testGetDestFileNamePatternFromFileName() {
//		String destFileNamePattern = xmlConfigGenerator.getDestFileNamePatternFromFileName("test.abc.txt", true);
//		assertEquals("${FileName{token=1}{separator=.}}.${FileName{token=2}{separator=.}}${CurrentTimeStamp}.txt",destFileNamePattern);
//	}
//	
//	@Test
//	public void testGetDestFileNamePatternFromFileName2() {
//		String destFileNamePattern = xmlConfigGenerator.getDestFileNamePatternFromFileName("test.abc.txt", false);
//		assertEquals("${FileName{token=1}{separator=.}}.${FileName{token=2}{separator=.}}.txt",destFileNamePattern);
//	}
//	
//	@Test(expected=ArrayIndexOutOfBoundsException.class)
//	public void testGetDestFileNamePatternFromFileNameException() {
//		xmlConfigGenerator.getDestFileNamePatternFromFileName(null, false);		
//	}
//	
//	@Test
//	public void testGetMftTimestampVar() {
//		String timestampVar = xmlConfigGenerator.getMftTimestampVar("TS1", true);
//		assertEquals("#{TS1}", timestampVar);
//	}
//	
//	@Test
//	public void testGetMftTimestampVar2() {
//		String timestampVar = xmlConfigGenerator.getMftTimestampVar("TS1", false);
//		assertEquals("", timestampVar);
//	}
//	
//	@Test
//	public void testGetMftTimestampVar3() {
//		String timestampVar = xmlConfigGenerator.getMftTimestampVar(null, true);
//		assertEquals("", timestampVar);
//	}
//	
//	@Test
//	public void testGetMftTimestampVar4() {
//		String timestampVar = xmlConfigGenerator.getMftTimestampVar(null, false);
//		assertEquals("", timestampVar);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveTS() {
//			buildCommandBody();
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("CREATE|#{DPATH}|.trg|YDELETE|${FilePath}", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveTS2() {
//			buildCommandBody();
//			commandBody.setTriggerPattern("*.txt");
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}_#{TS1}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}_#{TS1}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveTSFalse() {
//			buildCommandBody();
//			commandBody.setTimestampAsPartOfFile(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("CREATE|#{DPATH}|.trg|Y", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveTSFalse2() {
//			buildCommandBody();
//			commandBody.setTriggerPattern("*.txt");
//			commandBody.setTimestampAsPartOfFile(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataCreateTS() {
//			buildCommandBody();
//			commandBody.setArchive(false);
//			commandBody.setCreate(true);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}_#{TS1}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}_#{TS1}|.gz~DELETE|${FilePath}", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataCreateTS2() {
//			buildCommandBody();
//			commandBody.setArchive(false);
//			commandBody.setCreate(true);
//			commandBody.setTriggerPattern("*.txt");
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}_#{TS1}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}_#{TS1}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataCreateTSFalse() {
//			buildCommandBody();
//			commandBody.setArchive(false);
//			commandBody.setCreate(true);
//			commandBody.setTimestampAsPartOfFile(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataCreateTSFalse2() {
//			buildCommandBody();
//			commandBody.setArchive(false);
//			commandBody.setCreate(true);
//			commandBody.setTriggerPattern("*.txt");
//			commandBody.setTimestampAsPartOfFile(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveCreateTS() {
//			buildCommandBody();
//			commandBody.setCreate(true);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}_#{TS1}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}_#{TS1}|.gz~DELETE|${FilePath}", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveCreateTS2() {
//			buildCommandBody();
//			commandBody.setCreate(true);
//			commandBody.setTriggerPattern("*.txt");
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}_#{TS1}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}_#{TS1}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveCreateTSFalse() {
//			buildCommandBody();
//			commandBody.setCreate(true);
//			commandBody.setTimestampAsPartOfFile(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveCreateTSFalse2() {
//			buildCommandBody();
//			commandBody.setCreate(true);
//			commandBody.setTriggerPattern("*.txt");
//			commandBody.setTimestampAsPartOfFile(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("ARCHIVE|sourcePath_success/#{FileName}|COPY|#{SPATH}~COMPRESS|sourcePath_success/#{FileName}|.gz", metadata);
//	}
//	
//	@Test
//	public void testUserExitMetadataArchieveFalseCreateFalse() {
//			buildCommandBody();
//			commandBody.setArchive(false);
//			String metadata = xmlConfigGenerator.getUserExitMetadata(commandBody);
//			assertEquals("", metadata);
//	}
	
	private void buildCommandBody() {
		commandBody = new CommandBody();
		commandBody.setSourcePath("sourcePath");
		commandBody.setTargetPath("targetPath");
		commandBody.setUser("testUser");
		commandBody.setMonitorType(MonitorType.FTF);
		commandBody.setScenarioName("testScenario");
		commandBody.setCountryCode("WW");
		commandBody.setInstanceId("1");
		commandBody.setFilePattern("*.txt");
		commandBody.setTriggerPattern("*.trg");
		commandBody.setInputFileName("test.txt");
		commandBody.setOutputFileName("test.txt");
		commandBody.setTimestampFormat("TS1");
		commandBody.setTimestampAsPartOfFile(true);
		commandBody.setArchive(true);
		commandBody.setCreate(false);
		commandBody.setFileLocking(false);
		commandBody.setRegion("APAC");
		commandBody.setVolume("Average");
		commandBody.setSize("Average");
		commandBody.setRitmNumber("RITMtest");
		commandBody.setEnvironment(MFTEnvironment.FUT);
	}

}
