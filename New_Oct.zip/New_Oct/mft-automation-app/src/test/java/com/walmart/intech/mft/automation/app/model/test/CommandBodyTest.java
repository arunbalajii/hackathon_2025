package com.walmart.intech.mft.automation.app.model.test;

import static org.junit.Assert.assertEquals;

import java.time.Instant;

import org.junit.BeforeClass;
import org.junit.Test;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;

public class CommandBodyTest {
	
	private static CommandBody commandBody;
	
    @BeforeClass
    public static void setUp() {
    	commandBody = new CommandBody();
		commandBody.setSourcePath("sourcePath");
		commandBody.setTargetPath("targetPath");
		commandBody.setUser("testUser");
		commandBody.setMonitorType(MonitorType.FTF);
		commandBody.setScenarioName("testScenario");
		commandBody.setCountryCode("WW");
		commandBody.setInstanceId("1");
		commandBody.setFilePattern("*.txt");
		commandBody.setTriggerPattern("*.trg");
		commandBody.setExcludePattern("*.xml");
		commandBody.setInputFileName("test.txt");
		commandBody.setOutputFileName("test.txt");
		commandBody.setTimestampFormat("TS1");
		commandBody.setTimestampAsPartOfFile(true);
		commandBody.setArchive(true);
		commandBody.setCreate(false);
		commandBody.setFileLocking(false);
		commandBody.setRegion("APAC");
		commandBody.setVolume("Average");
		commandBody.setSize("Average");
		commandBody.setRitmNumber("RITMtest");
		commandBody.setEnvironment(MFTEnvironment.FUT);
    }
    
    @Test
    public void testGetSourcePath() {
         assertEquals("Validating Source Path", "sourcePath", commandBody.getSourcePath());
    }
    
    @Test
    public void testGetTargetPath() {
         assertEquals("Validating Source Path", "targetPath", commandBody.getTargetPath());
    }
    
    @Test
    public void testGetUser() {
         assertEquals("Validating Source Path", "testUser", commandBody.getUser());
    }
    
    @Test
    public void testGetMonitorType() {
         assertEquals("Validating Source Path", MonitorType.FTF, commandBody.getMonitorType());
    }
        
    @Test
    public void testGetScenarioName() {
         assertEquals("Validating Source Path", "testScenario", commandBody.getScenarioName());
    }
    
    @Test
    public void testGetCountryCode() {
         assertEquals("Validating Source Path", "WW", commandBody.getCountryCode());
    }
    
    @Test
    public void testGetInstanceId() {
         assertEquals("Validating Source Path", "1", commandBody.getInstanceId());
    }
    
    @Test
    public void testGetFilePattern() {
         assertEquals("Validating Source Path", "*.txt", commandBody.getFilePattern());
    }
    
    @Test
    public void testGetTriggerPattern() {
         assertEquals("Validating Source Path", "*.trg", commandBody.getTriggerPattern());
    }
    
    
    @Test
    public void testGetExcludePattern() {
         assertEquals("Validating Source Path", "*.xml", commandBody.getExcludePattern());
    }
    
    
    @Test
    public void testGetInputFileName() {
         assertEquals("Validating Source Path", "test.txt", commandBody.getInputFileName());
    }
    
    
    @Test
    public void testGetOutputFileName() {
         assertEquals("Validating Source Path", "test.txt", commandBody.getOutputFileName());
    }
    
    
    @Test
    public void testGetTimestampFormat() {
         assertEquals("Validating Source Path", "TS1", commandBody.getTimestampFormat());
    }
    
    @Test
    public void testGetTimestampAsPartOfFile() {
         assertEquals("Validating Source Path", true, commandBody.isTimestampAsPartOfFile());
    }
    
    public void testGetArchive() {
        assertEquals("Validating Source Path", true, commandBody.isArchive());
   }
   
   @Test
   public void testGetCreate() {
        assertEquals("Validating Source Path", false, commandBody.isCreate());
   }
   
   @Test
   public void testGetFileLocking() {
        assertEquals("Validating Source Path", false, commandBody.isFileLocking());
   }
   
   
   @Test
   public void testGetRegion() {
        assertEquals("Validating Source Path", "APAC", commandBody.getRegion());
   }
   
   
   @Test
   public void testGetVolume() {
        assertEquals("Validating Source Path", "Average", commandBody.getVolume());
   }
   
   
   @Test
   public void testGetSize() {
        assertEquals("Validating Source Path", "Average", commandBody.getSize());
   }
   
   
   @Test
   public void testGetRitmNumber() {
        assertEquals("Validating Source Path", "RITMtest", commandBody.getRitmNumber());
   }
   
   @Test
   public void testGetEnvironment() {
        assertEquals("Validating Source Path", MFTEnvironment.FUT, commandBody.getEnvironment());
   }

}
