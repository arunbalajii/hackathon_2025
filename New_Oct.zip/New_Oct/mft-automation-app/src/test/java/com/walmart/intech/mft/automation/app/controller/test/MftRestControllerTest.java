package com.walmart.intech.mft.automation.app.controller.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.intech.mft.automation.app.controller.MftRestController;
import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.processor.RunRemoteCommand;
import com.walmart.intech.mft.automation.app.util.ApiService;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;


@RunWith(SpringRunner.class)
public class MftRestControllerTest {
	
	private CommandBody commandBody;
	
	@InjectMocks
	MftRestController                mftRestController;
	
	@Mock
	private ApiService apiService;
	
	@Mock
	private RunRemoteCommand runRmtCmd;
	
	@Test
	 public void testPostCommandSuccess() throws Exception {
		buildCommandBody();
		given(apiService.validateScenario(commandBody)).willReturn(true);
		ResponseEntity<String> response = mftRestController.postCommand(commandBody);
        assertEquals("Request to create monitor on the region-environment servers is in progress", (response.getBody()));
	}
	
	@Test
	 public void testPostCommandFailure() throws Exception {
		buildCommandBody();
		given(apiService.validateScenario(commandBody)).willReturn(false);
		ResponseEntity<String> response = mftRestController.postCommand(commandBody);
       assertEquals("Interface not configured in Stronghold with provided 3 key fields", (response.getBody()));
	}
	
	private void buildCommandBody() {
		commandBody = new CommandBody();
		commandBody.setSourcePath("sourcePath");
		commandBody.setTargetPath("targetPath");
		commandBody.setUser("testUser");
		commandBody.setMonitorType(MonitorType.FTF);
		commandBody.setScenarioName("testScenario");
		commandBody.setCountryCode("WW");
		commandBody.setInstanceId("1");
		commandBody.setFilePattern("*.txt");
		commandBody.setTriggerPattern("*.trg");
		commandBody.setInputFileName("test.txt");
		commandBody.setOutputFileName("test.txt");
		commandBody.setTimestampFormat("TS1");
		commandBody.setTimestampAsPartOfFile(true);
		commandBody.setArchive(true);
		commandBody.setCreate(false);
		commandBody.setFileLocking(false);
		commandBody.setRegion("APAC");
		commandBody.setVolume("Average");
		commandBody.setSize("Average");
		commandBody.setRitmNumber("RITMtest");
		commandBody.setEnvironment(MFTEnvironment.FUT);
	}
	

}
