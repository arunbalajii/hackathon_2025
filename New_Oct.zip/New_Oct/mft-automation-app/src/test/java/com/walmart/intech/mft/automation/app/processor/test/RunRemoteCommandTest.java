package com.walmart.intech.mft.automation.app.processor.test;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.processor.RunRemoteCommand;
import com.walmart.intech.mft.automation.app.processor.XMLConfigGenerator;
import com.walmart.intech.mft.automation.app.util.MftUtil;
import com.walmart.intech.mft.automation.commons.models.AgentDetail;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;
import com.walmart.intech.mft.automation.commons.models.RegionClusters.Cluster;
import com.walmart.intech.mft.automation.commons.services.AgentService;
import com.walmart.intech.mft.automation.commons.services.CommandService;
import com.walmart.intech.mft.automation.commons.services.FileService;
import com.walmart.intech.mft.automation.commons.services.RegionService;

@RunWith(SpringRunner.class)
public class RunRemoteCommandTest {

	@InjectMocks
	RunRemoteCommand runRemoteCommand;

	@Mock
	RegionService mftServerService;
	@Mock
	AgentDetail agentDetail;
	@Mock
	AgentService agentService;
	@Mock
	CommandService commandService;
	@Mock
	XMLConfigGenerator xmlConfigGenerator;
	@Mock
	FileService fileService;
	@Mock
	MftUtil mftUtil;

	private CommandBody commandBody;

	@Test
	public void testrunFTFForRegionSuccess() {
		try {
			Map<String, Integer> agentMapping = new HashMap<>();
			agentMapping.put("agent1", 50);
			Map<String, String> xmlMapping = new HashMap<>();
			xmlMapping.put("xml", "xml");
			buildCommandBody();
			Mockito.when(mftServerService.getRemoteServers(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList(new Cluster("server", "qmgr", "cluster")));
			Mockito.when(agentService.getAgentDetail(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(new AgentDetail("_", "Average", "Average", 50));
			Mockito.when(agentService.agentNameLookup(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList("agent1"));
			Mockito.when(agentService.agentJsonToMap()).thenReturn(agentMapping);
			Mockito.when(xmlConfigGenerator.getXmlAsString(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(xmlMapping);
			runRemoteCommand.runFTFForRegion(commandBody);
			assertTrue(true);
		} catch (Exception e) {
			assertTrue(false);
		}
	}

	@Test
	public void testrunFTFForRegionSuccessPROD() {
		try {
			Map<String, Integer> agentMapping = new HashMap<>();
			agentMapping.put("agent1", 50);
			Map<String, String> xmlMapping = new HashMap<>();
			xmlMapping.put("xml", "xml");
			buildCommandBody();
			commandBody.setEnvironment(MFTEnvironment.PROD);
			Mockito.when(mftServerService.getRemoteServers(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList(new Cluster("server", "qmgr", "cluster")));
			Mockito.when(agentService.getAgentDetail(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(new AgentDetail("_", "Average", "Average", 50));
			Mockito.when(agentService.agentNameLookup(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList("agent1"));
			Mockito.when(agentService.agentJsonToMap()).thenReturn(agentMapping);
			Mockito.when(xmlConfigGenerator.getXmlAsString(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(xmlMapping);
			runRemoteCommand.runFTFForRegion(commandBody);
			assertTrue(true);
		} catch (Exception e) {
			assertTrue(false);
		}
	}

	@Test
	public void testrunFTFForRegionSuccessFileLocking() {
		try {
			Map<String, Integer> agentMapping = new HashMap<>();
			agentMapping.put("agent1", 50);
			Map<String, String> xmlMapping = new HashMap<>();
			xmlMapping.put("xml", "xml");
			buildCommandBody();
			commandBody.setFileLocking(true);
			Mockito.when(mftServerService.getRemoteServers(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList(new Cluster("server", "qmgr", "cluster")));
			Mockito.when(agentService.getAgentDetail(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(new AgentDetail("_", "Average", "Average", 50));
			Mockito.when(agentService.agentNameLookup(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList("agent1"));
			Mockito.when(agentService.agentJsonToMap()).thenReturn(agentMapping);
			Mockito.when(xmlConfigGenerator.getXmlAsString(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(xmlMapping);
			runRemoteCommand.runFTFForRegion(commandBody);
			assertTrue(true);
		} catch (Exception e) {
			assertTrue(false);
		}
	}

	@Test
	public void testrunFTFForRegionSuccessException() {
		try {
			Map<String, Integer> agentMapping = new HashMap<>();
			agentMapping.put("agent2", 50);
			Map<String, String> xmlMapping = new HashMap<>();
			xmlMapping.put("xml", "xml");
			buildCommandBody();
			commandBody.setFileLocking(true);
			Mockito.when(mftServerService.getRemoteServers(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList(new Cluster("server", "qmgr", "cluster")));
			Mockito.when(agentService.getAgentDetail(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(new AgentDetail(".", "Average", "Average", 50));
			Mockito.when(agentService.agentNameLookup(Mockito.anyString(), Mockito.any()))
					.thenReturn(Arrays.asList("agent1"));
			Mockito.when(agentService.agentJsonToMap()).thenReturn(agentMapping);
			Mockito.when(xmlConfigGenerator.getXmlAsString(Mockito.any(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(xmlMapping);
			runRemoteCommand.runFTFForRegion(commandBody);
			assertTrue(true);
		} catch (Exception e) {
			assertTrue(false);
		}
	}

	private void buildCommandBody() {
		commandBody = new CommandBody();
		commandBody.setSourcePath("sourcePath");
		commandBody.setTargetPath("targetPath");
		commandBody.setUser("testUser");
		commandBody.setMonitorType(MonitorType.FTF);
		commandBody.setScenarioName("testScenario");
		commandBody.setCountryCode("WW");
		commandBody.setInstanceId("1");
		commandBody.setFilePattern("*.txt");
		commandBody.setTriggerPattern("*.trg");
		commandBody.setInputFileName("test.txt");
		commandBody.setOutputFileName("test.txt");
		commandBody.setTimestampFormat("TS1");
		commandBody.setTimestampAsPartOfFile(true);
		commandBody.setArchive(true);
		commandBody.setCreate(false);
		commandBody.setFileLocking(false);
		commandBody.setRegion("APAC");
		commandBody.setVolume("Average");
		commandBody.setSize("Average");
		commandBody.setRitmNumber("RITMtest");
		commandBody.setEnvironment(MFTEnvironment.FUT);
	}

}
