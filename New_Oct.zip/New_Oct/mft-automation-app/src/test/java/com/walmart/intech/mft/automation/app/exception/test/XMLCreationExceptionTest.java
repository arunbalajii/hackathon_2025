package com.walmart.intech.mft.automation.app.exception.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import org.junit.Test;
import org.mockito.Mock;

import com.walmart.intech.mft.automation.app.exception.XMLCreationException;

public class XMLCreationExceptionTest {

	@Mock
	Throwable throwable;

	private XMLCreationException xmlCreationException;

	@Test
	public void testXMLCreationException() throws Exception {
		Constructor<XMLCreationException> constructor = XMLCreationException.class.getDeclaredConstructor();
		assertTrue("Validating TransactionWebAppConstants constructor modifier type",
				Modifier.isPublic(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
		assertTrue("Validating TransactionWebAppConstants constructor", true);
	}

	@Test
	public void testXMLCreationException2() throws Exception {
		xmlCreationException = new XMLCreationException("Failed to create xml");
		assertEquals("Failed to create xml", xmlCreationException.getMessage());
	}

	@Test
	public void testXMLCreationException3() throws Exception {
		xmlCreationException = new XMLCreationException(throwable);
		assertTrue(true);
	}

	@Test
	public void testXMLCreationException4() throws Exception {
		xmlCreationException = new XMLCreationException("Failed to create xml", throwable);
		assertEquals("Failed to create xml", xmlCreationException.getMessage());
	}

}
