package com.walmart.intech.mft.automation.app.config.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.UserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.test.context.junit4.SpringRunner;
import com.walmart.intech.mft.automation.app.config.WebSecurityConfig;
import com.walmart.intech.mft.automation.commons.config.RemoteServerConfig;
import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SuppressWarnings({"rawtypes", "unchecked"})
public class WebSecurityConfigTest{

	@InjectMocks
    private WebSecurityConfig webSecurityConfig;
	
	@Mock
	 AuthenticationManagerBuilder authenticationManagerBuilder;
	
	@Mock
	 InMemoryUserDetailsManagerConfigurer inMemoryUserDetailsManagerConfigurer;
	
	@Mock
	private RemoteServerConfig remoteServerConfig;
	
	@Mock
    private HttpSecurity httpSecurity;
	
    @Test
    public void configureTestSuccess() {
        try {
        	given(remoteServerConfig.getUser()).willReturn("User");
        	given(remoteServerConfig.getBasicAuthCred()).willReturn("Password");
            given(authenticationManagerBuilder.inMemoryAuthentication()).willReturn(inMemoryUserDetailsManagerConfigurer);
            UserDetailsManagerConfigurer.UserDetailsBuilder userDetailsManagerConfigurer = Mockito
                    .mock(UserDetailsManagerConfigurer.UserDetailsBuilder.class);
            Mockito.when(inMemoryUserDetailsManagerConfigurer.withUser(Mockito.anyString())).thenReturn(userDetailsManagerConfigurer);
            Mockito.when(userDetailsManagerConfigurer.password(Mockito.anyString())).thenReturn(userDetailsManagerConfigurer);
            webSecurityConfig.configure(authenticationManagerBuilder);
            assertTrue(true);
        }
        catch (Exception exception) {
            assertTrue(false);
        }
    }
    
    @Test
    public void configureTestFailure() {
    	try {
    		given(remoteServerConfig.getUser()).willReturn("User");
    		given(remoteServerConfig.getBasicAuthCred()).willReturn("Password");
    		webSecurityConfig.configure(authenticationManagerBuilder);
    		assertTrue(false);
    	}
    	catch (Exception exception) {
    		assertTrue(true);
    	}
    }

}
