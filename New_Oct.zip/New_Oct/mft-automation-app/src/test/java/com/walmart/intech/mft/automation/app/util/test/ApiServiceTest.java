package com.walmart.intech.mft.automation.app.util.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import static org.mockito.ArgumentMatchers.eq;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.walmart.intech.mft.automation.app.model.CommandBody;
import com.walmart.intech.mft.automation.app.util.ApiService;
import com.walmart.intech.mft.automation.commons.config.RemoteServerConfig;
import com.walmart.intech.mft.automation.commons.models.MFTEnvironment;
import com.walmart.intech.mft.automation.commons.models.MonitorType;

@RunWith(SpringRunner.class)
public class ApiServiceTest {
	  
	@InjectMocks
	ApiService apiService;
	
	@Mock
    private RestTemplate restTemplate;
	@Mock
	Environment env;
	@Mock
	RemoteServerConfig remoteServerConfig;
	
	private CommandBody commandBody;
	boolean result;

	@Test
	 public void testPostCommandSuccess() throws Exception {
			buildCommandBody();
	        ResponseEntity<String> myEntity = new ResponseEntity<String>(HttpStatus.OK);
	        Mockito.when(remoteServerConfig.getValidationUri()).thenReturn("url");
	        Mockito.when(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.GET), Mockito.<HttpEntity<String>> any(),
                    eq(String.class)))
	             .thenReturn(myEntity);
			result=apiService.validateScenario(commandBody);
			assertTrue(result);
	}
	
	@Test
	 public void testPostCommandFailure() throws Exception {
			buildCommandBody();
	        ResponseEntity<String> myEntity = new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
	        Mockito.when(remoteServerConfig.getValidationUri()).thenReturn("url");
	        Mockito.when(restTemplate.exchange(Mockito.anyString(), eq(HttpMethod.GET), Mockito.<HttpEntity<String>> any(),
                   eq(String.class)))
	             .thenReturn(myEntity);
			result=apiService.validateScenario(commandBody);
			assertFalse(result);
	}
	
	private void buildCommandBody() {
		commandBody = new CommandBody();
		commandBody.setSourcePath("sourcePath");
		commandBody.setTargetPath("targetPath");
		commandBody.setUser("testUser");
		commandBody.setMonitorType(MonitorType.FTF);
		commandBody.setScenarioName("testScenario");
		commandBody.setCountryCode("WW");
		commandBody.setInstanceId("1");
		commandBody.setFilePattern("*.txt");
		commandBody.setTriggerPattern("*.trg");
		commandBody.setInputFileName("test.txt");
		commandBody.setOutputFileName("test.txt");
		commandBody.setTimestampFormat("TS1");
		commandBody.setTimestampAsPartOfFile(true);
		commandBody.setArchive(true);
		commandBody.setCreate(false);
		commandBody.setFileLocking(false);
		commandBody.setRegion("APAC");
		commandBody.setVolume("Average");
		commandBody.setSize("Average");
		commandBody.setRitmNumber("RITMtest");
		commandBody.setEnvironment(MFTEnvironment.FUT);
	}
}
