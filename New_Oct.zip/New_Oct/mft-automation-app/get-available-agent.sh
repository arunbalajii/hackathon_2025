#!/bin/ksh

region=$(echo $1 | tr 'a-z' 'A-Z')

if [ $# -eq 0 ]
  then
    echo "Insufficient args, usage: scriptName [region]"
    exit 128
fi

MONITOR_COUNT=45

fileMonitorPath=/opt/mqm/bin
agentPrefix=AG_LO_$region
agent_json_file=agent.json.tmp
agent_kv_file=agent.out.tmp

echo "Region: $region, Agent pefix : $agentPrefix"

#agents=( `/opt/mqm/bin/fteListMonitors -ma AG_LO_APAC_* | grep -i "AG_LO_APAC_" | awk '/^AG_LO_APAC_/ {print $1}' | sort -u` )

agents=( $($fileMonitorPath/fteListMonitors -ma ${agentPrefix}_* | grep -i "${agentPrefix}" | awk '/^'${agentPrefix}'/ {print $1}' | sort -u) )

whoami
#declare -A agentsMonitors

getAgentsCountAsKeyValue() {
  touch $agent_kv_file
  printf "" > $agent_kv_file
  for agent in ${agents[*]}; do
      monitorCount=$(/opt/mqm/bin/fteListMonitors -ma $agent | grep -i $agent | wc -l)
      echo "Agent : $agent Count: $monitorCount"
      printf '%s:%d\n' "$agent" "$monitorCount" >> $agent_kv_file

  done;
}



getAgentsCountAsJson() {
  printf "{" > $agent_json_file
  for agent in ${agents[*]}; do
      monitorCount=$(/opt/mqm/bin/fteListMonitors -ma $agent | grep -i $agent | wc -l)
      echo "Agent : $agent Count: $monitorCount"
      echo "" >> $agent_json_file
      printf '\"%s\": %d,' "$agent" "$monitorCount" >> $agent_json_file
  done;
  truncate -s -1 $agent_json_file

  echo "" >> $agent_json_file
  echo "}" >> $agent_json_file
}

getAgentsCountAsJson
getAgentsCountAsKeyValue

echo "Monitors JSON: $(cat $agent_json_file)"
echo "Monitors KV: $(cat $agent_kv_file)"


cp $agent_json_file agent.json
cp $agent_kv_file agent.out