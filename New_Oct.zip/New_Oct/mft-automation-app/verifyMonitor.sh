#!/bin/ksh

monitorname=$1
ftfStageLogFile=/tmp/ftf.log


if [ $# -lt 1 ]
  then
    echo "Insufficient args : Usage scriptName [monitorname]"
    exit 128
fi

check_exitStatus() {
  exitStatus=$?
  #set -o history -o histexpand
  if [ $exitStatus -ne 0 ]
  then
    echo "cmd:$*::exitStatus:$exitStatus" | tee -a $ftfStageLogFile
    removeXmlFile
    exit 1
  fi
}

listMonitorOut="$(/opt/mqm/bin/fteListMonitors -mn $monitorname -v| awk 'NR>2')"

if echo $listMonitorOut | grep -iqF "Monitor Information";
  then
     echo "$listMonitorOut"
     echo "exitStatus:0"
elif echo $listMonitorOut | grep -iqF "No monitors exist";
  then
     echo "Monitor not found" 2>&1 | tee -a  $ftfStageLogFile
     echo "exitStatus:1" 2>&1 | tee -a $ftfStageLogFile
else
     echo "Error creating monitor" 2>&1 | tee -a  $ftfStageLogFile
     echo "exitStatus:1" 2>&1 | tee -a $ftfStageLogFile
fi









