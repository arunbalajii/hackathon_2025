#!/bin/ksh

region=$(echo $1 | tr 'a-z' 'A-Z')
src_dir=$2
dst_dir=$3
xmlFileName=$4
jiraTicketNo=$5
#maxMonitors=$5
#uuid=$6

agentCountPath="/tmp/agent.out"
ftfStageLogFile="/tmp/ftf.log"
xmlTempConfigPath=/tmp/configs
xmlConfigPath=/u/mft_app/mft_automation/mft_monitors


#echo "Total args: $#"

if [ $# -lt 3 ]
  then
    echo "Insufficient args : Usage scriptName [region] [src_dir] [dst_dir]"
    exit 128
fi


check_exitStatus() {
  exitStatus=$?
  #set -o history -o histexpand
  if [ $exitStatus -ne 0 ]
  then
    echo "cmd:$*::exitStatus:$exitStatus" | tee -a $ftfStageLogFile
    removeXmlFile
    exit 1
  fi
}

removeXmlFile() {
   if [ -e $xmlTempConfigPath/$xmlFileName ]
    then
      rm $xmlTempConfigPath/$xmlFileName
  fi
}


mkdir $src_dir  && mkdir $dst_dir  && echo "Created directories $src_dir && $dst_dir" | tee -a $ftfStageLogFile
check_exitStatus "mkdir" $src_dir $dst_dir

chmod 2770 -R $src_dir $dst_dir  && echo "Modified permissions on directories $src_dir && $dst_dir" | tee -a $ftfStageLogFile
check_exitStatus "chmod" $src_dir $dst_dir

mkdir -p $xmlConfigPath && mkdir -p $xmlTempConfigPath && echo "Created temp directories $xmlConfigPath && $xmlTempConfigPath"  | tee -a $ftfStageLogFile
chmod 777 $xmlConfigPath $xmlTempConfigPath
mv $xmlTempConfigPath/$xmlFileName $xmlConfigPath/$xmlFileName  && echo "Moved file from $xmlTempConfigPath/$xmlFileName to $xmlConfigPath/$xmlFileName"  | tee -a $ftfStageLogFile
check_exitStatus "mv" "$xmlTempConfigPath/$xmlFileName" "$xmlConfigPath/$xmlFileName"
removeXmlFile

echo "exitStatus:0"
