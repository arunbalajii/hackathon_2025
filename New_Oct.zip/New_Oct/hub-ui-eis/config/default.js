'use strict';

const defaultListenPort = 3000;

const portFromEnv = () => {
  const x = parseInt(process.env.APP_SERVER_PORT || process.env.PORT, 10);
  return x !== null && !isNaN(x) ? x : defaultListenPort;
};

module.exports = {
  connection: {
    host: process.env.HOST,
    address: process.env.HOST_IP || '0.0.0.0',
    port: portFromEnv(),
    routes: {
      cors: false,
    },
    state: {
      ignoreErrors: true,
    },
  },
  plugins: {
    '@fastify/auth': {
      enable: true,
      priority: -101,
    },
    '@gtpjs/sso-pingfed': {
      enable: true,
      priority: -100,
      options: {
        httpOnlyCookie: true,
        sslCaCert: false,
        verificationStrategy: 'local',
        preemptiveTokenRefreshThreshold: 14,
        cookieNames: {
          accessToken: 'hub-ping',
          destination: 'hub-ping-dest',
          refreshToken: 'hub-ping-refresh',
          additionalInfo: 'hub-userInfo',
        },
      },
    },
    '@hub/dxconsole-plugin': {
      enable: true,
      priority: 1,
      options: {
        prefix: '/resources',
      },
    },
    '@xarc/app-dev': {
      priority: -1,
      enable: process.env.WEBPACK_DEV_MIDDLEWARE === 'true' && process.env.WEBPACK_DEV === 'true',
    },
    // Disable WalmartLabs CCM for now to avoid noises and confusion
    '@walmart/electrode-ccm-initializer': {
      enable: false,
    },
    'subapp-server': {
      enable: true,
    },
    '@walmart/electrode-on-docker': {},
    '@walmart/electrode-prometheus': {
      priority: -1000,
      options: {
        tagFormat: 'openTelemetry',
      },
    },
    '@walmart/electrode-metrics': {
      options: {
        serializers: {
          response: (request, data) => {
            return { ...data, endpoint: request.routeOptions.url };
          },
        },
      },
    },
    '@walmart/electrode-log-consumer': {
      enable: true,
      priority: -9999,
    },
  },
  ui: {
    SLACK_BASE_URL: 'https://walmart.slack.com',
  },
  logging: {
    verbose: false,
    transports: [
      {
        type: 'stdout',
        default: true,
        level: 'info',
      },
    ],
    serializers: {
      err: (data) => {
        return data;
      },
    },
  },
};
