'use strict';

module.exports = {
  plugins: {
    'mock-server': {
      module: './{{env.APP_SRC_DIR}}/server/mock-server',
    },
    '@gtpjs/sso-pingfed': {
      options: {
        authSource: process.env['HOME'] + '/vault/pingfed.conf',
        env: 'stg',
        redirect: {
          protocol: 'https',
          host: 'dev.walmart.com',
          port: '',
          path: '/loggedin',
        },
        logout: {
          protocol: 'https',
          host: 'dev.walmart.com',
          port: '',
          path: '/logout',
        },
      },
    },
    '@hub/dxconsole-plugin': {
      options: {
        hubCommonEnv: 'STAGE',
        proxyEndpoints: [
          {
            clientPath: '/proxy/eis',
            remoteProtocol: 'http',
            remoteHost: 'localhost:9000',
            remotePath: '/mocks',
          },
          {
            clientPath: '/common/api/products/eis/feature',
            remoteProtocol: 'http',
            remoteHost: 'localhost:9000',
            remotePath: '/mocks/feature',
          },
          {
            clientPath: '/proxy/eis/automation',
            remoteProtocol: 'https',
            remoteHost: 'mft-automation-app-dev.mft-automation.k8s.glb.us.walmart.net',
            remotePath: '/api/v1',
          },
        ],
      },
    },
  },
};
