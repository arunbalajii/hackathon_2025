'use strict';
const { loadDevTasks, xrun } = require('@xarc/app-dev');
const { loadWmlBuildTasks } = require('@walmart/electrode-build-utils');
exports.xrun = xrun;

xrun.updateEnv(
  {
    APP_SERVER_PORT: 9000,
    HOST: 'dev.walmart.com',
    XARC_DEV_HTTPS: process.env.PORT,
    PORT: 8000,
  },
  {
    // avoid setting values that already exist in process.env
    override: true,
  }
);

const deps = require('./package.json').dependencies;

const remoteSubappConfig = {
  name: 'hub-ui-eis',
  subAppsToExpose: ['Eis'],
  shared: {
    '@ant-design/icons': {
      import: false,
      singleton: true,
      requiredVersion: deps['@ant-design/icons'],
    },
    '@hub/ui-lib': {
      import: false,
      singleton: true,
      requiredVersion: deps['@hub/ui-lib'],
    },
    antd: {
      import: false,
      singleton: true,
      requiredVersion: deps.antd,
    },
    axios: {
      import: false,
      singleton: true,
      requiredVersion: deps.axios,
    },
    react: {
      import: false,
      singleton: true,
      requiredVersion: deps.react,
    },
    'react-dom': {
      import: false,
      singleton: true,
      requiredVersion: deps['react-dom'],
    },
    'react-redux': {
      import: false,
      singleton: true,
      requiredVersion: deps['react-redux'],
    },
    'subapp-web': {
      import: false,
      singleton: true,
      requiredVersion: deps['subapp-web'],
    },
    'styled-components': {
      import: false,
      singleton: true,
      requiredVersion: deps['styled-components'],
    },
  },
};

loadDevTasks(xrun, {
  webpackOptions: {
    devtool: 'inline-source-map',
    useAppWebpackConfig: false,
    cssModuleSupport: false,
    v1RemoteSubApps: process.env.LOCAL ? null : remoteSubappConfig,
  },
});

require('@walmart/electrode-build-utils');

xrun.load('electrode', {
  webpackOptions: {
    useAppWebpackConfig: true,
    cssModuleSupport: false,
    v1RemoteSubApps: remoteSubappConfig,
  },
  'build-lib:all': xrun.concurrent('compile-dev', 'compile-node'),
  'compile-dev': xrun.exec(
    'babel src -d dist --copy-files --no-copy-ignored --delete-dir-on-start --config-file=./babelrc-subapp --source-maps --verbose',
    {
      env: { BABEL_ENV: '-src-dev' },
    }
  ),
  'compile-node': xrun.exec(
    'babel src -d lib --copy-files --no-copy-ignored --delete-dir-on-start --config-file=./babelrc-subapp --source-maps --verbose',
    {
      env: { BABEL_ENV: '-src-node' },
    }
  ),
});

//loading wml tasks for publishing
loadWmlBuildTasks(xrun);
