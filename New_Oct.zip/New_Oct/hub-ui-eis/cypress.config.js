const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'https://dev.walmart.com',
    setupNodeEvents(on, config) {
      // implement node event listeners here
      require('@cypress/grep/src/plugin')(config);
      require('@cypress/code-coverage/task')(on, config);
      
      return config;
    },
  },
  chromeWebSecurity: false,
  viewportWidth: 1440,
  viewportHeight: 900,
});
