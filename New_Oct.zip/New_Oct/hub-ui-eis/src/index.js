/**
 * Manifest file for microsite
 * This is needed to expose microsite to the main host app (strati-hub-app)
 */
export const subAppOptions = {
  serverSideRendering: false,
};

export const manifest = {
  type: 'app',
  name: 'Eis',
  entry: require.resolve('./eis/subapp-eis'),
};
