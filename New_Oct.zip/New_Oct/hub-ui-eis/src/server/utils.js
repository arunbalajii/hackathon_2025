'use strict';

module.exports = {
  getUserDetailsFromSSO: (creds) => {
    if (!creds) {
      return null;
    }
    let { name = '', email = '', loginId = '', userid = '', sub = '' } = creds;
    const loginIdArr = loginId && loginId.split('\\');
    if (loginIdArr && loginIdArr.length === 2) {
      loginId = loginIdArr[1];
    }
    return { name, email, loginId, userid, sub };
  },
};
