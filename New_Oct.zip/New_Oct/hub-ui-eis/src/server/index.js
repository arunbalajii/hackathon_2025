'use strict';

const { loadRuntimeSupport } = require('@xarc/app');
const { wmlServerFastify } = require('@walmart/wml-server-fastify');
const config = require('@walmart/electrode-config').config;

async function start() {
  const supportOpts = {};

  // Load run time support for application
  await loadRuntimeSupport(supportOpts);

  // It's recommended to access electrodeConfig.config here
  // rather than on the root level of this file because
  // it triggers loading the config files.
  let server;
  try {
    server = await wmlServerFastify(config);
  } catch (err) {
    console.error('Start server failed', err.stack);
    process.exit(1);
  }

  return server;
}

start();
