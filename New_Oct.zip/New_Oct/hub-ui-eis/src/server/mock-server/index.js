'use strict';

module.exports = {
  name: 'mock-server',
  version: '1.0.0',
  register: async (server) => {
    /**
     * API for fetching eis list based on mock data. Allows for
     * experimenting with the Resource List page before you have set up a real API with real data
     */
    server.route({
      method: ['get', 'post'],
      path: '/mocks/eis',
      handler: async (_req, reply) => {
        const resp = require('./mocks/resource-list.json');
        await reply.code(200).send(resp);
      },
    });

    /**
     * API for fetching eis details based on mock data. Allows for
     * experimenting with the Resource Details page before you have set up a real API with real data
     */
    server.route({
      method: ['get', 'post', 'put', 'delete'],
      path: '/mocks/eis/:resourceId',
      handler: async (req, reply) => {
        let resp = require('./mocks/resource-details.json');
        resp.detail.name = req.params.resourceId;
        await reply.code(200).send(resp);
      },
    });

    /**
     * API for fetching mocked out feature flags. Allows for experimenting with feature flags before
     * defining them on your product through DX Console Control Center
     */
    server.route({
      method: ['get', 'post', 'put', 'delete'],
      path: '/mocks/feature',
      handler: async (_req, reply) => {
        let resp = require('./mocks/feature.json');
        await reply.code(200).send(resp);
      },
    });
  },
};
