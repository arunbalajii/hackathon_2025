import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { React } from 'subapp-react';
import {
  BannerContainer,
  fetchUserPreferences,
  fetchUserSettings,
  getUserDetails,
  Header,
  RefreshModal,
  setCurrentProduct,
  setFeatures,
  setUser,
  setUserPreferences,
  useSessionValid,
  errorLogger,
} from '@hub/ui-lib';

import { fetchFeatures } from './utils';
import hubLogo from './hub-logo.svg';
import { routesConfig } from '../common/Routes';

const Main = () => {
  const dispatch = useDispatch();
  const { name: username } = getUserDetails();
  const productId = getProductIdByPath();

  useEffect(() => {
    fetchUserSettings().then((user) => dispatch(setUser(user)));
  }, []);

  useEffect(() => {
    fetchUserPreferences().then((pref) => dispatch(setUserPreferences(pref)));
  }, []);

  useEffect(() => {
    fetchAndSetCurrentProduct();
    fetchAndSetFeatures();
  }, [productId]);

  function fetchAndSetCurrentProduct() {
    // automatically fetch product info according to current path.
    getCurrentProductById(productId).then(
      (product) =>
        // set only when found. Do not set a default value -- that'll override other subapp's Ad Hoc settings.
        // default value should be handled when needed.
        product.id !== undefined && dispatch(setCurrentProduct(product))
    );
  }

  function fetchAndSetFeatures() {
    fetchFeatures(productId).then((features) => dispatch(setFeatures(features)));
  }

  const headerProps = {
    hasLogin: true,
    branding: {
      link: '/',
      img: hubLogo,
      logoHeight: 30,
    },
    navItems: [],
    username,
    portalId: productId,
  };

  return (
    <div>
      <Header {...headerProps} />
      <BannerContainer portalId={productId} />
    </div>
  );
};

function getProductIdByPath() {
  const pathParts = window.location.pathname.split('/');
  if (pathParts.length >= 2) {
    const productFromPath = pathParts[1];
    const subapp = Object.keys(routesConfig).find((subapp) => {
      let productFromConfig = routesConfig[subapp].path;
      if (productFromConfig && productFromConfig.startsWith('/')) {
        productFromConfig = productFromConfig.substr(1);
      }
      return productFromPath.toLowerCase() === productFromConfig.toLowerCase();
    });
    return subapp && routesConfig[subapp].productId;
  }
  return undefined;
}

async function getCurrentProductById(productId) {
  let product = {};
  if (productId) {
    try {
      const response = await axios.get(`/common/api/products/${productId}`);
      product = response['data'];
    } catch (err) {
      errorLogger(
        `Error fetching product config for ${productId}`,
        err,
        null,
        `/common/api/products/${productId}`,
        'hub-ui-eis'
      );
    }
  }
  return product;
}

export const App = (props) => {
  const isSessionValid = useSessionValid(useLocation());
  // If the current session is invalid, this would automatically pop-up refresh modal and refreshes the page
  if (!isSessionValid) {
    return <RefreshModal />;
  }

  return <Main {...props} />;
};
