import axios from 'axios';
import intersection from 'lodash/intersection';

export function fetchFeatures(productId) {
  return Promise.all([
    // Get site-wide features
    axios
      .get(`/common/api/products/platform-hub/feature`)
      .then((response) => response.data)
      .catch((e) => {
        console.error('ERROR: fetching site-wide features');
        console.error(e);
      }),
    // Get features for current product
    productId !== undefined && productId !== null
      ? axios
          .get(`/common/api/products/${productId}/feature`)
          .then((response) => response.data)
          .catch((e) => {
            console.error('ERROR: fetching features for ' + productId);
            console.error(e);
          })
      : null,
  ]).then(([siteWideFeatures, productFeatures]) => {
    // Combine site-wide features and product features into site-wide namespace, allowing product
    // specific features with the same key to override site-wide ones. But also put product features
    // under their own namespace so that individual products can safely reference their features
    // independent of if there is a site-wide flag that happens to have the same key

    const siteWideFeatureKeys = siteWideFeatures && Object.keys(siteWideFeatures);
    const productFeatureKeys = productFeatures && Object.keys(productFeatures);
    const siteWideFeatureKeysToOverride = intersection(siteWideFeatureKeys, productFeatureKeys);

    const features = {
      ...siteWideFeatures,
    };

    if (
      productId !== undefined &&
      productId !== null &&
      productFeatures !== undefined &&
      productFeatures !== null
    ) {
      features[productId] = { ...productFeatures };
    }

    siteWideFeatureKeysToOverride.forEach((matchingKey) => {
      if (matchingKey === productId) {
        return; // don't allow overriding product namespace with a feature key
      }
      features[matchingKey] = productFeatures[matchingKey];
    });

    return features;
  });
}
