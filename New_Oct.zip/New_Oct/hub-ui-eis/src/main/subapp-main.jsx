import { getBrowserHistory, React } from 'subapp-react';
import { Router } from 'react-router-dom';
import { reduxLoadSubApp } from 'subapp-redux';
import { GlobalStyles, reduxReducers } from '@hub/ui-lib';
import { App } from './Main';

import 'antd/dist/antd.css';

const combinedReducers = { ...reduxReducers };

export default reduxLoadSubApp({
  name: 'Main',
  Component: App,
  useReactRouter: true,
  reduxReducers: combinedReducers,
  reduxShareStore: true,
  StartComponent: (props) => {
    return (
      <Router history={getBrowserHistory()}>
        <GlobalStyles />
        <App {...props} />
      </Router>
    );
  },
});
