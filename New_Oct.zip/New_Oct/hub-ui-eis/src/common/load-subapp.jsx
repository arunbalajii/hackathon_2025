/**
 * When user navigates from one subapp to other, we need a way to load subapp without impacting SPA experience
 * This utility helps in achieving that SPA experience without reloading the entire page
 *
 * supports "serverSideRendering" and "clientSideRendering"
 *
 * Ideally, this logic should be part of electrodeX framework
 * Once Electrode X has this capability, we should get rid of this functionality here
 **/

import { lazyLoadSubApp, AppContext, xarc } from 'subapp-react';
import React, { Component } from 'react';
import { unmountComponentAtNode } from 'react-dom';

// ssr inline subapp
const SSRSubApp = (props) => {
  return (
    <AppContext.Consumer>
      {({ ssr }) => {
        let __html;
        if (!ssr) {
          __html = `<!-- SSRSubApp did not get ssr from AppContext: ${props.name} -->`;
        } else if (props.dynamic) {
          // everything on SSR is static so we can't handle dynamic render subapp into
          // a DOM element.
          return '';
        } else {
          const xarcInlineSSR = ssr.request.app.xarcInlineSSR;
          const ssrInfo = xarcInlineSSR && xarcInlineSSR[props.name];
          if (ssrInfo) {
            __html = ssrInfo.lib.handleSSRSync();
          } else {
            __html = `<!-- SSRSubApp did not find ssrInfo: ${props.name} -->`;
          }
        }
        
        return <div dangerouslySetInnerHTML={{ __html }} />;
        
      }}
    </AppContext.Consumer>
  );
};
// client side inlining subapp
class ClientSubApp extends Component {
  constructor() {
    super();
    this.state = { ready: false };
  }
  componentWillUnmount() {
    if (this.elementId) {
      const el = window.document.getElementById(this.elementId);
      if (el) {
        unmountComponentAtNode(el);
      }
    }
  }
  render() {
    const { name, group } = this.props;
    const onLoad = () => this.setState({ ready: true });
    const subapp = xarc.getSubApp(name);
    if (this.props.dynamic) {
      // dynamic means we will create a DOM element with an id for the subapp to render itself into later
      if (!this.elementId) {
        this.elementId = Math.random().toString();
      }
      lazyLoadSubApp({ id: this.elementId, group, name, onLoad });
      let fallback;
      if (subapp && xarc.getBundle(name)) {
        fallback = '';
      } else {
        // TODO: figure out why react.render doesn't remove the fallback content
        // and what's the solution
        fallback = '';
        // fallback = this.props.fallback || `wait for render from subapp ${name}`;
      }
      // if not, return loadingComponent
      return <div id={this.elementId}>{fallback}</div>;
    } else {
      // the subapp should return its component to us to be directly rendered into the component tree
      if (subapp && xarc.getBundle(name)) {
        // subapp instantiated and bundle available, directly execute it to get its component
        // for the component tree.
        return subapp.inline({ group, props: this.props });
      }
      lazyLoadSubApp({ group, name, onLoad });
      // if not, return loadingComponent
      return this.props.fallback || <div>loading bundle for subapp {name}</div>;
    }
  }
}
export default xarc.IS_BROWSER ? ClientSubApp : SSRSubApp;
