/**
 * Defines all subapp routes
 * These routes are needed when we load one subapp from other subapp
 *
 * Currently, used by "Home" subapp as user can navigate to other subapps from Home
 **/

export const routesConfig = {
  Eis: { path: '/eis', productId: 'eis' },
};
