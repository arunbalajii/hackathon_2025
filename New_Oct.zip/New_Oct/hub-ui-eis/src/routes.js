const Path = require('path');
const electrodeCookies = require('@walmart/electrode-cookies');
const utils = require('./server/utils');

const subAppOptions = {
  serverSideRendering: false,
};

const settings = {
  preHandler: (request, _reply, done) => {
    if (request.auth && request.auth.credentials) {
      const creds = request.auth.credentials;

      let details = {};

      if (
        request.state &&
        request.state['hub-userInfo'] &&
        request.state['hub-userInfo']['basicInfo']
      ) {
        console.log('request.state', request.state);
        details = { ...request.state['hub-userInfo']['basicInfo'] };
      }

      if (!details.loginId && creds) {
        // just need to make sure loginId is there because that is important on client-side
        const usersDetails = utils.getUserDetailsFromSSO(creds);
        details.loginId = usersDetails.loginId;
        details.name = usersDetails.name;
        details.email = usersDetails.email;
      }

      electrodeCookies.set('SSO_CRED', details, { request, secure: true, sameSite: 'Lax' });
    } else if (electrodeCookies.get('SSO_CRED', { request })) {
      electrodeCookies.expire('SSO_CRED');
    }

    done();
  },
};

const tokenHandlers = [Path.join(__dirname, './server/token-handler')];

const subappRouteConfig = {
  pageTitle: 'DX Console | eis',
  subApps: [['./eis', subAppOptions]],
  auth: ['sso-pingfed'],
  templateFile: './server/templates/microsite',
  tokenHandlers,
  settings,
  criticalCSS: Path.join(__dirname, './server/templates/global.css'),
};

export default {
  '/': {
    pageTitle: 'DX Console | Home',
    subApps: [['./home', subAppOptions]],
  },
  // Fastify registration of `<pre-wildcard-path>/*` does not include `<pre-widcard-path>` itself.
  // So we need to register it separately
  '/eis': subappRouteConfig,
  '/eis/*': subappRouteConfig,
};
