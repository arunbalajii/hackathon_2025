import { React, loadSubApp } from 'subapp-react';
import { Footer } from '@hub/ui-lib';

export default loadSubApp({
  name: 'Footer',
  Component: () => {
    return <Footer />;
  },
});
