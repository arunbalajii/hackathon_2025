const product = {
  id: 'eis',
  name: 'eis',
  nickname: 'eis',
};

const resourceConfig = {
  id: 'eis',
  path: 'eis',
  name: 'Eis',
  listName: 'Eis',
};

export const config = {
  product,
  resource: resourceConfig,
};
