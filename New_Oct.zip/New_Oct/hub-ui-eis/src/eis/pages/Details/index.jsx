import React from 'react';
import { EditButton, ResourceDetails } from '@hub/ui-lib';
import { Link } from 'react-router-dom';
import { config } from '../../config';
import { convertFromAPIToDetailsFormat } from './detailsMapping';
import { Tooltip } from 'antd';
import open from '../../../images/open.svg';
import { renderConcordStatus } from '@hub/ui-lib';
import { InfoCircleFilled } from '@ant-design/icons';

const Details = ({ match }) => {
  const resourceId = match && match.params && match.params.id;
  const { product, resource } = config;

  const pageActions = [
    <EditButton
      key='edit-btn'
      resourceId={resourceId}
      product={product}
      resource={resource}
      routerLink={Link}
    />,
  ];

  const breadcrumbs = [
    {
      path: '',
      breadcrumbName: 'Home',
    },
    {
      path: product.id,
      breadcrumbName: product.name,
    },
    {
      path: resource.id,
      breadcrumbName: resource.name,
    },
  ];

  const getEnvironments = (resources) => {
    if (!resources) {
      return null;
    }
    const columns = [
      {
        title: 'Environment',
        key: 'type',
        dataIndex: 'type',
      },
      {
        title: 'Region',
        key: 'region',
        dataIndex: 'region',
      },
      {
        title: 'CPU (Cores)',
        key: 'cores',
        dataIndex: 'cores',
      },
      {
        title: 'Memory (GB)',
        key: 'memory',
        dataIndex: 'memory',
      },
      {
        title: (
          <span>
            Provisioning Status
            <img alt='concord' src={open} className='open' />
            <Tooltip title={'Provisioning process takes about 20-30 mins to complete.'}>
              <InfoCircleFilled />
            </Tooltip>
          </span>
        ),
        dataIndex: 'concordStatus',
        key: 'concordStatus',
        render: (text, record) => renderConcordStatus(text, record),
      },
    ];
    const dataSource =
      resources &&
      resources.map((env) => {
        return Object.assign(
          {
            key: `${env['type']}_${env['region']}`,
          },
          env
        );
      });
    return {
      dataSource,
      columns,
    };
  };

  const props = {
    resourceApiPath: `/proxy/${product.id}/${resource.id}/${resourceId}`,
    resourceId,
    product,
    componentId: resource.id,
    breadcrumbs,
    pageActions,
    getEnvironments,
    routerLink: Link,
    mappingFunc: convertFromAPIToDetailsFormat,
  };

  return <ResourceDetails {...props} />;
};

export default Details;