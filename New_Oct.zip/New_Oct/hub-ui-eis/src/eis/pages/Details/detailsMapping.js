import { ApplicationTiers, WalmartResources } from '@hub/ui-lib';

/**
 * Convert from API payload to structured expected by ResourceDetails component.
 */
export async function convertFromAPIToDetailsFormat(response) {
  const { detail = {}, environments = [] } = response;

  const appTiers = ApplicationTiers();
  const trProductResp = await WalmartResources.findProductById(detail['trProductId']);
  const trProduct =
    trProductResp.status === 'SUCCESS' && trProductResp.data ? trProductResp.data : null;

  const config = {
    emptyMsg: 'Currently there are no details associated with the selection.',
    details: {
      'basic-details': [
        {
          key: 'activeDirectoryGroup',
          label: 'AD Group',
          value: detail['activeDirectoryGroup'],
        },
        {
          key: 'complianceLevel',
          label: 'Compliance',
          value: detail['complianceLevel'],
        },
        {
          key: 'serviceNowGroup',
          label: 'ServiceNow Group',
          value: detail['serviceNowGroup'],
        },
        {
          key: 'srcr',
          label: 'SRCR#',
          value: detail['srcr'],
        },
        {
          key: 'trProduct',
          label: 'Team Rosters Product',
          value: {
            id: detail['trProductId'],
            name: (trProduct && trProduct.name) || detail['trProductId'],
          },
        },
      ],
      'other-details': [
        {
          key: 'distributionEmail',
          label: 'Notification Email',
          value: detail['distributionEmail'],
        },
        {
          key: 'applicationTier',
          label: 'Application Tier',
          value:
            detail['applicationTier'] === undefined
              ? 'N/A'
              : appTiers.findByValue(detail['applicationTier']).label,
        },
        {
          key: 'dataClassification',
          label: 'Data Classification',
          value: detail['dataClassification'],
        },
      ],
    },
    resources: environments,
  };

  return config;
}