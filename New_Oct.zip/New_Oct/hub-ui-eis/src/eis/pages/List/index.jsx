import React from 'react';
import { basicResourceList, ResourceList } from '@hub/ui-lib';
import { config } from '../../config';
import { convertFromAPIToListFormat } from './listMapping';
import { Link } from 'react-router-dom';

const List = () => {
  const { product, resource } = config;

  const list = basicResourceList(product, resource, Link);

  const resourceListConfig = {
    list,
    product,
    resource,
    routerLink: Link,
    intro: 'Intro text can go here...',
    mappingFunc: convertFromAPIToListFormat,
    resourceApiPath: `/proxy/${product.id}/${resource.id}`,
  };
  return <ResourceList config={resourceListConfig} />;
};

export default List;