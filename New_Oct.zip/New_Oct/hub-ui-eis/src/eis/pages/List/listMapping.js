/**
 * Convert from API format to expected List structure
 */
 export function convertFromAPIToListFormat(payload) {
    const listResponse = {
      resources: payload,
    };
    return listResponse;
  }
