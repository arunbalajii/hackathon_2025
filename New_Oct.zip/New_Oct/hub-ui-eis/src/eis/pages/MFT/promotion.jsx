import { BasePage } from '@walmart/gtp-design';
import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import { Input, Typography, Button, Col, Row, Select, Checkbox } from 'antd';
import axios from 'axios';
import { Card, Space } from 'antd';
import { Breadcrumb } from 'antd';

const { Text, Title } = Typography;

const style = {
  column: {
    padding: 10,
  },
  text: {
    marginBottom: 15,
  },
  form: {
    // marginLeft: 50,
    // marginRight: 50,
    border: 1,
    borderColor: 'rgb(4, 31, 65)',
    borderStyle: 'solid',
    borderRadius: 8,
    padding: 40,
  },
};

const Promotion = () => {
  const [gitPath, setGitPath] = useState('');
  const [environment, setEnvironment] = useState('');
  const [scenarioName, setScenarioName] = useState('');
  const [countryCode, setCountryCode] = useState('');
  const [instanceId, setInstanceId] = useState('');
  const [region, setRegion] = useState('');
  const [monitorInstance, setMonitorInstance] = useState('');
  const [sourcePath, setSourcePath] = useState('');
  const [targetPath, setTargetPath] = useState('');
  const [monitorType, setMonitorType] = useState('');

  const submitRequest = async () => {
    const mftFormBody = {
      gitPath: gitPath,
      environment: environment,
      scenarioDetails: {
        scenarioName: scenarioName,
        countryCode: countryCode,
        instanceId: instanceId,
      },
      region: region,
      monitorInstance: monitorInstance,
      sourcePath: sourcePath,
      targetPath: targetPath,
      monitorType: monitorType,
    };

    axios
      .post('/proxy/eis/automation/cmd', mftFormBody)
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        alert(
          'Status: ' +
            error.response.data.status +
            '\nError: ' +
            error.response.data.message +
            '\n\nDetails: ' +
            error.response.data.errors
        );
      });
  };

  return (
    <div>
      {/* <Card style={{width: 1300,}}> */}
      {/* <Breadcrumb>
        <Breadcrumb.Item href='/'> Home </Breadcrumb.Item>
        <Breadcrumb.Item href='/eis'> EIS </Breadcrumb.Item>
        <Breadcrumb.Item> Monitor Promorion </Breadcrumb.Item>
      </Breadcrumb>

      <Row>
        <Col span={15}>
          <Title level={2}> MFT Monitor Promotion</Title>
        </Col>
      </Row> */}
      {/* </Card> */}

      <Card style={{ width: 1300 }}>
        <Row>
          <Col style={style.column} span={24}>
            <Title level={5}>
              Please fill in the required fields below to submit a request to Promote MFT Monitor to
              other environments
            </Title>
            <Row>
              You can refer to this&nbsp;
              <a
                href={
                  'https://confluence.walmart.com/pages/viewpage.action?spaceKey=INIPIT&title=MFT+HA+Integration+Configuration+Guide'
                }
                target='_blank'
              >
                confluence page
              </a>
              &nbsp;for help in placing request:
            </Row>
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={12}>
            <Text strong>Enter the Git Path </Text>
            <Input
              size='large'
              placeholder='Enter the GIT Path'
              onChange={(ev) => setGitPath(ev.currentTarget.value)}
              value={gitPath}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={12}>
            <Text strong>Enter the Scenario Name</Text>
            <Input
              size='large'
              placeholder='Enter the Scenario Name'
              onChange={(ev) => setScenarioName(ev.currentTarget.value)}
              value={scenarioName}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={12}>
            <Text strong>Enter the Source Path </Text>
            <Input
              size='large'
              placeholder='Enter the Source Path'
              onChange={(ev) => setSourcePath(ev.currentTarget.value)}
              value={sourcePath}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={12}>
            <Text strong>Enter the Target Path </Text>
            <Input
              size='large'
              placeholder='Enter the Target Path'
              onChange={(ev) => setTargetPath(ev.currentTarget.value)}
              value={targetPath}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={12}>
            <Text strong>Enter the Monitor Instance </Text>
            <Input
              size='large'
              placeholder='Enter the Monitor Instance'
              onChange={(ev) => setMonitorInstance(ev.currentTarget.value)}
              value={monitorInstance}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={4}>
            <Text strong>Select the Environment </Text>
          </Col>
          <Col style={style.column} span={12}>
            <Select
              defaultValue={environment}
              style={{
                width: 390,
              }}
              placeholder='Select the Environment'
              optionFilterProp='label'
              onChange={(val) => setEnvironment(val)}
              options={[
                {
                  value: 'FUT',
                  label: 'FUT',
                },
                {
                  value: 'QA',
                  label: 'QA',
                },
                {
                  value: 'PROD',
                  label: 'PROD',
                },
              ]}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={4}>
            <Text strong>Select the Country Code </Text>
          </Col>
          <Col style={style.column} span={12}>
            <Select
              defaultValue={countryCode}
              style={{
                width: 390,
              }}
              placeholder='Select the Country Code'
              optionFilterProp='label'
              onChange={(val) => setCountryCode(val)}
              options={[
                {
                  value: 'AR',
                  label: 'AR',
                },
                {
                  value: 'BR',
                  label: 'BR',
                },
                {
                  value: 'CA',
                  label: 'CA',
                },
                {
                  value: 'CN',
                  label: 'CN',
                },
                {
                  value: 'CR',
                  label: 'CR',
                },
                {
                  value: 'GB',
                  label: 'GB',
                },
                {
                  value: 'GT',
                  label: 'GT',
                },
                {
                  value: 'IN',
                  label: 'IN',
                },
                {
                  value: 'JP',
                  label: 'JP',
                },
                {
                  value: 'K1',
                  label: 'K1',
                },
                {
                  value: 'WW',
                  label: 'WW',
                },
              ]}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={4}>
            <Text strong>Select the Instance Id </Text>
          </Col>
          <Col style={style.column} span={12}>
            <Select
              defaultValue={instanceId}
              style={{
                width: 390,
              }}
              placeholder='Select the Instance Id'
              optionFilterProp='label'
              onChange={(val) => setInstanceId(val)}
              options={[
                {
                  value: '1',
                  label: '1',
                },
                {
                  value: '2',
                  label: '2',
                },
                {
                  value: '4',
                  label: '4',
                },
                {
                  value: '5',
                  label: '5',
                },
              ]}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={4}>
            <Text strong>Select the Region </Text>
          </Col>
          <Col style={style.column} span={12}>
            <Select
              defaultValue={region}
              style={{
                width: 390,
              }}
              placeholder='Select the Region'
              optionFilterProp='label'
              onChange={(val) => setRegion(val)}
              options={[
                {
                  value: 'APAC',
                  label: 'APAC',
                },
                {
                  value: 'EMEA',
                  label: 'EMEA',
                },
                {
                  value: 'GLOBAL',
                  label: 'GLOBAL',
                },
                {
                  value: 'NAMR',
                  label: 'NAMR',
                },
                {
                  value: 'LTAM',
                  label: 'LTAM',
                },
              ]}
            />
          </Col>
        </Row>

        <Row>
          <Col style={style.column} span={4}>
            <Text strong>Select the Monitor Type </Text>
          </Col>
          <Col style={style.column} span={12}>
            <Select
              defaultValue={monitorType}
              style={{
                width: 390,
              }}
              placeholder='Select the Monitor Type'
              optionFilterProp='label'
              onChange={(val) => setMonitorType(val)}
              options={[
                {
                  value: 'FTF',
                  label: 'FTF',
                },
                {
                  value: 'FTQ',
                  label: 'FTQ',
                },
                {
                  value: 'QTF',
                  label: 'QTF',
                },
                {
                  value: 'FTS',
                  label: 'FTS',
                },
                {
                  value: 'OTM',
                  label: 'OTM',
                },
              ]}
            />
          </Col>
        </Row>

        <Row style={{ textAlign: 'center', marginTop: 20 }}>
          <Col style={style.column} span={15}>
            <Button type='primary' size={'medium'} onClick={submitRequest}>
              Create Request
            </Button>
          </Col>
        </Row>
      </Card>
    </div>
  );
};

export default Promotion;
