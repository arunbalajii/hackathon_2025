import React, { useState } from 'react';
import { Input, Typography, Button, Col, Row, Select, Checkbox } from 'antd';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { Breadcrumb } from 'antd';
import { Card, Space } from 'antd';

const { Text, Title } = Typography;
const { TextArea } = Input;

const style = {
  column: {
    padding: 10,
  },
  text: {
    marginBottom: 15,
  },
  form: {
    marginLeft: 50,
    marginRight: 50,
    border: 1,
    borderColor: 'rgb(4, 31, 65)',
    borderStyle: 'solid',
    borderRadius: 8,
    padding: 40,
  },
};

const Onboard = () => {
  const [region, setRegion] = useState('');
  const [environment, setEnvironment] = useState('');
  const [countryCode, setCountryCode] = useState('');
  const [instanceId, setInstanceId] = useState('');
  const [volume, setVolume] = useState('');
  const [size, setSize] = useState('');
  const [monitorType, setMonitorType] = useState('');
  const [scenarioName, setScenarioName] = useState('');
  const [sourcePath, setSourcePath] = useState('');
  const [targetPath, setTargetPath] = useState('');
  const [filePattern, setFilePattern] = useState('');
  const [srcTriggerPattern, setSrcTriggerPattern] = useState('');
  const [condition, setCondition] = useState('');
  const [fileSizePolls, setFileSizePolls] = useState('');
  const [inputFileName, setInputFileName] = useState('');
  const [excludePattern, setExcludePattern] = useState(null);
  const [outputFileName, setOutputFileName] = useState('');
  const [pollInterval, setPollInterval] = useState('');
  const [sourceDisposition, setSourceDisposition] = useState('');
  const [isCompressRequired, setIsCompressRequired] = useState(false);
  const [isFileLockingRequired, setIsFileLockingRequired] = useState(false);
  const [isAppendTimestampRequired, setIsAppendTimestampRequired] = useState(false);
  const [isArchivalRequired, setIsArchivalRequired] = useState(false);
  const [isCreateRequired, setIsCreateRequired] = useState(false);
  const [archivalPath, setArchivalPath] = useState('');
  const [createPath, setCreatePath] = useState('');
  const [destTriggerPattern, setDestTriggerPattern] = useState('');

  const submitRequest = async () => {
    const mftFormBody = {
      sourcePath: sourcePath,
      targetPath: targetPath,
      user: 'testUser',
      pollInterval: pollInterval,
      fileSizeMB: true,
      monitorType: monitorType,
      scenarioDetails: {
        scenarioName: scenarioName,
        countryCode: countryCode,
        instanceId: instanceId,
        mqHeaderScenario: null,
      },
      environmentDetails: {
        environment: environment,
        region: region,
        volume: volume,
        size: size,
      },
      triggerMatch: {
        condition: condition,
        fileSizePolls: fileSizePolls,
      },
      exitPoints: [
        {
          exitPoint: 'PostDst',
          archive: isArchivalRequired,
          archivePath: archivalPath,
          compress: isCompressRequired,
          delete: true,
          destTriggerPattern: destTriggerPattern,
          createPath: createPath,
        },
      ],
      sourceDisposition: sourceDisposition,
      filePattern: filePattern,
      excludePattern: excludePattern,
      srcTriggerPattern: srcTriggerPattern,
      inputFileName: inputFileName,
      outputFileName: outputFileName,
      fileLocking: true,
      timestampPartOfFile: false,
    };

    axios
      .post('/proxy/eis/automation/cmd', mftFormBody)
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        alert(
          'Status: ' +
            error.response.data.status +
            '\nError: ' +
            error.response.data.message +
            '\n\nDetails: ' +
            error.response.data.errors
        );
      });
  };

  return (
    // <div>
    //   <Breadcrumb>
    //     <Breadcrumb.Item href='/'> Home </Breadcrumb.Item>
    //     <Breadcrumb.Item href='/eis'> EIS </Breadcrumb.Item>
    //     <Breadcrumb.Item> New Monitor </Breadcrumb.Item>
    //   </Breadcrumb>
    //   <Row>
    //     <Col style={style.column} span={24}>
    //       <Title level={3}> Work Intake - MFT</Title>
    //     </Col>
    //   </Row>

    <Card style={{ width: 1300 }}>
      <Row>
        <Col style={style.column} span={24}>
          <Title level={5}>
            Please fill in the required fields below to submit a request to Create a new Monitor
          </Title>
          <Row>
            You can refer to this&nbsp;
            <a
              href={
                'https://confluence.walmart.com/pages/viewpage.action?spaceKey=INIPIT&title=MFT+HA+Integration+Configuration+Guide'
              }
              target='_blank'
            >
              confluence page
            </a>
            &nbsp;for help in placing request:
          </Row>
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Region</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={region}
            style={{
              width: 375,
            }}
            placeholder='Select the Region'
            optionFilterProp='label'
            onChange={(val) => setRegion(val)}
            options={[
              {
                value: 'APAC',
                label: 'APAC',
              },
              {
                value: 'EMEA',
                label: 'EMEA',
              },
              {
                value: 'GLOBAL',
                label: 'GLOBAL',
              },
              {
                value: 'NAMR',
                label: 'NAMR',
              },
              {
                value: 'LTAM',
                label: 'LTAM',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Environment</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={environment}
            style={{
              width: 375,
            }}
            placeholder='Select the Environment'
            optionFilterProp='label'
            onChange={(val) => setEnvironment(val)}
            options={[
              {
                value: 'FUT',
                label: 'FUT',
              },
              {
                value: 'QA',
                label: 'QA',
              },
              {
                value: 'PROD',
                label: 'PROD',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Country Code</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={countryCode}
            style={{
              width: 375,
            }}
            placeholder='Select the Country Code'
            optionFilterProp='label'
            onChange={(val) => setCountryCode(val)}
            options={[
              {
                value: 'AR',
                label: 'AR',
              },
              {
                value: 'BR',
                label: 'BR',
              },
              {
                value: 'CA',
                label: 'CA',
              },
              {
                value: 'CN',
                label: 'CN',
              },
              {
                value: 'CR',
                label: 'CR',
              },
              {
                value: 'GB',
                label: 'GB',
              },
              {
                value: 'GT',
                label: 'GT',
              },
              {
                value: 'IN',
                label: 'IN',
              },
              {
                value: 'JP',
                label: 'JP',
              },
              {
                value: 'K1',
                label: 'K1',
              },
              {
                value: 'WW',
                label: 'WW',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Instance Id</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={instanceId}
            style={{
              width: 375,
            }}
            placeholder='Select the Instance Id'
            optionFilterProp='label'
            onChange={(val) => setInstanceId(val)}
            options={[
              {
                value: '1',
                label: '1',
              },
              {
                value: '2',
                label: '2',
              },
              {
                value: '4',
                label: '4',
              },
              {
                value: '5',
                label: '5',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Volume of Files</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={volume}
            style={{
              width: 375,
            }}
            placeholder='Select the Volume of Files'
            optionFilterProp='label'
            onChange={(val) => setVolume(val)}
            options={[
              {
                value: 'Average',
                label: 'Average',
              },
              {
                value: 'High',
                label: 'High',
              },
              {
                value: 'Small',
                label: 'Small',
              },
              {
                value: 'X Small',
                label: 'X Small',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the FIle Size</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={size}
            style={{
              width: 375,
            }}
            placeholder='Select the FIle Size'
            optionFilterProp='label'
            onChange={(val) => setSize(val)}
            options={[
              {
                value: 'Avergae',
                label: 'Avergae',
              },
              {
                value: 'Low',
                label: 'Low',
              },
              {
                value: 'X Large',
                label: 'X Large',
              },
              {
                value: 'XX Large',
                label: 'XX Larg',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Monitor Type</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={monitorType}
            style={{
              width: 375,
            }}
            placeholder='Select the Monitor Type'
            optionFilterProp='label'
            onChange={(val) => setMonitorType(val)}
            options={[
              {
                value: 'FTF',
                label: 'FTF',
              },
              {
                value: 'FTQ',
                label: 'FTQ',
              },
              {
                value: 'QTF',
                label: 'QTF',
              },
              {
                value: 'FTS',
                label: 'FTS',
              },
              {
                value: 'OTM',
                label: 'OTM',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Trigger Condition</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={condition}
            style={{
              width: 375,
            }}
            placeholder='Select the Trigger Condition'
            optionFilterProp='label'
            onChange={(val) => setCondition(val)}
            options={[
              {
                value: 'FILEMATCH',
                label: 'FILEMATCH',
              },
              {
                value: 'FILEMATCH',
                label: 'FILESIZESAME',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={4}>
          <Text strong>Select the Source Deposition</Text>
        </Col>
        <Col style={style.column} span={12}>
          <Select
            defaultValue={sourceDisposition}
            style={{
              width: 375,
            }}
            placeholder='Select the Source Deposition'
            optionFilterProp='label'
            onChange={(val) => setSourceDisposition(val)}
            options={[
              {
                value: 'LEAVE',
                label: 'LEAVE',
              },
              {
                value: 'DELETE',
                label: 'DELETE',
              },
            ]}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Scenario Name
          </Text>
          <Input
            size='large'
            placeholder='Enter the Scenario Name'
            onChange={(ev) => setScenarioName(ev.currentTarget.value)}
            value={scenarioName}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Source detail
          </Text>
          <Input
            size='large'
            placeholder='Enter the Source detail'
            onChange={(ev) => setSourcePath(ev.currentTarget.value)}
            value={sourcePath}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Target details
          </Text>
          <Input
            size='large'
            placeholder='Enter the Target details'
            onChange={(ev) => setTargetPath(ev.currentTarget.value)}
            value={targetPath}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the File Pattern
          </Text>
          <Input
            size='large'
            placeholder='Enter the File Pattern'
            onChange={(ev) => setFilePattern(ev.currentTarget.value)}
            value={filePattern}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Trigger Pattern
          </Text>
          <Input
            size='large'
            placeholder='Enter the Trigger Pattern'
            onChange={(ev) => setSrcTriggerPattern(ev.currentTarget.value)}
            value={srcTriggerPattern}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Input File Name
          </Text>
          <Input
            size='large'
            placeholder='Enter the Input File Name'
            onChange={(ev) => setInputFileName(ev.currentTarget.value)}
            value={inputFileName}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Exclude Pattern
          </Text>
          <Input
            size='large'
            placeholder='Enter the Exclude Pattern'
            onChange={(ev) => setExcludePattern(ev.currentTarget.value)}
            value={excludePattern}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Output File Name
          </Text>
          <Input
            size='large'
            placeholder='Enter the Output File Name'
            onChange={(ev) => setOutputFileName(ev.currentTarget.value)}
            value={outputFileName}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Text style={style.text} strong>
            Enter the Poll Interval
          </Text>
          <Input
            size='large'
            placeholder='Enter the Poll Interval'
            onChange={(ev) => setPollInterval(ev.currentTarget.value)}
            value={pollInterval}
          />
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Checkbox onChange={(e) => setIsCompressRequired(e.target.checked)}>
            isCompressRequired
          </Checkbox>
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Checkbox onChange={(e) => setIsFileLockingRequired(e.target.checked)}>
            isFileLockingRequired
          </Checkbox>
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Checkbox onChange={(e) => setIsAppendTimestampRequired(e.target.checked)}>
            isAppendTimestampRequired
          </Checkbox>
        </Col>
      </Row>

      <Row>
        <Col style={style.column} span={12}>
          <Checkbox onChange={(e) => setIsArchivalRequired(e.target.checked)}>
            isArchivalRequired
          </Checkbox>
        </Col>
      </Row>

      {isArchivalRequired && (
        <Row>
          <Col style={style.column} span={12}>
            <Text style={style.text} strong>
              Enter the Archival Path
            </Text>
            <Input
              size='large'
              placeholder='Enter the Archival Path'
              onChange={(ev) => setArchivalPath(ev.currentTarget.value)}
              value={archivalPath}
            />
          </Col>
        </Row>
      )}

      <Row>
        <Col style={style.column} span={12}>
          <Checkbox onChange={(e) => setIsCreateRequired(e.target.checked)}>
            isCreateRequired
          </Checkbox>
        </Col>
      </Row>

      {isCreateRequired && (
        <Row>
          <Col style={style.column} span={12}>
            <Text style={style.text} strong>
              Enter the Create Directory Path
            </Text>
            <Input
              size='large'
              placeholder='Enter the Create Directory Path'
              onChange={(ev) => setCreatePath(ev.currentTarget.value)}
              value={createPath}
            />
          </Col>
        </Row>
      )}

      {isCreateRequired && (
        <Row>
          <Col style={style.column} span={12}>
            <Text style={style.text} strong>
              Enter the Destination Trigger Pattern
            </Text>
            <Input
              size='large'
              placeholder='Enter the Destination Trigger Pattern'
              onChange={(ev) => setDestTriggerPattern(ev.currentTarget.value)}
              value={destTriggerPattern}
            />
          </Col>
        </Row>
      )}

      <Row style={{ textAlign: 'center', marginTop: 20 }}>
        <Col style={style.column} span={15}>
          <Button type='primary' size={'medium'} onClick={submitRequest}>
            Create Request
          </Button>
        </Col>
      </Row>
    </Card>
    // </div>
  );
};

export default Onboard;
