import React from 'react';
import { Tabs } from 'antd';
import Onboard from './onboard';
import Promotion from './promotion';
import { Breadcrumb } from 'antd';
import { Typography, Col, Row } from 'antd';

const { Title } = Typography;

const Home = () => {
  return (
    <div>
      <Breadcrumb>
        <Breadcrumb.Item href='/'> Home </Breadcrumb.Item>
        <Breadcrumb.Item href='/eis'> EIS </Breadcrumb.Item>
        <Breadcrumb.Item> MFT </Breadcrumb.Item>
      </Breadcrumb>
      <Row>
        <Col span={24}>
          <Title level={3}> Work Intake - MFT</Title>
        </Col>
      </Row>
      <Tabs
        defaultActiveKey='1'
        centered
        items={[
          {
            label: 'Onboard New Monitor',
            key: '1',
            children: <Onboard />,
          },
          {
            label: 'Monitor Promotion',
            key: '2',
            children: <Promotion />,
          },
        ]}
      />
    </div>
  );
};

export default Home;
