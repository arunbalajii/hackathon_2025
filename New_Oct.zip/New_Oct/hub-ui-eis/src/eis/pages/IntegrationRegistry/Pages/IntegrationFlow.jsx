import { InfoCircleTwoTone } from '@ant-design/icons';
import { Col, Popover, Row } from 'antd';
import React, { useRef, useEffect, useState } from 'react';

const styles = {
  container: {
    transform: 'translateX(-100%)',
    opacity: 0,
    transition: 'transform 0.5s ease, opacity 0.5s ease',
    position: 'relative',
    width: '100%',
    height: '100%',
    backgroundColor: '#F5F1FEFF',
    border: '1px solid black',
    borderRadius: '4px',
    padding: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
  },
  sourceContent: {
    width: '100px',
    height: '100px',
    backgroundColor: '#8bc34a',
    border: '2px solid black',
    borderRadius: '60px',
    textAlign: 'center',
    lineHeight: '100px',
    boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
  },
  techContent: {
    width: '100px',
    height: '100px',
    backgroundColor: '#ff9800',
    border: '2px solid #1E2128FF',
    borderRadius: '4px',
    textAlign: 'center',
    lineHeight: '100px',
    boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
  },
  targetContent: {
    width: '100px',
    height: '100px',
    backgroundColor: '#03a9f4',
    border: '2px solid black',
    borderRadius: '60px',
    textAlign: 'center',
    lineHeight: '100px',
    boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
  },
};

function MouseOver(event) {
  event.target.style.borderWidth = '3px';
}

function MouseOut(event) {
  event.target.style.borderWidth = '2px';
}

function MouseClick(event) {
  event.target.style.height = '300px';
}

const IntegrationFlow = (params) => {
  const [sources, setSources] = useState(['Source 1']);
  const [targets, setTargets] = useState(['Destination 1']);
  const [technologies, setTechnologies] = useState(['Armory', 'SAP']);

  const canvasRefs = useRef([]);
  canvasRefs.current = [];

  const setRef = (element) => {
    if (element && !canvasRefs.current.includes(element)) {
      canvasRefs.current.push(element);
    }
  };

  const [nodePoints, setNodePoints] = useState([
    {
      startPoint: {
        x: 200,
        y: 300,
      },
      endPoint: {
        x: 400,
        y: 300,
      },
    },
    {
      startPoint: {
        x: 400,
        y: 300,
      },
      endPoint: {
        x: 600,
        y: 300,
      },
    },
    {
      startPoint: {
        x: 600,
        y: 300,
      },
      endPoint: {
        x: 800,
        y: 300,
      },
    },
    {
      startPoint: {
        x: 800,
        y: 300,
      },
      endPoint: {
        x: 1000,
        y: 300,
      },
    },
  ]);

  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setSources(params.sourceList);
    setTargets(params.targetList);
    setTechnologies(params.technologyList);

    const drawArrow = (point, ctx) => {
      // Draw arrow connecting the two boxes
      ctx.beginPath();
      ctx.moveTo(point.startPoint.x - 50, point.startPoint.y);
      ctx.lineTo(point.endPoint.x - 50, point.endPoint.y);
      ctx.lineWidth = 2;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)'; // Shadow color
      ctx.shadowBlur = 10; // Shadow blur
      ctx.shadowOffsetX = 3; // Shadow offset X
      ctx.shadowOffsetY = 3; // Shadow offset Y
      ctx.strokeStyle = '#5b3388';
      ctx.stroke();

      // Draw arrowhead
      ctx.beginPath();
      ctx.moveTo(point.endPoint.x - 50 - 10, point.endPoint.y - 10);
      ctx.lineTo(point.endPoint.x - 50, point.endPoint.y);
      ctx.lineTo(point.endPoint.x - 50 - 10, point.endPoint.y + 10);
      ctx.closePath();
      ctx.fillStyle = '#5b3388';
      ctx.fill();
    };

    if (canvasRefs.current) {
      canvasRefs.current.forEach((canvas, index) => {
        const ctx = canvas.getContext('2d');
        drawArrow(nodePoints.at(index), ctx);
      });
    }

    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100); // Delay for the animation to start

    return () => clearTimeout(timer);
  }, []);

  const content = (
    <div>
      <p>Content</p>
      <p>Content</p>
    </div>
  );

  return (
    <div
      style={{
        transform: isVisible ? 'translateX(0)' : 'translateX(+50%)',
        opacity: isVisible ? 1 : 0,
        transition: 'transform 0.5s ease, opacity 1s ease',
        position: 'relative',
        width: '100%',
        height: '100%',
        backgroundColor: '#F5F1FEFF',
        border: '1px solid black',
        borderRadius: '4px',
        padding: '10px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      }}
    >
      <Row>
        <Col span={12}>
          {' '}
          <h4 style={{ textAlign: 'left' }}>{params.integrationName}</h4>
        </Col>
        <Col span={12}>
          {' '}
          <h4 style={{ textAlign: 'right' }}>
            <InfoCircleTwoTone /> Hover on any node for more info
          </h4>
        </Col>
      </Row>

      {Array(technologies.length + 2)
        .fill(0)
        .map((nodePoint, index) => {
          return (
            <canvas
              key={index}
              ref={setRef}
              width='1200'
              height='500'
              style={{ position: 'absolute', top: 0, left: 0 }}
            />
          );
        })}

      {sources.map((source, index) => {
        const content = (
          <div>
            <p>
              <b>Protocol: </b> {params.sources.at(index).protocol}
            </p>
            <p>
              <b>End Point: </b>
              {params.sources.at(index).endpoint}
            </p>
            <p>
              <b>Contact: </b>
              {params.sources.at(index).contactName}
            </p>
            <p>
              <b>Assignment Group: </b> {params.sources.at(index).assignmentGroup}
            </p>
          </div>
        );
        return (
          <Popover placement='bottom' title={source} content={content} pointAtCenter={true}>
            <div
              style={{
                position: 'absolute',
                left: `${nodePoints[0].startPoint.x - 50}px`,
                top: `${nodePoints[0].startPoint.y - 50}px`,
                zIndex: 1,
              }}
            >
              <div style={styles.sourceContent} onMouseOver={MouseOver} onMouseOut={MouseOut}>
                {source}
              </div>
            </div>
          </Popover>
        );
      })}

      {technologies.map((technology, index) => {
        const content = (
          <div>
            <p>
              <b>Platform Id: </b>
              {technology.platformIdentifier}
            </p>
            <p>
              <b>Source: </b>
              {technology.sourceEndpoint}
            </p>
            <p>
              <b>Source Protocol: </b>
              {technology.sourceProtocol}
            </p>
            <p>
              <b>Target: </b>
              {technology.targetEndpoint}
            </p>
            <p>
              <b>Target Protocol: </b>
              {technology.targetProtocol}
            </p>
          </div>
        );
        return (
          <Popover
            placement='bottom'
            title={technology.technology}
            content={content}
            pointAtCenter={true}
          >
            <div
              style={{
                position: 'absolute',
                left: `${nodePoints[index + 1].startPoint.x - 50}px`,
                top: `${nodePoints[index + 1].startPoint.y - 50}px`,
                zIndex: 1,
              }}
            >
              <div
                key={technology.sequence}
                style={styles.techContent}
                onMouseOver={MouseOver}
                onMouseOut={MouseOut}
              >
                {technology.technology}
              </div>
            </div>
          </Popover>
        );
      })}

      {targets.map((target, index) => {
        const content = (
          <div>
            <p>
              <b>Protocol: </b>
              {params.targets.at(index).protocol}
            </p>
            <p>
              <b>End Point: </b>
              {params.targets.at(index).endpoint}
            </p>
            <p>
              <b>Contact: </b>
              {params.targets.at(index).contactName}
            </p>
            <p>
              <b>Assignment Group: </b>
              {params.targets.at(index).assignmentGroup}
            </p>
          </div>
        );
        return (
          <Popover placement='bottom' title={target} content={content} pointAtCenter={true}>
            <div
              style={{
                position: 'absolute',
                left: `${nodePoints[technologies.length].endPoint.x - 50}px`,
                top: `${nodePoints[technologies.length].endPoint.y - 50}px`,
                zIndex: 1,
              }}
            >
              <div style={styles.targetContent} onMouseOver={MouseOver} onMouseOut={MouseOut}>
                {target}
              </div>
            </div>
          </Popover>
        );
      })}

      <div style={{ position: 'absolute', bottom: '0', marginBottom: '10px' }}>
        <div style={{ display: 'flex' }}>
          <div
            style={{
              border: '3px solid #8bc34a',
              borderRadius: '5px',
              backgroundColor: '#8bc34a',
              width: '30px',
              height: '2px',
              marginTop: '8px',
            }}
          ></div>{' '}
          Source
        </div>
        <div style={{ display: 'flex' }}>
          <div
            style={{
              border: '3px solid #ff9800',
              borderRadius: '5px',
              backgroundColor: '#ff9800',
              width: '30px',
              height: '2px',
              marginTop: '8px',
            }}
          ></div>{' '}
          Technology
        </div>
        <div style={{ display: 'flex' }}>
          <div
            style={{
              border: '3px solid #03a9f4',
              borderRadius: '5px',
              backgroundColor: '#03a9f4',
              width: '30px',
              height: '2px',
              marginTop: '8px',
            }}
          ></div>{' '}
          Target
        </div>
      </div>
      {/*
            <div style={{ position: 'absolute', top: '50px', left: '50px', zIndex: 1 }}>
                <div style={{ width: '100px', height: '100px', backgroundColor: 'lightblue', border: '2px solid blue', textAlign: 'center', lineHeight: '100px' }}>
                    Box 1
                </div>
            </div>

            <div style={{ position: 'absolute', top: '50px', left: '250px', zIndex: 1 }}>
                <div style={{ width: '100px', height: '100px', backgroundColor: 'lightblue', border: '2px solid blue', textAlign: 'center', lineHeight: '100px' }}>
                    Box 2
                </div>
            </div>
           
            <div style={{ position: 'absolute', left: `${nodePoints[nodePoints.length-1].endPoint.x-50}px`, top: `${nodePoints[nodePoints.length-1].endPoint.y-50}px`, zIndex: 1 }}>
                <div style={{ width: '100px', height: '100px', backgroundColor: 'lightblue', border: '2px solid blue', textAlign: 'center', lineHeight: '100px' }}>
                    Box {nodePoints.length}
                </div>
            </div>
             */}
    </div>
  );
};

export default IntegrationFlow;
