import { Button, Card, Col, Divider, Modal, Row, Skeleton, Statistic, Tooltip } from 'antd';
import React, { useEffect, useState } from 'react';
import { DoubleLeftOutlined, InfoCircleTwoTone } from '@ant-design/icons';

import { useLocation } from 'react-router-dom';
import axios from 'axios';
import ArrowCanvas from './IntegrationFlow';
import ConnectionInfo from '../components/moreDetails/ConnectionInfo';

const styles = {
  container: {
    backgroundColor: '#FFFFFFFF',
    border: '1',
    borderRadius: '5px',
    padding: '1em 5em 1em 5em',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
  },
  rowCard: {
    margin: '5px',
    textAlign: 'center',
  },
  highlightText: {
    color: '#6D31EDFF',
    fontFamily: 'Verdana',
  },
  integrationInfoItems: {
    paddingLeft: '5%',
    textAlign: 'left',
    fontSize: '16px',
  },
  graphButton: {
    display: 'flex',
    textAlign: 'center',
    verticalAlign: 'middle',
  },
  bold: {
    fontWeight: 'bold',
    textAlign: 'left',
  },
  borderBox: {
    border: '3px solid #DEE1E6FF',
    borderRadius: '5px',
    padding: '10px',
    margin: '10px',
  },
  left: {
    textAlign: 'left',
  },
  connectionBox: {
    padding: '10px 10px 2px 10px',
  },
  centerAlign: {
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
  },
};

function MoreDetails() {
  const [data, setData] = useState({
    integrationId: 648,
    name: 'ESB0560_AP_DOWNPYMNT',
    description: 'I0180 - Inbound AP interface from Agua to SAP',
    identifier: 'I0180',
    country: 'MX',
    owner: '',
    env: '',
    integrationPOC: '',
    integrationEmail: '',
    tags: 'AP',
    sourceDetails: [
      {
        name: 'Agua',
        schemaName: '',
        protocol: 'Queue',
        endpoint: 'WW.ESB.ENTRY.SERVICE.IN',
        contactName: '_MXEAIProfit@email.wal-mart.com;_Profit_AP_MX_FACTURACION@email.wal-mart.com',
        assignmentGroup: 'MX - AMS Soporte , MX - Soporte Moneta , ',
      },
    ],
    targetDetails: [
      {
        name: 'SAP PR2',
        schemaName: '',
        protocol: 'Queue',
        endpoint: 'MX.SAP.AP_DOWNPYMNT_I0180.EXIT.OUT',
        contactName: 'GIP SAP Tech Support <gipsaptsup@email.wal-mart.com>',
        assignmentGroup: 'GBS - SAP Tech Support',
      },
    ],
    technology: 'File/MFT/SAP',
    domainName: ['Finance'],
  });

  const emailName = 'Enterprise Integration Tech Support';
  const email = 'gbsitsupport@wal-mart.com';

  const [technologiesList, settechnologiesList] = useState([]);

  const location = useLocation();
  const props = location.state; // access the props object

  const [isLoading, setIsLoading] = useState(false);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const submitRequest = async () => {
    const response = await axios.get(`/proxy/int/api/integration/${props.id}`);
    setData(response.data);
    const respons2 = await axios.get(`/proxy/int/api/platformDataflow/${props.id}`);
    settechnologiesList(respons2.data);
    setIsLoading(false);
  };

  useEffect(() => {
    submitRequest().then(() => {});
  });

  return isLoading ? (
    <Skeleton active />
  ) : (
    <>
      {/*<h1 style={{ fontWeight: "bold", fontFamily: 'Verdana', marginBottom: "0", }}>{data.name}</h1>*/}
      <div style={styles.container}>
        <Row>
          <Col span={24}>
            <Row style={styles.integrationInfoItems}>
              <Col span={20}>
                <h3 style={styles.highlightText}>
                  <InfoCircleTwoTone
                    twoToneColor={'#6D31EDFF'}
                    style={{ padding: '5px', textColor: '#6D31EDFF' }}
                  />
                  Integration Information
                </h3>
                <Divider style={{ margin: '0', backgroundColor: '#DEE1E6FF' }} />

                <Row>
                  <Col span={24}>
                    <Row style={styles.rowCard}>
                      <Col span={5} style={styles.bold} justify='start'>
                        Integration Name:
                      </Col>
                      <Col span={7} style={styles.left}>
                        {data.name}
                      </Col>
                      <Col span={5} style={styles.bold} justify='start'>
                        Integration Email:
                      </Col>
                      <Col span={7} style={styles.left}>
                        <a
                          href={`mailto:${email}?subject=${encodeURIComponent(
                            'Info regarding Integration needed'
                          )}`}
                        >
                          {emailName}{' '}
                        </a>
                      </Col>
                    </Row>
                  </Col>
                  <Col span={24}>
                    <Row style={styles.rowCard}>
                      <Col span={5} style={styles.bold}>
                        Integration ID:
                      </Col>
                      <Col span={7} style={styles.left}>
                        {data.identifier}
                      </Col>
                      <Col span={5} style={styles.bold}>
                        Country:
                      </Col>
                      <Col span={7} style={styles.left}>
                        {data.country}
                      </Col>
                    </Row>
                  </Col>
                  <Col span={24}>
                    <Row style={styles.rowCard}>
                      <Col span={5} style={styles.bold}>
                        Domain:
                      </Col>
                      <Col span={7} style={styles.left}>
                        {data.domainName}
                      </Col>
                      <Col span={5} style={styles.bold}>
                        Owner:
                      </Col>
                      <Col span={7} style={styles.left}>
                        {data.owner}
                      </Col>
                    </Row>
                  </Col>
                  <Col span={24}>
                    <Row style={styles.rowCard}>
                      <Col style={styles.bold} justify='start' span={5}>
                        Description:
                      </Col>
                      <Col span={19} style={styles.left}>
                        {data.description}
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
              <Col span={4} justify='center'>
                <Row>
                  <Card
                    bordered
                    hoverable
                    style={{
                      height: '100px',
                      width: '300px',
                      boxShadow: '0 1px 2px rgba(0, 0, 0, 0.2)',
                    }}
                  >
                    <Statistic
                      title='   No of sources'
                      value={data.sourceDetails.length}
                      valueStyle={{
                        color: '#15ABFFFF',
                      }}
                    />
                  </Card>
                </Row>
                <Row>
                  <Card
                    bordered
                    hoverable
                    style={{
                      height: '100px',
                      width: '300px',
                      marginTop: '10px',
                      boxShadow: '0 1px 2px rgba(0, 0, 0, 0.2)',
                    }}
                  >
                    <Statistic
                      title='No of destinations'
                      value={data.targetDetails.length}
                      valueStyle={{
                        color: '#15ABFFFF',
                      }}
                    />
                  </Card>
                </Row>
              </Col>
            </Row>
          </Col>
        </Row>
        <Row style={styles.connectionBox}>
          <Col span={11}>
            <ConnectionInfo infoName='Source' data={data.sourceDetails}></ConnectionInfo>
          </Col>
          <Col span={11}>
            <ConnectionInfo infoName='Destination' data={data.targetDetails}></ConnectionInfo>
          </Col>
          <Col span={2}>
            <Row>
              <Col span={24} style={styles.centerAlign}>
                <Tooltip
                  title={isModalOpen ? 'Integration Flow' : 'Check integration flow!'}
                  open
                  placement='bottom'
                >
                  <Button
                    type='primary'
                    style={{
                      backgroundColor: '#6D31EDFF',
                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
                    }}
                    onClick={showModal}
                  >
                    <DoubleLeftOutlined /> Graph
                  </Button>
                </Tooltip>
                <Modal
                  open={isModalOpen}
                  onOk={handleOk}
                  onCancel={handleCancel}
                  footer={null}
                  centered={true}
                  bodyStyle={{ height: '70vh', paddingTop: '3em', borderRadius: '5px' }}
                  width={'70vw'}
                >
                  <ArrowCanvas
                    key={data.integrationId}
                    integrationId={data.integrationId}
                    integrationName={data.name}
                    sourceList={data.sourceDetails.map((source) => {
                      return source.name;
                    })}
                    targetList={data.targetDetails.map((target) => {
                      return target.name;
                    })}
                    technologyList={technologiesList}
                    sources={data.sourceDetails}
                    targets={data.targetDetails}
                  />
                  {/*
                                    <IntegrationFlow
                                        sourceList={data.sourceDetails.map((source) =>{
                                            return source.name
                                        })}
                                        targetList={data.targetDetails.map((target) =>{
                                            return target.name
                                        })}
                                        technologyList={data.technology.split("/")}
                                    />*/}
                </Modal>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default MoreDetails;
