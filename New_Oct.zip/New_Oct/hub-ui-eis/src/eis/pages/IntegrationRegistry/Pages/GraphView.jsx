// SimpleGraph.js
import {
  DownSquareTwoTone,
  LeftSquareTwoTone,
  RightSquareTwoTone,
  UpSquareTwoTone,
} from '@ant-design/icons';
import { Menu } from 'antd';
import React, { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';

const GraphView = () => {
  const canvasRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [lastPosition, setLastPosition] = useState({ x: 800, y: 400 });
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  const handleMouseDown = (event) => {
    setIsDragging(true);
    setLastPosition({ x: event.clientX, y: event.clientY });
  };

  const handleMouseMove = (event) => {
    if (isDragging) {
      const dx = event.clientX - lastPosition.x;
      const dy = event.clientY - lastPosition.y;

      if (
        offset.x + dx > -300 &&
        offset.x + dx < 500 &&
        offset.y + dy > -100 &&
        offset.y + dy < 200
      ) {
        setOffset((prevOffSet) => ({
          x: prevOffSet.x + dx,
          y: prevOffSet.y + dy,
        }));
        setLastPosition({ x: event.clientX, y: event.clientY });
      }

      console.log(offset);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const moveCanvas = (dx, dy) => {
    if (
      offset.x + dx > -300 &&
      offset.x + dx < 500 &&
      offset.y + dy > -100 &&
      offset.y + dy < 200
    ) {
      setOffset((prevOffset) => ({
        x: prevOffset.x + dx,
        y: prevOffset.y + dy,
      }));
    }
  };

  const sourceNodeslist = [
    { id: 1, text: 'SAP PR2', nodeType: 'root', x: 600, y: 300 },
    { id: 2, text: ' HOST', nodeType: 'child', x: 550, y: 500 },
    { id: 3, text: ' GLM', nodeType: 'child', x: 450, y: 150 },
    { id: 4, text: 'MOTOR', nodeType: 'child', x: 800, y: 300 },
    { id: 5, text: 'HOST', nodeType: 'child', x: 700, y: 100 },
    { id: 6, text: '  SAP', nodeType: 'child', x: 300, y: 350 },
    { id: 7, text: '   BW', nodeType: 'child', x: 700, y: 500 },
    { id: 8, text: 'Membrshp', nodeType: 'child', x: 300, y: 500 },
    { id: 9, text: 'SAP/Vistex', nodeType: 'child', x: 900, y: 500 },
    { id: 10, text: 'Mainframe', nodeType: 'child', x: 400, y: 600 },
    { id: 11, text: 'STRIDE', nodeType: 'child', x: 1100, y: 450 },
    { id: 12, text: '   I0468', x: 500, y: 700 },
    { id: 13, text: 'I0181', x: 400, y: 0 },
    { id: 14, text: 'I0181', x: 1000, y: 300 },
    { id: 15, text: '   I0245', x: 100, y: 300 },
    { id: 16, text: 'I0551', x: 200, y: 700 },
    { id: 17, text: 'I0560', x: 900, y: 100 },
    { id: 18, text: '   I0468', x: 200, y: 100 },
    { id: 19, text: 'I01221', x: 150, y: 500 },
    { id: 20, text: '   I0180', x: 1050, y: 150 },
    { id: 21, text: 'I0181', x: 800, y: 0 },
    { id: 23, text: '   I0245', x: 800, y: 600 },
    { id: 24, text: 'I0551', x: 1000, y: 700 },
    { id: 25, text: 'I0560', x: 350, y: 800 },
    { id: 26, text: '   I0468', x: 1200, y: 200 },
    { id: 27, text: 'I01221', x: 1300, y: 500 },
  ];

  const eges = [
    { from: 1, to: 2 },
    { from: 1, to: 3 },
    { from: 1, to: 4 },
    { from: 1, to: 5 },
    { from: 1, to: 6 },
    { from: 1, to: 7 },
    { from: 1, to: 8 },
    { from: 1, to: 9 },
    { from: 1, to: 10 },
    { from: 1, to: 11 },
    { from: 2, to: 12 },
    { from: 3, to: 13 },
    { from: 3, to: 18 },

    { from: 4, to: 20 },
    { from: 4, to: 14 },
    { from: 4, to: 26 },
    { from: 5, to: 17 },
    { from: 5, to: 21 },
    { from: 6, to: 15 },
    { from: 6, to: 19 },
    { from: 7, to: 23 },
    { from: 8, to: 16 },
    { from: 9, to: 24 },
    { from: 10, to: 25 },
    { from: 11, to: 27 },
  ];
  const domainNodesList = [
    { id: 1, text: 'Domains', nodeType: 'root', x: 600, y: 300 },
    { id: 2, text: ' Retail', nodeType: 'child', x: 600, y: 500 },
    { id: 3, text: 'People', nodeType: 'child', x: 400, y: 100 },
    { id: 4, text: 'Finance', nodeType: 'child', x: 800, y: 300 },
    { id: 5, text: '     1', x: 600, y: 100 },
    { id: 6, text: '     2', x: 900, y: 100 },
    { id: 7, text: '     3', x: 600, y: 700 },
    { id: 8, text: '     4', x: 900, y: 500 },
    { id: 9, text: '     5', x: 1000, y: 300 },
    { id: 10, text: '   ISM', nodeType: 'child', x: 400, y: 400 },
    { id: 11, text: '     6', x: 300, y: 500 },
    { id: 12, text: '     7', x: 400, y: 600 },
  ];

  const domainNodesList1 = [
    { id: 1, text: 'Finance', nodeType: 'root', x: 600, y: 300 },
    { id: 2, text: ' AGUA', nodeType: 'child', x: 550, y: 500 },
    { id: 3, text: ' HOST', nodeType: 'child', x: 450, y: 150 },
    { id: 4, text: 'SAP PR2', nodeType: 'child', x: 800, y: 300 },
    { id: 5, text: 'SAP PR3', nodeType: 'child', x: 700, y: 100 },
    { id: 6, text: '  SAP', nodeType: 'child', x: 300, y: 350 },
    { id: 7, text: '   BW', nodeType: 'child', x: 700, y: 500 },
    { id: 8, text: 'Membrshp', nodeType: 'child', x: 300, y: 500 },
    { id: 9, text: 'SAP/Vistex', nodeType: 'child', x: 900, y: 500 },
    { id: 10, text: 'Mainframe', nodeType: 'child', x: 400, y: 600 },
    { id: 11, text: 'STRIDE', nodeType: 'child', x: 1100, y: 450 },
    { id: 12, text: '   I0180', x: 500, y: 700 },
    { id: 13, text: 'I0181', x: 400, y: 0 },
    { id: 14, text: 'I0181', x: 1000, y: 300 },
    { id: 15, text: '   I0245', x: 100, y: 300 },
    { id: 16, text: 'I0551', x: 200, y: 700 },
    { id: 17, text: 'I0560', x: 900, y: 100 },
    { id: 18, text: '   I0468', x: 200, y: 100 },
    { id: 19, text: 'I01221', x: 150, y: 500 },
    { id: 20, text: '   I0180', x: 1050, y: 150 },
    { id: 21, text: 'I0181', x: 800, y: 0 },
    { id: 23, text: '   I0245', x: 800, y: 600 },
    { id: 24, text: 'I0551', x: 1000, y: 700 },
    { id: 25, text: 'I0560', x: 350, y: 800 },
    { id: 26, text: '   I0468', x: 1200, y: 200 },
    { id: 27, text: 'I01221', x: 1300, y: 500 },
  ];
  const domainEges1 = [
    { from: 1, to: 2 },
    { from: 1, to: 3 },
    { from: 1, to: 4 },
    { from: 1, to: 5 },
    { from: 1, to: 6 },
    { from: 1, to: 7 },
    { from: 1, to: 8 },
    { from: 1, to: 9 },
    { from: 1, to: 10 },
    { from: 1, to: 11 },
    { from: 2, to: 12 },
    { from: 3, to: 13 },
    { from: 3, to: 18 },

    { from: 4, to: 20 },
    { from: 4, to: 14 },
    { from: 4, to: 26 },
    { from: 5, to: 17 },
    { from: 5, to: 21 },
    { from: 6, to: 15 },
    { from: 6, to: 19 },
    { from: 7, to: 23 },
    { from: 8, to: 16 },
    { from: 9, to: 24 },
    { from: 10, to: 25 },
    { from: 11, to: 27 },
  ];

  const domainEges = [
    { from: 1, to: 2 },
    { from: 1, to: 3 },
    { from: 1, to: 4 },
    { from: 1, to: 10 },
    { from: 4, to: 6 },
    { from: 2, to: 7 },
    { from: 3, to: 5 },
    { from: 4, to: 8 },
    { from: 4, to: 9 },
    { from: 10, to: 11 },
    { from: 10, to: 12 },
  ];

  const [nodes, setNodes] = useState([
    { id: 1, text: 'Finance', nodeType: 'root', x: 600, y: 300 },
    { id: 2, text: ' AGUA', nodeType: 'child', x: 550, y: 500 },
    { id: 3, text: ' HOST', nodeType: 'child', x: 450, y: 150 },
    { id: 4, text: 'SAP PR2', nodeType: 'child', x: 800, y: 300 },
    { id: 5, text: 'SAP PR3', nodeType: 'child', x: 700, y: 100 },
    { id: 6, text: '  SAP', nodeType: 'child', x: 300, y: 350 },
    { id: 7, text: 'BW', nodeType: 'child', x: 700, y: 500 },
    { id: 8, text: 'Membrshp', nodeType: 'child', x: 300, y: 500 },
    { id: 9, text: 'SAP/Vistex', nodeType: 'child', x: 900, y: 500 },
    { id: 10, text: 'Mainframe', nodeType: 'child', x: 400, y: 600 },
    { id: 11, text: 'STRIDE', nodeType: 'child', x: 1100, y: 450 },
    { id: 12, text: '   I0180', x: 500, y: 700 },
    { id: 13, text: 'I0181', x: 400, y: 0 },
    { id: 14, text: 'I0181', x: 1000, y: 300 },
    { id: 15, text: '   I0245', x: 100, y: 300 },
    { id: 16, text: 'I0551', x: 200, y: 700 },
    { id: 17, text: 'I0560', x: 900, y: 100 },
    { id: 18, text: '   I0468', x: 200, y: 100 },
    { id: 19, text: 'I01221', x: 150, y: 500 },
    { id: 20, text: '   I0180', x: 1050, y: 150 },
    { id: 21, text: 'I0181', x: 800, y: 0 },
    { id: 23, text: '   I0245', x: 800, y: 600 },
    { id: 24, text: 'I0551', x: 1000, y: 700 },
    { id: 25, text: 'I0560', x: 350, y: 800 },
    { id: 26, text: '   I0468', x: 1200, y: 200 },
    { id: 27, text: 'I01221', x: 1300, y: 500 },
  ]);

  const [edges, setEdges] = useState([
    { from: 1, to: 2 },
    { from: 1, to: 3 },
    { from: 1, to: 4 },
    { from: 1, to: 5 },
    { from: 1, to: 6 },
    { from: 1, to: 7 },
    { from: 1, to: 8 },
    { from: 1, to: 9 },
    { from: 1, to: 10 },
    { from: 1, to: 11 },
    { from: 2, to: 12 },
    { from: 3, to: 13 },
    { from: 3, to: 18 },

    { from: 4, to: 20 },
    { from: 4, to: 14 },
    { from: 4, to: 26 },
    { from: 5, to: 17 },
    { from: 5, to: 21 },
    { from: 6, to: 15 },
    { from: 6, to: 19 },
    { from: 7, to: 23 },
    { from: 8, to: 16 },
    { from: 9, to: 24 },
    { from: 10, to: 25 },
    { from: 11, to: 27 },
  ]);

  const changeList = (key) => {
    if (key == 'source') {
      setNodes(sourceNodeslist);
      setEdges(eges);
    } else if (key == 'domain') {
      setNodes(domainNodesList1);
      setEdges(domainEges1);
    } else {
      setNodes(domainNodesList1);
      setEdges(domainEges1);
    }
  };
  const drawLine = (ctx, from, to) => {
    ctx.beginPath();
    ctx.moveTo(from.x + offset.x, from.y + offset.y);
    ctx.lineTo(to.x + offset.x, to.y + offset.y);
    ctx.shadowColor = 'rgba(0, 0, 0, 0.5)'; // Shadow color
    ctx.shadowBlur = 10; // Shadow blur
    ctx.shadowOffsetX = 3; // Shadow offset X
    ctx.shadowOffsetY = 3; // Shadow offset Y
    ctx.strokeStyle = 'black';
    ctx.stroke();

    // Draw arrowhead
    const headLength = 7; // Length of head in pixels
    const angle = Math.atan2(to.y - from.y, to.x - from.x);
    ctx.beginPath();
    ctx.moveTo(to.x - 30 + offset.x, to.y + offset.y);
    ctx.lineTo(
      to.x - 30 + offset.x - headLength * Math.cos(angle - Math.PI / 6),
      to.y + offset.y - headLength * Math.sin(angle - Math.PI / 6)
    );
    ctx.lineTo(
      to.x - 30 + offset.x - headLength * Math.cos(angle + Math.PI / 6),
      to.y + offset.y - headLength * Math.sin(angle + Math.PI / 6)
    );
    ctx.lineTo(to.x - 30 + offset.x, to.y + offset.y);
    ctx.fillStyle = 'black';
    ctx.fill();
  };

  const drawGraph = (ctx) => {
    // Clear the canvas
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Draw edges
    edges.forEach((edge) => {
      const fromNode = nodes.find((node) => node.id === edge.from);
      const toNode = nodes.find((node) => node.id === edge.to);
      if (fromNode && toNode) {
        drawLine(ctx, fromNode, toNode);
      }
    });

    // Draw nodes
    nodes.forEach((node, index) => {
      ctx.beginPath();
      if (node.id == 1) {
        ctx.arc(node.x + offset.x, node.y + offset.y, 80, 0, Math.PI * 2, true);
        ctx.fillStyle = '#ffc107';
      } else if (node.nodeType == 'child') {
        ctx.arc(node.x + offset.x, node.y + offset.y, 50, 0, Math.PI * 2, true);
        ctx.fillStyle = '#00bcd4';
      } else {
        ctx.arc(node.x + offset.x, node.y + offset.y, 50, 0, Math.PI * 2, true);
        ctx.fillStyle = '#8bc34a';
      }

      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)'; // Shadow color
      ctx.shadowBlur = 10; // Shadow blur
      ctx.shadowOffsetX = 3; // Shadow offset X
      ctx.shadowOffsetY = 3; // Shadow offset Y
      ctx.fill();

      ctx.strokeStyle = 'black';
      ctx.stroke();

      // Draw node text
      if (node.id == 1) {
        ctx.fillStyle = 'black';
      } else {
        ctx.fillStyle = 'black';
      }

      ctx.font = '14px verdana';
      ctx.fillText(node.text, node.x + offset.x - 25, node.y + offset.y + 5); // Display node ID
    });
  };

  const location = useLocation();
  const props = location.state; // access the props object

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    const render = () => {
      drawGraph(ctx);
      requestAnimationFrame(render);
    };

    render();
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100); // Delay for the animation to start

    // Set up mouse event listeners
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      clearTimeout(timer);
    };
  }, [nodes, edges, isDragging, offset]);

  return (
    <div
      style={{
        position: 'absolute',
        top: 100,
        left: 260,
        width: '1400px',
        height: '800px',
        transform: isVisible ? 'translateX(0)' : 'translateX(+50%)',
        opacity: isVisible ? 1 : 0,
        transition: 'transform 0.5s ease, opacity 1s ease',
        cursor: 'move',
        userSelect: 'none',
        background: 'radial-gradient(circle, #e3f2fd, #64b5f6)',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      }}
    >
      <Menu
        style={{
          marginBottom: '20',
          position: 'absolute',
          width: '20%',
          textAlign: 'center',
          borderRadius: '3px',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        }}
      >
        <Menu.Item key='Domain' onClick={() => changeList('domain')}>
          Domain
        </Menu.Item>
        <Menu.Item key='Source' onClick={() => changeList('source')}>
          Application
        </Menu.Item>
        <Menu.Item>
          <LeftSquareTwoTone
            style={{
              width: '30px', // Set desired width
              height: '50px', // Set desired height
              fontSize: '24px', // Adjust icon size
              color: 'red', // Change color if needed
            }}
            onClick={() => moveCanvas(-10, 0)}
          />
          <UpSquareTwoTone
            style={{
              width: '30px', // Set desired width
              height: '50px', // Set desired height
              fontSize: '24px', // Adjust icon size
              color: 'red', // Change color if needed
            }}
            onClick={() => moveCanvas(0, -10)}
          />
          <DownSquareTwoTone
            style={{
              width: '30px', // Set desired width
              height: '50px', // Set desired height
              fontSize: '24px', // Adjust icon size
              color: 'red', // Change color if needed
            }}
            onClick={() => moveCanvas(0, 10)}
          />
          <RightSquareTwoTone
            style={{
              width: '30px', // Set desired width
              height: '50px', // Set desired height
              fontSize: '24px', // Adjust icon size
              color: 'red', // Change color if needed
            }}
            onClick={() => moveCanvas(10, 0)}
          />
        </Menu.Item>
      </Menu>

      <canvas ref={canvasRef} width={1400} height={800} style={{ cursor: 'grab' }}></canvas>
      <div
        style={{
          position: 'absolute',
          bottom: '0',
          marginBottom: '10px',
          backgroundColor: 'white',
          borderRadius: '4px',
          padding: '4px',
          boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        }}
      >
        <div style={{ display: 'flex' }}>
          <div
            style={{
              border: '3px solid #ff9800',
              borderRadius: '5px',
              backgroundColor: '#ff9800',
              width: '30px',
              height: '2px',
              marginTop: '8px',
            }}
          ></div>{' '}
          Domain
        </div>
        <div style={{ display: 'flex' }}>
          <div
            style={{
              border: '3px solid #03a9f4',
              borderRadius: '5px',
              backgroundColor: '#03a9f4',
              width: '30px',
              height: '2px',
              marginTop: '8px',
            }}
          ></div>{' '}
          Application
        </div>
        <div style={{ display: 'flex' }}>
          <div
            style={{
              border: '3px solid #8bc34a',
              borderRadius: '5px',
              backgroundColor: '#8bc34a',
              width: '30px',
              height: '2px',
              marginTop: '8px',
            }}
          ></div>{' '}
          Integration
        </div>
      </div>
    </div>
  );
};

export default GraphView;
