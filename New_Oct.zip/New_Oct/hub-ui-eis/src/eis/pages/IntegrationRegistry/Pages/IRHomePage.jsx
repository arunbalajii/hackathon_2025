import React, { useEffect, useState } from 'react';
import SearchAllIntegrationColumns from '../components/registryTable/SearchAllIntegrationColumns';
import { Avatar, Button, Col, Popover, Row, Select, Space, Spin, Tag } from 'antd';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { UploadOutlined } from '@ant-design/icons';
import RegistryTable from '../components/registryTable/RegistryTable';

const styles = {
  column: {
    paddingTop: 12,
    paddingBottom: 12,
  },
  text: {
    marginBottom: 15,
  },
  IntegrationRegistry: {
    color: '#565D6DFF',
  },
};

const IntegrationRegistry = () => {
  const [data, setData] = useState([
    {
      integrationId: 1,
      name: 'AGUA_APDOWNPAYMENTS',
      description: 'Account Payable interface from Agua to SAP',
      identifier: 'I0180',
      domainName: ['Finance'],
      country: 'Mexico',
      owner: 'Enterprise Integration',
      sourceNames: ['AGUA'],
      targetNames: ['SAP PR2'],
      tags: 'AP, Stronghold, PI',
    },
    {
      integrationId: 2,
      name: 'GL_JORN_PST',
      description: 'Integration configuration to transmit GL data interface from HOST to SAP',
      identifier: 'I0481',
      domainName: ['Finance'],
      country: 'CN',
      owner: 'Enterprise Integration',
      sourceNames: ['HOST'],
      targetNames: ['SAP PR3'],
      tags: 'GL, Journal Post, China',
    },
    {
      integrationId: 3,
      name: 'GL_JORN_PST',
      description: 'Integration configuration to transmit GL data interface from HOST to SAP',
      identifier: 'I0481',
      domainName: ['Finance'],
      country: 'Mexico',
      owner: 'Enterprise Integration',
      sourceNames: ['HOST'],
      targetNames: ['SAP PR2'],
      tags: 'GL, Journal Post, Mexico',
    },
    {
      integrationId: 4,
      name: 'ASSOCIATE_DATA',
      description: 'File transfer configuration for Associate data files from HRDW to SAP',
      identifier: 'I0710',
      domainName: ['People Systems'],
      country: 'US',
      owner: 'Enterprise Integration',
      sourceNames: ['HRDW'],
      targetNames: ['SAP PR4'],
      tags: null,
    },
    {
      integrationId: 5,
      name: 'DISTRIBUTION_ARTICLE_MASTERDATA_POS',
      description: 'Article Master POS  data from SAP FMS to UK Legacy',
      identifier: 'I0937',
      domainName: ['Retail'],
      country: 'GB',
      owner: 'Enterprise Integration',
      sourceNames: ['SAP PRF'],
      targetNames: ['GPI'],
      tags: 'VIVA/GEORGE',
    },
  ]);

  const history = useHistory();

  const handleClick = (event, domainName) => {
    event.preventDefault();
    console.log(domainName);
    history.push('/eis/GraphView');
  };

  const columns = [
    {
      title: 'Id',
      dataIndex: 'identifier',
    },
    /*{
    title: 'Name',
    dataIndex: 'name'
  },*/
    {
      title: 'Description',
      dataIndex: 'description',
    },
    {
      title: 'Source',
      key: 'sourceNames',
      dataIndex: 'sourceNames',
      render: (sourceNames) => (
        <span>
          {sourceNames.map((source) => {
            let color = source.length > 5 ? 'geekblue' : 'green';
            if (source === 'loser') {
              color = 'volcano';
            }
            return (
              <Tag
                color={color}
                key={source}
                style={{
                  borderRadius: '2px',
                  border: '1px solid #d9d9d9',
                  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
                }}
              >
                {source.toUpperCase()}
              </Tag>
            );
          })}
        </span>
      ),
      filters: [
        {
          text: 'AGUA',
          value: 'AGUA',
        },
        {
          text: 'HRDW',
          value: 'HRDW',
        },
        {
          text: 'HOST',
          value: 'HOST',
        },
      ],
      onFilter: (value, record) => {
        return record.sourceNames != null && record.sourceNames.indexOf(value) !== -1;
      },
    },
    {
      title: 'Destination',
      key: 'destinations',
      dataIndex: 'targetNames',
      render: (destinations) => (
        <span>
          {destinations.map((destination) => {
            let color = destination.length > 5 ? 'geekblue' : 'green';
            if (destination === 'loser') {
              color = 'volcano';
            }
            return (
              <Tag
                color={color}
                key={destination}
                style={{
                  borderRadius: '2px',
                  border: '1px solid #d9d9d9',
                  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
                }}
              >
                {destination.toUpperCase()}
              </Tag>
            );
          })}
        </span>
      ),
      filters: [
        {
          text: 'SAP PR2',
          value: 'SAP PR2',
        },
        {
          text: 'SAP/VISTEX',
          value: 'SAP/VISTEX',
        },
      ],
      onFilter: (value, record) => {
        return record.targetNames != null && record.targetNames.indexOf(value) !== -1;
      },
    },
    {
      title: 'Domain',
      dataIndex: 'domainName',
      render: (domainName) => (
        <span>
          <Tag
            color={'green'}
            key={domainName}
            style={{
              borderRadius: '2px',
              border: '1px solid #d9d9d9',
              boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            }}
            onClick={(event, domainName) => handleClick(event, domainName)}
          >
            {domainName}
          </Tag>
        </span>
      ),
      filters: [
        {
          text: 'Finance',
          value: 'Finance',
        },
        {
          text: 'Retail',
          value: 'Retail',
        },
        {
          text: 'People Systems',
          value: 'People Systems',
        },
      ],
      onFilter: (value, record) =>
        record.domainName != null && record.domainName.indexOf(value) === 0,
    },
    {
      title: 'Owner',
      dataIndex: 'owner',
      filters: [],
      onFilter: (value, record) => {
        record.owner != null && record.owner.indexOf(value) === 0;
      },
    },
    {
      title: 'Country',
      dataIndex: 'country',
      filters: [
        {
          text: 'Mexico',
          value: 'Mexico',
        },
        {
          text: 'China',
          value: 'China',
        },
        {
          text: 'US',
          value: 'US',
        },
        {
          text: 'GB',
          value: 'GB',
        },
      ],
      onFilter: (value, record) => {
        return record.country != null && record.country.indexOf(value) === 0;
      },
    },
    {
      title: 'Tags',
      dataIndex: 'tags',
      render: (tags) => (
        <span>
          {tags !== null &&
            tags.split(',').map((tag) => {
              let color = tag.length > 5 ? 'geekblue' : 'green';
              if (tag === 'loser') {
                color = 'volcano';
              }
              return (
                <Tag
                  color={color}
                  key={tag}
                  style={{
                    borderRadius: '2px',
                    border: '1px solid #d9d9d9',
                    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
                  }}
                >
                  {tag.toUpperCase()}
                </Tag>
              );
            })}
        </span>
      ),
      filters: [
        {
          text: 'Stronghold',
          value: 'Stronghold',
        },
        {
          text: 'AP',
          value: 'AP',
        },
        {
          text: 'PI',
          value: 'PI',
        },
        {
          text: 'China',
          value: 'China',
        },
      ],
      onFilter: (value, record) => {
        return record.tags != null && record.tags.includes(value);
      },
    },
  ];

  const [tableColumns, setTableColumns] = useState(columns);
  const [optionSelected, SetOptionSelected] = useState('');

  const replaceColumnsOptions = [{ value: 'Name', label: 'Name' }];

  const handleOptionMessage = (option) => {
    interchangeColumns(option);
  };

  const reorderColumns = (columns, fromIndex, toIndex, option) => {
    const newColumns = [...columns];
    const removed = newColumns.at(newColumns.length - 1);

    console.log(option);
    const replacedColumn = {
      title: option,
      dataIndex: 'name',
    };

    newColumns.splice(newColumns.length - 1, 1, replacedColumn);

    return newColumns;
  };

  const interchangeColumns = (option) => {
    const newColumns = reorderColumns(tableColumns, 0, 1, option);
    setTableColumns(newColumns);
  };

  // TODO : change back
  const [isLoading, setIsLoading] = useState(false);

  const submitRequest = async () => {
    const response = await axios.get('/proxy/int/api/integration/all');
    setData(response.data);
    setIsLoading(false);
  };
  useEffect(() => {
    if (isLoading) {
      submitRequest().then((response) => {});
    }
  });

  const url = 'https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg';

  const chatBotDirect = () => {
    history.push('/eis/ChatBot');
  };
  const botText = <span> Integration Bot</span>;
  const buttonWidth = 80;
  const botContent = (
    <div>
      <p>Hi, click on me to help you</p>
    </div>
  );

  return (
    <div style={styles.IntegrationRegistry}>
      <header className='IntegrationRegistry-header'>
        <h1
          style={{
            fontWeight: 'bolder',
            fontFamily: 'Verdana',
            marginBottom: '0',
            textShadow: '1px 1px 4px rgba(0, 0, 0, 0.5)',
          }}
        >
          INTEGRATION REGISTRY
        </h1>
        <h3
          style={{
            fontFamily: 'Courier',
            color: '#171A1FFF',
            textShadow: '0px 0px 1px rgba(0, 0, 0, 0.5)',
          }}
        >
          Search any Integration easily
        </h3>
      </header>
      <Row>
        <Col span={22}></Col>
        <Col span={2}>
          <Button style={{ backgroundColor: '#e91e63', color: 'white' }} onClick={handleClick}>
            Upload <UploadOutlined />
          </Button>
        </Col>
      </Row>
      <Row style={styles.column}>
        <Col span={12}>
          <SearchAllIntegrationColumns style={{ width: '50%' }} />
        </Col>

        <Col span={8}></Col>
        <Col span={4} style={{ textAlign: 'right', paddingTop: '5px' }}>
          <a href=''>Clear filters</a>
          <Select
            value={optionSelected}
            options={replaceColumnsOptions}
            onChange={handleOptionMessage}
            style={{ width: '200px' }}
            placeholder='Replace last column'
          />
        </Col>
      </Row>
      {isLoading ? (
        <Spin size='large'></Spin>
      ) : (
        <RegistryTable dataSource={data} columns={tableColumns} />
      )}
      <Row>
        <Col span={23}></Col>
        <Col
          span={1}
          style={{
            marginTop: '30px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            borderRadius: '30px',
            textAlign: 'center',
            padding: '10px',
            backgroundColor: '#ffecb3',
          }}
        >
          <Popover placement='topLeft' title={botText} content={botContent}>
            <Avatar src={<img src={url} alt='avatar' />} onClick={chatBotDirect} />
          </Popover>
        </Col>
      </Row>
    </div>
  );
};

export default IntegrationRegistry;
