import { Col, Popover, Row } from 'antd';
import React, { useEffect, useRef, useState } from 'react';
import Arrow from './Arrow';
import { QuestionCircleTwoTone } from '@ant-design/icons';

const styles = {
  container: {
    height: '100%',
    width: '100%',
    fontFamily: 'Verdana',
  },
  pane: {
    backgroundColor: '#F5F1FEFF',
    height: '100%',
    width: '100%',
    border: '1px solid black',
    borderRadius: '4px',
    padding: '10px',
    marginTop: '15px',
    marginBottom: '10px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-around',
  },
  /*
   container: {
       height: "100%",
       width: "100%",
       fontFamily: "Verdana",
   },
   pane: {
       backgroundColor: "#F5F1FEFF",
       height: "100%",
       width: "100%",
   },
  
   sectionBox:{
       padding: "20px 10px 20px 10px",
       justifyContent: "center",
       display: "flex",
       alignItems: "center",
   },*/
  sectionBox: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-around',
  },
  /*
    connectionPoints: {
        width: "160px",
        height: "80px",
        border: "3px solid #8E61F1FF",
        backgroundColor: "#D3C1FAFF",
        borderRadius: "40px",
        justifyContent: "center",
        display: "flex",
        alignItems: "center",
    },*/
  connectionPoints: {
    width: '160px',
    height: '80px',
    border: '3px solid #8E61F1FF',
    backgroundColor: '#D3C1FAFF',
    borderRadius: '40px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
  },
  techPoints: {
    border: '2px solid #1E2128FF',
    backgroundColor: '#FFD317FF',
    borderRadius: '4px',
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
    width: '150px',
    height: '150px',
    margin: '10px',
  },
  destinationPoints: {
    width: '160px',
    height: '80px',
    border: '3px solid #8E61F1FF',
    backgroundColor: '#D3C1FAFF',
    borderRadius: '40px',
    display: 'flex',
    right: '10%',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
  },
  technologyBox: {
    height: '80%',
    width: '80%',
    border: '3px solid #8E61F1FF',
    backgroundColor: '#D3C1FAFF',
    borderRadius: '15px',
    padding: '40px 2px 10px 2px',
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
  },
  techonologyPane: {
    position: 'absolute',
    border: '3px solid #8E61F1FF',
    backgroundColor: '#D3C1FAFF',
    borderRadius: '15px',
    height: '80%',
    width: '40%',
    left: '30%',
    top: '10%',
    zIndex: '0',
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
  },
  /*
    sourceBox: {
        height: "80%",
        width: "80%",
        padding: "40px 2px 10px 2px",
        justifyContent: "right",
        display: "flex",
        alignItems: "center",
    },*/
  sourceBox: {
    height: '80%',
    width: '80%',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-around',
  },
  destinationBox: {
    height: '80%',
    width: '80%',
    padding: '40px 2px 10px 2px',
    justifyContent: 'left',
    display: 'flex',
    alignItems: 'center',
  },
  centerAlign: {
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
  },
};

function IntegrationFlowTest(params) {
  // Points array details in graph
  const [sources, setSources] = useState(['Source 1', 'sdf']);
  const [destinations, setDestinations] = useState(['Destination 1', 'Destiona 2']);
  const [technologies, setTechnologies] = useState(['Armory', 'SAP', 'Armada']);

  // Arrow coordinates
  const [featureAPosition, setFeatureAPosition] = useState({
    x: 10,
    y: 55,
  });

  const [featureBPosition, setFeatureBPosition] = useState({
    x: 290,
    y: 150,
  });

  const [featureAPositionDest, setfeatureAPositionDest] = useState({
    x: -30,
    y: 25,
  });

  const featureBPositionDest = {
    x: 100,
    y: 25,
  };

  // Constants for pane
  const paneRef = useRef(null);
  const [paneCoordinates, setpaneCoordinates] = useState({
    right: 100,
    top: 100,
    height: 100,
    width: 100,
  });

  const [coordinates, setcoordinates] = useState([
    {
      right: 100,
      top: 100,
    },
    {
      right: 100,
      top: 100,
    },
  ]);
  const [destCoordinates, setdestCoordinates] = useState([
    {
      right: 100,
      top: 100,
    },
    {
      right: 100,
      top: 100,
    },
  ]);

  // Constants for tech boxes
  const divRefs = useRef([]);
  const techRefs = useRef([]);
  const destRefs = useRef([]);
  divRefs.current = [];
  techRefs.current = [];
  destRefs.current = [];

  const setRef = (element) => {
    if (element && !divRefs.current.includes(element)) {
      divRefs.current.push(element);
    }
  };

  const setTechRef = (element) => {
    if (element && !techRefs.current.includes(element)) {
      techRefs.current.push(element);
    }
  };

  const setDestRef = (element) => {
    if (element && !destRefs.current.includes(element)) {
      destRefs.current.push(element);
    }
  };

  useEffect(() => {
    setSources(params.sourceList);
    setDestinations(params.targetList);
    setTechnologies(params.technologyList);

    let paneCoordinateslocal = {};
    let coordinatesArray = [];
    let destsArray = [];

    if (paneRef.current) {
      const paneRect = paneRef.current.getBoundingClientRect();
      setpaneCoordinates({
        left: paneRect.left,
        top: paneRect.top,
        width: paneRect.width,
        height: paneRect.height,
      });
      paneCoordinateslocal = {
        left: paneRect.left,
        top: paneRect.top,
        width: paneRect.width,
        height: paneRect.height,
      };
    }

    const findSourcePoints = () => {
      let rightmostX = 0;
      let topmostY = 0;
      let coordinateArray = [];
      let destArray = [];

      divRefs.current.forEach((div) => {
        if (div) {
          const rect = div.getBoundingClientRect();
          if (rect.right > rightmostX) {
            rightmostX = rect.right;
            topmostY = rect.top;
          }

          coordinateArray.push({ right: rect.right, top: rect.top });
        }
      });

      destRefs.current.forEach((dest) => {
        if (dest) {
          const rect = dest.getBoundingClientRect();
          destArray.push({ left: rect.left, top: rect.top });
        }
      });
      destsArray = destArray;
      coordinatesArray = coordinateArray;
      setcoordinates(coordinateArray);
      setdestCoordinates(destArray);
    };

    findSourcePoints();

    // Optional: add a resize listener to update coordinates if the window resizes
    window.addEventListener('resize', findSourcePoints);

    return () => {
      window.removeEventListener('resize', findSourcePoints);
    };
  }, [sources, destinations, technologies]);

  const TechBoxes = ({ key, top, left, text, ref }) => {
    return (
      <div
        key={key}
        style={{
          border: '2px solid #1E2128FF',
          backgroundColor: '#FFD317FF',
          borderRadius: '4px',
          justifyContent: 'center',
          display: 'flex',
          alignItems: 'center',
          width: '100px',
          height: '50px',
          position: 'absolute',
          left: left,
          top: top,
        }}
        ref={ref}
      >
        {text}
      </div>
    );
  };

  const DestBoxes = ({ key, top, left, text }) => {
    return (
      <Popover placement='bottom' title={text} trigger='click' style={{ position: 'absolute' }}>
        <div
          ref={setDestRef}
          key={key}
          style={{
            width: '160px',
            height: '80px',
            border: '3px solid #8E61F1FF',
            backgroundColor: '#D3C1FAFF',
            borderRadius: '40px',
            display: 'flex',
            right: '10%',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'absolute',
            zIndex: 3,
            left: left,
            top: top,
          }}
        >
          {text}
        </div>
      </Popover>
    );
  };

  const content = () => {
    <div>
      <p>Content</p>
      <p>Content</p>
    </div>;
  };

  return (
    <div style={styles.container}>
      <h5
        style={{
          position: 'absolute',
          color: '#6D31EDFF',
          fontFamily: '',
          fontWeight: 'bold',
          padding: '10px',
        }}
        top='0'
      >
        <QuestionCircleTwoTone twoToneColor='#6D31EDFF' /> Click on any source to check the flow
      </h5>

      <div style={styles.pane} ref={paneRef}>
        {sources.map((source, index) => {
          return (
            <Popover
              placement='bottom'
              title={source}
              trigger='click'
              style={{ position: 'absolute' }}
            >
              <div ref={setRef} style={styles.connectionPoints}>
                {source}
              </div>
            </Popover>
          );
        })}
        {sources.map((source, index) => {
          return (
            <Arrow
              startPoint={{
                x: -paneCoordinates.left + coordinates[index].right + 30,
                y: -paneCoordinates.top + coordinates[index].top + 30,
              }}
              endPoint={featureBPosition}
            />
          );
        })}

        <div style={styles.techonologyPane}></div>
        {technologies.map((technology, index) => {
          return (
            <TechBoxes
              key={index}
              left={paneCoordinates.left + paneCoordinates.width / 4}
              top={
                paneCoordinates.top + (paneCoordinates.height / (2 * technologies.length)) * index
              }
              text={technology}
              ref={setTechRef}
            />
          );
        })}
        {destinations.map((destination, index) => {
          return (
            <DestBoxes
              key={index}
              left={paneCoordinates.left + (5 * paneCoordinates.width) / 8}
              top={
                paneCoordinates.top +
                ((3 * paneCoordinates.height) / (2 * destination.length)) * (index + 1)
              }
              text={destination}
            />
          );
        })}

        {destinations.map((destination, index) => {
          return (
            <Arrow
              endPoint={{
                x: paneCoordinates.left + (5 * paneCoordinates.width) / 8,
                y:
                  paneCoordinates.top +
                  ((9 * paneCoordinates.height) / (2 * destination.length)) * index,
              }}
              startPoint={{
                x: (3 * paneCoordinates.left) / 8 + (5 * paneCoordinates.width) / 8,
                y:
                  paneCoordinates.top -
                  10 +
                  ((3 * paneCoordinates.height) / (2 * destination.length)) * (index + 1),
              }}
            />
          );
        })}
      </div>

      {/* <Row style={styles.pane}>
                <Col span={8} style={styles.sectionBox}>
                {sources.map((source)=>{
                    return <div ref={divRef} style={styles.connectionPoints}>{source}: ({coordinates.right}px, {coordinates.top}px)</div>
                })}
                    <Arrow 
                        startPoint={featureAPosition} 
                        endPoint={featureBPosition} 
                    />
                 <div style={styles.sourceBox}>

                    {sources.map((source)=>{
                        return <div style={styles.connectionPoints}>      
                            <p>{source}</p>
                            </div>
                    })}
                    </div>
                     <Arrow 
                        startPoint={featureAPosition} 
                        endPoint={featureBPosition} 
                    /> 
                </Col>
                <Col span={8} style={styles.centerAlign}>
                    <div style={styles.technologyBox}>
                        {technologies.map((technology)=>{
                            return <div style={styles.techPoints}>{technology}</div>
                        })}
                    </div>
                </Col>
                <Col span={8} style={styles.sectionBox}>
                <Arrow 
                        startPoint={featureAPositionDest} 
                        endPoint={featureBPositionDest} 
                    />
                    <div style={styles.destinationBox}>
                        {destinations.map((destination)=>{
                            return <div style={styles.connectionPoints}>{destination}</div>
                            
                        })}
                    </div>

                </Col>
            </Row>
            */}
      {console.log(featureAPosition)}
    </div>
  );
}

export default IntegrationFlowTest;
