import { Col, Row } from 'antd';
import React from 'react';

const styles = {
  card: {
    display: 'grid',
    borderRadius: '1rem',
    boxSizing: 'border-box',
    userSelect: 'none',
    padding: '0px 20px',
    ':hover': {
      cursor: 'pointer',
    },
  },
  bold: {
    fontWeight: 'bold',
    padding: '10px',
  },
  text: {
    padding: '10px 2px 10px 2px',
    overflow: 'scroll',
  },
  centerAlign: {
    justifyContent: 'center',
    display: 'flex',
    alignItems: 'center',
  },
  schemaBox: {
    padding: '10px',
    border: '4px solid #BDC1CAFF',
    borderRadius: '3px',
    backgroundColor: '#DEE1E6FF',
    boxShadow: '0px 2px 5px #171a1f, 0px 0px 2px #171a1f',
    justifyContent: 'center',
    alignItems: 'center',
    height: '300px',
    width: '90%',
    overflowY: 'scroll',
  },
};

const schemaSample = `<?xml version="1.0" encoding="UTF-8" ?>
                        <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
                        <xs:element name="shiporder">
                        <xs:complexType>
                            <xs:sequence>
                            <xs:element name="orderperson" type="xs:string"/>
                            <xs:element name="shipto">
                                <xs:complexType>
                                <xs:sequence>
                                    <xs:element name="name" type="xs:string"/>
                                    <xs:element name="address" type="xs:string"/>
                                    <xs:element name="city" type="xs:string"/>
                                    <xs:element name="country" type="xs:string"/>
                                </xs:sequence>
                                </xs:complexType>
                            </xs:element>
                            <xs:element name="item" maxOccurs="unbounded">
                                <xs:complexType>
                                <xs:sequence>
                                    <xs:element name="title" type="xs:string"/>
                                    <xs:element name="note" type="xs:string" minOccurs="0"/>
                                    <xs:element name="quantity" type="xs:positiveInteger"/>
                                    <xs:element name="price" type="xs:decimal"/>
                                </xs:sequence>
                                </xs:complexType>
                            </xs:element>
                            </xs:sequence>
                            <xs:attribute name="orderid" type="xs:string" use="required"/>
                        </xs:complexType>
                        </xs:element>
                        </xs:schema>`;

function SystemInfo(params) {
  return (
    <div style={styles.card}>
      <Row>
        <Col span={8} style={styles.bold}>
          {params.infoName}:
        </Col>
        <Col span={16} style={styles.text}>
          {params.sourceName}
        </Col>
      </Row>
      <Row>
        <Col span={8} style={styles.bold}>
          Protocol:
        </Col>
        <Col span={16} style={styles.text}>
          {params.protocol}
        </Col>
      </Row>
      <Row>
        <Col span={8} style={styles.bold}>
          Endpoint:
        </Col>
        <Col span={16} style={styles.text}>
          {params.endpoint}
        </Col>
      </Row>
      <Row>
        <Col span={8} style={styles.bold}>
          Contact:
        </Col>
        <Col span={16} style={styles.text}>
          {' '}
          {/*<a
            href={`mailto:${params.contact.split('<')[1].slice(0, -1)}?subject=${encodeURIComponent(
              'Info regarding integration needed'
            )}`}
          >
            {params.contact}
          </a>*/}
        </Col>
      </Row>
      <Row>
        <Col span={24} style={styles.bold}>
          Schema:
        </Col>
      </Row>
      <Row>
        <Col span={24} style={styles.bold}>
          <div style={styles.schemaBox}>{params.schema != null ? params.schema : schemaSample}</div>
        </Col>
      </Row>
    </div>
  );
}

export default SystemInfo;
