import React, { useEffect, useState } from 'react';

import { Divider, Pagination } from 'antd';
import { ArrowLeftOutlined, ArrowRightOutlined, ControlTwoTone } from '@ant-design/icons';
import SystemInfo from './SystemInfo';

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFFFF',
    width: '70%',
    margin: 'auto',
    borderRadius: '8px',
    borderWidth: '1px',
    borderColor: '#DEE1E6FF',
    borderStyle: 'solid',
    height: 'fill',
  },
  cardContainer: {
    position: 'relative',
    padding: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
  },
  card: {
    backgroundColor: 'red',
  },
  highlightText: {
    fontFamily: 'Verdana',
    color: '#6D31EDFF',
  },
  dot: {
    height: '15px',
    width: '15px',
    backgroundColor: '#DEE1E6FF',
    borderRadius: '50%',
    display: 'inline-block',
  },
};

function ConnectionInfo(params) {
  const [index, setIndex] = useState(0);

  const onChange = (page, pageSize) => {
    console.log('params', page, pageSize);
    setIndex((page - 1) % page);
  };

  useEffect(() => {}, [params.data]);

  const itemRender = (current, type, originalElement) => {
    if (type === 'prev') {
      return (
        <a>
          <ArrowLeftOutlined />
        </a>
      );
    }
    if (type === 'next') {
      return (
        <a>
          <ArrowRightOutlined />
        </a>
      );
    }
    if (type === 'page') {
      return (
        <a>
          <span style={styles.dot}></span>
        </a>
      );
    }
    return originalElement;
  };

  return (
    <div style={styles.container}>
      <div className='card' style={styles.cardContainer}>
        <h3 style={styles.highlightText}>
          <ControlTwoTone
            twoToneColor={'#6D31EDFF'}
            style={{ padding: '5px', textColor: '#6D31EDFF' }}
          />{' '}
          {params.infoName} information
        </h3>
        <Divider style={{ margin: '0', backgroundColor: '#DEE1E6FF' }} />

        <SystemInfo
          key={params.data.at(index).id}
          index={index}
          dataIndex={index}
          sourceName={params.data.at(index).name}
          protocol={params.data.at(index).protocol}
          endpoint={params.data.at(index).endpoint}
          contact={params.data.at(index).contactName}
          schema={params.data.at(index).schemaName}
          infoName={params.infoName}
        />

        <Pagination
          onChange={onChange}
          total={params.data.length}
          style={{ textAlign: 'center' }}
          itemRender={itemRender}
        />
      </div>
    </div>
  );
}

export default ConnectionInfo;
