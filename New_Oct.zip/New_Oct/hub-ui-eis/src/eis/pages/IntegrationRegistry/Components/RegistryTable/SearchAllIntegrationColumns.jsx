import { Input } from 'antd';
import React from 'react';
import { SearchOutlined } from '@ant-design/icons';

const styles = {
  searchBar: {
    borderRadius: '8px',
    paddingTop: '5px',
    paddingBottom: '5px',
    boxShadow: '0 1px 8px rgba(0, 0, 0, 0.2)',
    antInput: {
      backgroundColor: '#F3F4F6FF',
      color: 'red',
    },
  },
};

const SearchAllIntegrationColumns = () => {
  return (
    <Input
      style={styles.searchBar}
      className='searchBar'
      placeholder='Search by any field'
      prefix={<SearchOutlined style={{ color: 'rgba(0,0,0,.25)' }} />}
    />
  );
};

export default SearchAllIntegrationColumns;
