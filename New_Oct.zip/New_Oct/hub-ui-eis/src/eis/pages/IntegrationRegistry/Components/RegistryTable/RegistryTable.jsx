import { Table } from 'antd';
import React from 'react';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';

function RegistryTable(params) {
  const styles = {
    main: {
      backgroundColor: '#f1f1f1',
      width: '100%',
      padding: '10px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    },
    inputText: {
      padding: '10px',
      color: 'red',
      backgroundColor: 'red',
    },
  };

  const dispatch = useDispatch();
  const registryData = useSelector((state) => state.registry.data);

  useEffect(() => {
    dispatch(fetchRegistryData());
  }, [dispatch]);

  const onChange = (pagination, filters, sorter, extra) => {
    console.log('params', pagination, filters, sorter, extra);
  };

  const history = useHistory();

  const handleClick = (id) => {
    const props = { id: id };
    history.push('/eis/MoreDetails', props);
  };

  return (
    <Table
      style={styles.main}
      bordered
      columns={params.columns}
      dataSource={params.dataSource}
      onChange={onChange}
      showSorterTooltip={{
        target: 'sorter-icon',
      }}
      /* expandable={{
      expandedRowRender: (record) => (
        <p
          style={{
            margin: 0,
          }}
        >
          {record.description}
        </p>
      ),
      rowExpandable: (record) => record.name !== 'Not Expandable',
      expandRowByClick: true,
      expandIcon: ({ expanded, onExpand, record }) =>{
        return <div>{record.id}</div>
      }
    }}*/
      rowHoverable
      onRow={(record) => {
        return {
          onClick: () => {}, // click row
          onDoubleClick: () => {
            handleClick(record.integrationId);
          }, // double click row
          onContextMenu: () => {}, // right button click row
          onMouseEnter: () => {}, // mouse enter row
          onMouseLeave: () => {}, // mouse leave row
        };
      }}
    />
  );
}

export default RegistryTable;
