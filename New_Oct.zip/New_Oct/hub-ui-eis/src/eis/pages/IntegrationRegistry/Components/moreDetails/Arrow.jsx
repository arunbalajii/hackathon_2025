import React, { useEffect, useRef } from 'react';

function Arrow({ startPoint, endPoint }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    // Draw the arrow line
    ctx.beginPath();
    ctx.moveTo(10, 50);
    ctx.lineTo(150, 50);
    ctx.lineWidth = 4;
    ctx.strokeStyle = 'blue';
    ctx.stroke();

    // Draw the arrowhead
    ctx.beginPath();
    ctx.moveTo(150, 40);
    ctx.lineTo(150, 60);
    ctx.lineTo(170, 50);
    ctx.closePath();
    ctx.fillStyle = 'blue';
    ctx.fill();
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        top: `${startPoint.y}px`,
        left: `${startPoint.x}px`,
        zIndex: '3',
      }}
      width='220'
      height='100'
    />
  );
}

export default Arrow;
