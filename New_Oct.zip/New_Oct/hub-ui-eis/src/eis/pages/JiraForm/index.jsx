import React, { useState } from 'react';
import {
  Form,
  Input,
  Button,
  Modal,
  Card,
  Breadcrumb,
  Alert,
  Typography,
  Col,
  Row,
  DatePicker,
  Tooltip,
} from 'antd';
import { UserLookup } from '@hub/ui-lib';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { InfoCircleOutlined } from '@ant-design/icons';

const { Text, Title } = Typography;
const { TextArea } = Input;

const style = {
  column: {
    padding: 10,
  },
  text: {
    marginBottom: 15,
  },
  form: {
    marginLeft: 50,
    border: 1,
    borderColor: 'rgb(4, 31, 65)',
    borderStyle: 'solid',
    borderRadius: 8,
    padding: 40,
  },
};

const JiraForm = () => {
  const [title, setTitle] = useState('');
  const [techLead, setTechLead] = useState('');
  const [participant, setParticipant] = useState('');
  const [manager, setManager] = useState('');
  const [description, setDescription] = useState('');
  const [market, setMarket] = useState('');
  const [businessBenefit, setBusinessBenefit] = useState('');
  const [costCenter, setCostCenter] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [label, setLabel] = useState('');
  const [alert, setAlert] = useState(null);
  const user = useSelector((state) => state.user);
  const [visible, setVisible] = useState('');
  const [modalTitle, setModalTitle] = useState(false);
  const [responseMessage, setResponseMessage] = useState({});
  const [responseText, setResponseText] = useState('');
  const [responseLink, setResponseLink] = useState('');
  const [responseLinkText, setResponseLinkText] = useState('');

  const [form] = Form.useForm();

  const ResponseMessage = () => {
    return (
      <div>
        <p>{responseText}</p>
        <p>
          <a href={`${responseLink}/${responseLinkText}`} target='_blank'>
            {responseLinkText}
          </a>
        </p>
      </div>
    );
  };

  const handleModalOk = () => {
    setVisible(false);
    window.location.reload();
  };

  const submitRequest = async () => {
    const jiraFormBody = {
      fields: {
        project: {
          id: '30504',
        },
        issuetype: {
          id: '7',
        },
        customfield_10701: {
          id: '10906',
        },
        customfield_10211: {
          id: '10102',
        },
        reporter: { name: user.userId },
        summary: title,
        description: description,
        customfield_21250: { name: form.getFieldValue('techLead').userId },
        customfield_20900: [{ name: participant.userId }],
        environment: market,
        customfield_21267: form.getFieldValue('manager').userFullName,
        labels: [label],
        customfield_10400: deliveryDate,
        customfield_21200: businessBenefit,
        customfield_10302: costCenter,
      },
    };

    axios
      .post('/proxy/eis/automation/jira', jiraFormBody)
      .then((response) => {
        setVisible(true);
        setModalTitle('Success');
        setResponseText('JIRA is Created with requestId ');
        setResponseLink('https://jira-stage.walmart.com/browse/');
        setResponseLinkText(response.data.key);
      })
      .catch(function (error) {
        setVisible(true);
        setModalTitle('Error');
        setResponseText('JIRA Could not be created! Please reach out to our team ');
        setResponseLink('https://walmart.enterprise.slack.com/archives/CL241PFFF');
        setResponseLinkText('help_integrations');
      });
  };

  return (
    <div>
      <Breadcrumb>
        <Breadcrumb.Item href='/'> Home </Breadcrumb.Item>
        <Breadcrumb.Item href='/eis'> EIS </Breadcrumb.Item>
        <Breadcrumb.Item> Work Intake </Breadcrumb.Item>
      </Breadcrumb>

      <Row>
        <Col style={style.column} span={24}>
          <Title level={3}> Work Intake - EIT</Title>
        </Col>
      </Row>
      <Card style={{ width: 1300 }}>
        {alert}

        <Row>
          <Col style={style.column} span={24}>
            <Title level={5}>
              Please fill in the required fields below to submit a work intake request for the
              Integrations team.
            </Title>
            <Row>
              You can refer to this&nbsp;
              <a
                href={'https://confluence.walmart.com/pages/viewpage.action?pageId=1171106724'}
                target='_blank'
              >
                confluence page
              </a>
              &nbsp;for help in placing Work Intake Requests:
            </Row>
          </Col>
        </Row>

        <Form form={form} onFinish={submitRequest}>
          <Row>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Title
              </Text>
              <Form.Item
                name='title'
                rules={[
                  { required: true, message: 'Please enter the title of the Integration request!' },
                ]}
              >
                <Input
                  size='large'
                  placeholder='Title of the Integration request'
                  onChange={(ev) => setTitle(ev.currentTarget.value)}
                  value={title}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row align='middle'>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Description
              </Text>
              <Form.Item>
                <Tooltip
                  title={
                    <div>
                      <p>Please provide:</p>
                      <p>1. Source and Target systems</p>
                      <p>2. Description of the project</p>
                      <p>3. Design (how do you want to communicate between the applications)</p>
                      <p>4. # of interfaces</p>
                      <p>
                        5. Any additional notes like available timings for a call or details of
                        timesheet approver in fieldglass
                      </p>
                    </div>
                  }
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item
                    name='description'
                    rules={[
                      {
                        required: true,
                        message: 'Please enter the title of the Integration request!',
                      },
                    ]}
                  >
                    <TextArea
                      rows={6}
                      placeholder='Enter the description'
                      autoSize={{
                        minRows: 6,
                        maxRows: 10,
                      }}
                      onChange={(ev) => setDescription(ev.target.value)}
                      value={description}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Technical Lead
              </Text>
              <Form.Item>
                <Tooltip
                  title='Technical Point of Contact'
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item
                    name='techLead'
                    rules={[{ required: true, message: 'Please select a user!' }]}
                  >
                    <UserLookup
                      style={{ width: 600 }}
                      fieldId='techLeadId'
                      setUser={(user) => form.setFieldsValue({ techLead: user })}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                Participant
              </Text>
              <Form.Item>
                <Tooltip
                  title='Please list out any additional individuals who would like to keep track of this work intake'
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item name='participant'>
                    <UserLookup
                      style={{ width: 600 }}
                      fieldId='participantId'
                      setUser={(user) => setParticipant(user)}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row align='middle'>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Market/Location
              </Text>
              <Form.Item>
                <Tooltip
                  title={
                    <div>
                      <p>Market and geographical region details. E: China, Mexico, APAC, NAMR</p>
                      <p>
                        This will help us assign the request to the appropriate leads that works in
                        a closely matching timezone.
                      </p>
                    </div>
                  }
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item name='market'>
                    <TextArea
                      rows={6}
                      placeholder='Enter the Market/Location'
                      autoSize={{
                        minRows: 6,
                        maxRows: 10,
                      }}
                      onChange={(ev) => setMarket(ev.target.value)}
                      value={market}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                Manager
              </Text>
              <Form.Item>
                <Tooltip
                  title='Please designate the manager overseeing this effort.'
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item
                    name='manager'
                    rules={[{ required: true, message: 'Please select a user!' }]}
                  >
                    <UserLookup
                      style={{ width: 600 }}
                      fieldId='managerId'
                      setUser={(user) => form.setFieldsValue({ manager: user })}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Domain
              </Text>
              <Form.Item
                name='label'
                rules={[{ required: true, message: 'Please enter the domain name!' }]}
              >
                <Input
                  size='large'
                  placeholder='Specify the domain (HR, ISM, MFG, etc.)'
                  onChange={(ev) => setLabel(ev.currentTarget.value)}
                  value={label}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Expected Delivery Date
              </Text>
              <Form.Item
                name='deliveryDate'
                rules={[
                  { required: true, message: 'Please enter the title of the Integration request!' },
                ]}
              >
                <DatePicker
                  placeholder='Select the date'
                  style={{ width: 600 }}
                  onChange={(date, dateString) => setDeliveryDate(dateString)}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row align='middle'>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                Business Benefit
              </Text>
              <Form.Item>
                <Tooltip
                  title={
                    <div>
                      <p>
                        Share with us the business value (in $)/ value add or goal of this
                        integration request in few words.
                      </p>
                      <p>
                        If this request to related to meeting Compliance please mention that as
                        well.
                      </p>
                    </div>
                  }
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item
                    name='businessBenefit'
                    rules={[{ required: true, message: 'Please enter the business value!' }]}
                  >
                    <TextArea
                      rows={6}
                      placeholder='Enter the business value'
                      autoSize={{
                        minRows: 6,
                        maxRows: 10,
                      }}
                      onChange={(ev) => setBusinessBenefit(ev.target.value)}
                      value={businessBenefit}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row align='middle'>
            <Col style={style.column} span={12}>
              <Text style={style.text} strong>
                <Text type='danger'>* &nbsp;</Text>
                SOW/Cost Center
              </Text>
              <Form.Item>
                <Tooltip
                  title='Details of SOW or cost center'
                  overlayStyle={{ maxWidth: '600px' }}
                  placement='right'
                  mouseEnterDelay={0.2}
                >
                  <Form.Item
                    name='costCenter'
                    rules={[{ required: true, message: 'Please enter the cost center!' }]}
                  >
                    <TextArea
                      rows={6}
                      placeholder='Enter the cost center'
                      autoSize={{
                        minRows: 6,
                        maxRows: 10,
                      }}
                      onChange={(ev) => setCostCenter(ev.target.value)}
                      value={costCenter}
                    />
                  </Form.Item>
                </Tooltip>
              </Form.Item>
            </Col>
          </Row>

          <Row style={{ textAlign: 'center', marginTop: 20 }}>
            <Col style={style.column} span={6}>
              <Form.Item>
                <Button type='primary' htmlType='submit'>
                  Submit
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>

        <Modal title={modalTitle} open={visible} onOk={handleModalOk}>
          <ResponseMessage message={responseMessage} />
        </Modal>
      </Card>
    </div>
  );
};

export default JiraForm;
