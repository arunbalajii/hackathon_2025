/**
 * Convert the incoming payload off of the API into a structure
 * understood by the form.
 */
 export function convertFromApiToFormStructure(payload) {
    const detail = { ...payload['detail'] } || {};
    const incomingEnvs = payload['environments'];

    const newEnvironments = {};

    if(incomingEnvs) {
      incomingEnvs.forEach((curEnv) => {
        let key = curEnv.type && curEnv.type.toLowerCase();
        newEnvironments[key] = { ...curEnv };
      });
    }

    detail.environments = newEnvironments;

    return detail;
  }

  /**
   * Converts the form data into a structure understood by the
   * backend API.
   */
  export function convertToApiStructure(formData) {
    // detail:
    const detail = { ...formData };
    delete detail.environments;

    // environments:
    let environments = [];
    if (Object.keys(formData).includes('environments')) {
      const envInput = formData['environments'];
      Object.keys(envInput).forEach((envKey) => {
        const currentEnv = envInput[envKey];
        let type = envKey && envKey.toUpperCase();
        const newEnv = {
          ...currentEnv,
          type: type,
        };

        environments.push(newEnv);
      });
    }

    return { detail, environments };
  }
