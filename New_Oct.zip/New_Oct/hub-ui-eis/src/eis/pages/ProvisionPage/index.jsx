import React from 'react';
import { getBreadCrumbs, ResourceProvision } from '@hub/ui-lib';
import { useSelector } from 'react-redux';
import { config } from '../../config';
import { Link } from 'react-router-dom';
import { convertFromApiToFormStructure, convertToApiStructure } from './formMappings';

const ProvisionPage = ({ match }) => {
  const user = useSelector((state) => state.user);
  const resourceId = match && match.params && match.params.id;

  const fields = require('./provisionForm.json');
  const { product, resource } = config;

  const resourceApiPath = resourceId
    ? `/proxy/${product.id}/${resource.id}/${resourceId}`
    : `/proxy/${product.id}/${resource.id}`;

  const title = {
    create: `Create ${resource.name}`,
    modify: `Modify ${resource.name}`,
  };

  const breadcrumbs = getBreadCrumbs(product, resource, resourceId);

  const props = {
    resourceApiPath,
    resourceId,
    product,
    componentId: config.resource.id,
    title,
    breadcrumbs,
    routerLink: Link,
    formId: `${product.id}-${resource.id}`,
    user,
    fields,
    dataMappingFunc: convertFromApiToFormStructure,
    payloadMappingFunc: convertToApiStructure,
  };
  return <ResourceProvision {...props} />;
};

export default ProvisionPage;
