import React from 'react';
import { useSelector } from 'react-redux';
import { buildMenu, SideMenu, UnknownError } from '@hub/ui-lib';
import { ErrorBoundary } from 'react-error-boundary';
import { Switch, Route, Link, Redirect, withRouter } from 'react-router-dom';
import { config } from './config';
import JiraForm from './pages/JiraForm';
import MFT from './pages/MFT/home';
import IntegrationRegistry from './pages/IntegrationRegistry/Pages/IRHomePage';
import MoreDetails from './pages/IntegrationRegistry/Pages/MoreDetails';
import GraphView from './pages/IntegrationRegistry/Pages/GraphView';
import { Typography, Card } from 'antd';
const { Title } = Typography;
import { Spinner } from '@hub/ui-lib';

const canAccessRoute = (isPublic, groupsWithAccess, userGroups, defaultAllow = false) =>
  isPublic ||
  groupsWithAccess.some((groupWithAccess) => userGroups.includes(groupWithAccess)) ||
  defaultAllow;

const Admins = ({ message }) => {
  return (
    <Card style={{ width: 1300 }}>
      <div className='content'>
        <div className='title-holder'>
          <Title level={3}>This page is only for ADMINS!</Title>
          <p>{message}</p>
        </div>
      </div>
    </Card>
  );
};

const SideMenuWithRouter = withRouter(SideMenu);

const ProtectedRoute = ({ path, component, module }) => {
  // Feature flags are set per environment. Prod URL here: https://console.dx.walmart.com/controlcenter/products/feature/eis
  // Change host in URL to environment you need to set the flags in
  const eisFeatures = useSelector((state) => state.features.eis);
  const user = useSelector((state) => state.user);

  // Until these two are available in store we can not really decide if canView or not so will display spinner until then
  if (!user || !eisFeatures) {
    return <Spinner size='large' />;
  }

  const canView = canAccessRoute(
    eisFeatures?.[module]?.isPublic ?? false,
    eisFeatures?.[module]?.accessGroups ?? [],
    user?.groups ?? []
  );

  return canView ? <Route path={path} component={component} /> : <Admins />;
};

const { product, resource } = config;

const menuItems = buildMenu(product.name, [
  {
    text: 'Work Intake',
    route: '/eis/createWorkRequest',
    icon: 'file',
    activePaths: ['/eis/createWorkRequest'],
  },
  {
    text: 'MFT',
    route: '/eis/mft',
    icon: 'accounts',
    activePaths: ['/eis/mft'],
  },
  {
    text: 'Integration Registry',
    route: '/eis/integrationRegistry',
    icon: 'file',
    activePaths: ['/eis/integrationRegistry'],
  },
]);

const Main = () => {
  // An example of fetching product feature flag flags from redux and logging them to the console
  const features = useSelector((state) => state.features);
  console.info(features); // All features, including global ones
  console.info(features.eis); // Your product specific features are under your product's ID

  return (
    <ErrorBoundary FallbackComponent={UnknownError}>
      <div className='app-sider'>
        <SideMenuWithRouter menuItems={menuItems} routerLink={Link} />
      </div>
      <div className='app-content'>
        <Switch>
          <Route path='/eis' exact component={() => <Redirect to='/eis/createWorkRequest' />} />
          <Route path='/eis/createWorkRequest' exact component={JiraForm} />
          <ProtectedRoute path='/eis/mft' component={MFT} module='mft' />
          <Route path='/eis/integrationRegistry' exact component={IntegrationRegistry} />
          <Route path='/eis/MoreDetails' exact component={MoreDetails} />
          <Route path='/eis/GraphView' exact component={GraphView} />
        </Switch>
      </div>
    </ErrorBoundary>
  );
};

export default Main;
