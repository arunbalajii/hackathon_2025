// store.js
import { configureStore } from '@reduxjs/toolkit';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Dummy API URL
const apiUrl = 'https://my-dummy-api.com/registry';

// Create a slice for the registry data
const registrySlice = createSlice({
  name: 'registry',
  initialState: {
    data: [],
    loading: false,
    error: null,
  },
  reducers: {
    setData: (state, action) => {
      state.data = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
  },
});

// Create an async thunk to fetch data from the API
export const fetchRegistryData = createAsyncThunk('registry/fetchData', async () => {
  const response = await axios.get(apiUrl);
  return response.data;
});

// Create the store
const store = configureStore({
  reducer: {
    registry: registrySlice.reducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(registrySlice.middleware),
});

// Export the store and the async thunk
export default store;
