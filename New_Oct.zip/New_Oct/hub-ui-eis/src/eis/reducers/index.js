// 1. Action types:
const SET_PLACEHOLDER = 'SET_PLACEHOLDER';

// 2. Reducers:
const placeholder = (placeholder = {}, action) => {
  if (action.type === SET_PLACEHOLDER) {
    return action.payload;
  }
  return placeholder;
};

export const reducers = {
  placeholder,
};

// 3. helper functions.
export function setPlaceholder(newPlaceholder) {
  return {
    type: SET_PLACEHOLDER,
    payload: newPlaceholder,
  };
}
