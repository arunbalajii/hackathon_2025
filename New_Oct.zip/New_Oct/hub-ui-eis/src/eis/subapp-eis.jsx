import { getBrowserHistory, React } from 'subapp-react';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { reduxLoadSubApp } from 'subapp-redux';
import { reportUser } from '@hub/ui-lib';
import { Route, Router } from 'react-router-dom';
import Main from './Main';
import { reducers as localReducers } from './reducers';

const App = () => {
  const product = useSelector((state) => state.currentProduct);
  const productId = product && product.id;

  useEffect(() => {
    productId && reportUser(productId);
  }, [productId]);
  return <Main />;
};

export default reduxLoadSubApp({
  name: 'Eis',
  Component: App,
  useReactRouter: true,
  reduxReducers: localReducers,
  reduxShareStore: true,
  StartComponent: (props) => {
    return (
      <Router history={getBrowserHistory()}>
        <Route path='/eis'>
          <App {...props} />
        </Route>
      </Router>
    );
  },
});
