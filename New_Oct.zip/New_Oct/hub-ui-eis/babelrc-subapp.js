const config = {};

const ignore = [
  'src/server',
  'src/routes.js',
  'src/home',
  'src/common',
  'src/main',
  'src/footer',
  'src/.__dev_hmr',
  'node_modules',
  'src/test',
];
Object.assign(config, { ignore });

module.exports = {
  extends: '@xarc/app-dev/config/babel/babelrc.js',
  ...config,
};
