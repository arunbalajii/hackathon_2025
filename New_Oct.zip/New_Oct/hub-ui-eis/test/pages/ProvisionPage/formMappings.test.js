'use strict';

import {
  convertFromApiToFormStructure,
  convertToApiStructure,
} from '../../../src/eis/pages/ProvisionPage/formMappings';

let uiDataFromCreateForm;
let responseDataFromApi;

beforeEach(() => {
  // Reset the data being provided by calling services, in case we modified this specific object
  // during one of the tests. An actual API call would result in a new object anyways. So it
  // better mimics that behavior

  uiDataFromCreateForm = {
    name: 'some-resource2',
    activeDirectoryGroup: 'strati-hub-admin',
    trProductId: '985',
    srcr: '54321',
    distributionEmail: 'email@email.com',
    serviceNowGroup: 'snow-group',
    complianceLevel: 'HIPAA',
    applicationTier: 2,
    dataClassification: 'NON_SENSITIVE',
    environments: {
      dev: {
        region: 'southcentralus',
        cores: 11,
        memory: 1000,
      },
      prod: {
        region: 'eastus2',
        cores: 25,
        memory: 5000,
      },
    },
  };

  responseDataFromApi = {
    detail: {
      stratiProductId: 'azure-sql',
      name: 'some-resource1',
      activeDirectoryGroup: 'strati-hub-admin',
      distributionEmail: 'email@email.com',
      serviceNowGroup: 'snow-group',
      srcr: 54321,
      trProductId: 985,
      complianceLevel: 'HIPAA',
      applicationTier: 0,
      dataClassification: 'NON_SENSITIVE',
    },
    environments: [
      {
        type: 'DEV',
        region: 'southcentralus',
        cores: 10,
        memory: 200,
      },
      {
        type: 'PROD',
        region: 'eastus2',
        cores: 50,
        memory: 2000,
      },
    ],
  };
});

test('Translates UI create format into expected API payload', () => {
  const payload = convertToApiStructure(uiDataFromCreateForm);
  const detail = payload.detail;

  expect(detail.trProductId).toBe('985');
  expect(detail.name).toBe('some-resource2');
  expect(detail.activeDirectoryGroup).toBe('strati-hub-admin');
  expect(detail.distributionEmail).toBe('email@email.com');
  expect(detail.srcr).toBe('54321');
  expect(detail.serviceNowGroup).toBe('snow-group');
  expect(detail.complianceLevel).toBe('HIPAA');
  expect(detail.applicationTier).toBe(2);
  expect(detail.dataClassification).toBe('NON_SENSITIVE');

  expect(payload.environments.length).toBe(2);

  const r = payload.environments[1];
  expect(r['type']).toBe('PROD');
  expect(r['region']).toBe('eastus2');
  expect(r['cores']).toBe(25);
  expect(r['memory']).toBe(5000);
});

test('Translates response payload to edit format', () => {
  let editFormat = convertFromApiToFormStructure(responseDataFromApi);

  expect(editFormat.name).toBe('some-resource1');
  expect(editFormat.activeDirectoryGroup).toBe('strati-hub-admin');
  expect(editFormat['distributionEmail']).toBe('email@email.com');
  expect(editFormat['trProductId']).toBe(985);
  expect(editFormat['complianceLevel']).toBe('HIPAA');
  expect(editFormat['serviceNowGroup']).toBe('snow-group');
  expect(editFormat['srcr']).toBe(54321);
  expect(editFormat['applicationTier']).toBe(0);
  expect(editFormat.dataClassification).toBe('NON_SENSITIVE');

  let envs = editFormat.environments;
  const prodEnv = envs['prod'];
  expect(prodEnv['type']).toBe('PROD');
  expect(prodEnv['region']).toBe('eastus2');
  expect(prodEnv['cores']).toBe(50);
  expect(prodEnv['memory']).toBe(2000);
});
