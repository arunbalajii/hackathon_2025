'use strict';

import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { convertFromAPIToDetailsFormat } from '../../../src/eis/pages/Details/detailsMapping';

let responseDataFromApi;

jest.mock('@hub/ui-lib', () => {
  return {
    WalmartResources: {
      findProductById: async (id) => {
        return {
          status: 'SUCCESS',
          data: {
            teamRosterId: id,
            costId: '985',
            name: 'CS - Experience Tools',
            pillar: 'Strati',
            ownerId: 'svenka6',
          },
        };
      },
    },
    ApplicationTiers: () => {
      return {
        findByValue: () => {
          return {
            label: 'Tier 0',
          };
        },
      };
    },
  };
});

beforeEach(() => {
  // Reset the data being provided by calling services, in case we modified this specific object
  // during one of the tests. An actual API call would result in a new object anyways. So it
  // better mimics that behavior

  responseDataFromApi = {
    detail: {
      stratiProductId: 'azure-sql',
      name: 'some-resource1',
      activeDirectoryGroup: 'strati-hub-admin',
      distributionEmail: 'email@email.com',
      serviceNowGroup: 'snow-group',
      srcr: 54321,
      trProductId: 985,
      complianceLevel: 'HIPAA',
      applicationTier: 0,
      dataClassification: 'NON_SENSITIVE',
    },
    environments: [
      {
        type: 'DEV',
        region: 'southcentralus',
        cores: 5,
        memory: 100,
        concordProcessId: '8675309',
        concordStatus: 'FAILED',
      },
      {
        type: 'STAGE',
        region: 'westus',
        cores: 12,
        memory: 2000,
        concordProcessId: '0101010',
        concordStatus: 'PENDING',
      },
      {
        type: 'PROD',
        region: 'eastus2',
        cores: 25,
        memory: 5000,
        concordProcessId: '1111111',
        concordStatus: 'COMPLETED',
      },
    ],
  };
});

test('Translates API response format to UI details page template config', async () => {
  const mock = new MockAdapter(axios);

  mock.onGet('/common/api/walmart-products/985').reply(200, {
    teamRosterId: 985,
    costId: '985',
    name: 'CS - Experience Tools',
    pillar: 'Strati',
    ownerId: 'svenka6',
  });

  const response = await convertFromAPIToDetailsFormat(responseDataFromApi);
  expect(response.emptyMsg).toBe('Currently there are no details associated with the selection.');

  const details = response && response['details'];
  const basicDetails = details && details['basic-details'];

  const trProduct = basicDetails.find((d) => d.key === 'trProduct');
  expect(trProduct['value']).toStrictEqual({ id: 985, name: 'CS - Experience Tools' });
  expect(trProduct['key']).toBe('trProduct');

  const activeDirectoryGroup = basicDetails.find((d) => d.key === 'activeDirectoryGroup');
  expect(activeDirectoryGroup['value']).toBe('strati-hub-admin');
  expect(activeDirectoryGroup['key']).toBe('activeDirectoryGroup');

  const complianceLevel = basicDetails.find((d) => d.key === 'complianceLevel');
  expect(complianceLevel['value']).toBe('HIPAA');
  expect(complianceLevel['key']).toBe('complianceLevel');

  const serviceNowGroup = basicDetails.find((d) => d.key === 'serviceNowGroup');
  expect(serviceNowGroup['value']).toBe('snow-group');
  expect(serviceNowGroup['key']).toBe('serviceNowGroup');

  const srcr = basicDetails.find((d) => d.key === 'srcr');
  expect(srcr['value']).toBe(54321);
  expect(srcr['key']).toBe('srcr');

  const otherDetails = details && details['other-details'];
  expect(otherDetails.length).toBe(3);

  const distributionEmail = otherDetails.find((d) => d.key === 'distributionEmail');
  expect(distributionEmail['value']).toBe('email@email.com');
  expect(distributionEmail['key']).toBe('distributionEmail');

  const applicationTier = otherDetails.find((d) => d.key === 'applicationTier');
  expect(applicationTier['value']).toBe('Tier 0');
  expect(applicationTier['key']).toBe('applicationTier');
  expect(applicationTier['label']).toBe('Application Tier');

  const dataClassification = otherDetails.find((d) => d.key === 'dataClassification');
  expect(dataClassification['value']).toBe('NON_SENSITIVE');
  expect(dataClassification['key']).toBe('dataClassification');

  const resources = response['resources'];

  expect(resources.length).toBe(3);

  let found = resources[2];
  expect(found['type']).toBe('PROD');
  expect(found['region']).toBe('eastus2');
  expect(found['cores']).toBe(25);
  expect(found['memory']).toBe(5000);
  expect(found['concordStatus']).toBe('COMPLETED');
  expect(found['concordProcessId']).toBe('1111111');
});
