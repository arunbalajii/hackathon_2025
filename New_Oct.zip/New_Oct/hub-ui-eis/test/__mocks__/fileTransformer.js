// Mocks every media file to return its filename. Makes it possible to test that
// the correct images are loaded for components.

const path = require('path');

module.exports = {
  process(_sourceText, sourcePath) {
    return {
      code: `module.exports = '${JSON.stringify(path.basename(sourcePath))}';`,
    };
  },
};
