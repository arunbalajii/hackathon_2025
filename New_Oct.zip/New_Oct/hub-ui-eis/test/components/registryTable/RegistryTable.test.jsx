import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import { Router } from 'react-router-dom';
import RegistryTable from '../../../src/eis/pages/IntegrationRegistry/components/registryTable/RegistryTable';

const columns = [
  {
    title: 'Column 1',
    dataIndex: 'column1',
    key: 'column1',
  },
  {
    title: 'Column 2',
    dataIndex: 'column2',
    key: 'column2',
  },
];

const dataSource = [
  {
    key: '1',
    column1: 'Data 1',
    column2: 'Data 2',
    integrationId: '1',
  },
  {
    key: '2',
    column1: 'Data 3',
    column2: 'Data 4',
    integrationId: '2',
  },
];

describe('RegistryTable', () => {
  it('renders without errors', () => {
    const { container } = render(<RegistryTable columns={columns} dataSource={dataSource} />);
    expect(container).toBeTruthy();
  });

  it('renders correct columns', () => {
    const { getByText } = render(<RegistryTable columns={columns} dataSource={dataSource} />);
    expect(getByText('Column 1')).toBeTruthy();
    expect(getByText('Column 2')).toBeTruthy();
    expect(getByText('Data 1')).toBeTruthy();
    expect(getByText('Data 2')).toBeTruthy();
  });

  it('calls handleClick on row double click', () => {
    const history = createMemoryHistory();
    const { getByText } = render(
      <Router history={history}>
        <RegistryTable columns={columns} dataSource={dataSource} />
      </Router>
    );
    const row = getByText('Data 1');
    fireEvent.doubleClick(row);
    expect(history.location.pathname).toBe('/eis/MoreDetails');
    expect(history.location.state).toEqual({ id: '1' });
  });
});
