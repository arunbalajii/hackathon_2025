// See: https://jestjs.io/docs/configuration#setupfilesafterenv-array for full expected use of this
// file.
//
// "Since setupFiles executes before the test framework is installed in the environment, this script
// file presents you the opportunity of running some code immediately after the test framework has
//  been installed in the environment but before the test code itself.
// In other words, setupFilesAfterEnv modules are meant for code which is repeating in each test
// file. Having the test framework installed makes Jest globals, jest object and expect accessible
// in the modules. For example, you can add extra matchers from jest-extended library or call setup
// and teardown hooks"

// See: https://www.npmjs.com/package/jest-fetch-mock
require('jest-fetch-mock').enableMocks();

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});
