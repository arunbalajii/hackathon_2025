'use strict';

module.exports = function (composer, options, compose) {
  const config = compose();
  config.output.uniqueName = require('./package.json').name;
  return config;
};
