'use strict';
const { babelPresetFile } = require('@xarc/app-dev');
module.exports = {
  presets: [babelPresetFile],
  env: {
    development: {
      plugins: ['istanbul'],
    },
  },
};
