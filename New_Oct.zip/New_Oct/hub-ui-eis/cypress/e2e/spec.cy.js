describe('core', () => {
  it('loads main', { tags: ['stage'] }, () => {
    cy.login();
    cy.visit('/eis/eis');
  });
});
