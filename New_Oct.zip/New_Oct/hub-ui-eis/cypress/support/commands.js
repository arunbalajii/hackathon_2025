// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

Cypress.Commands.add('login', () => {
  cy.session('sesh', () => {
    cy.request({
      method: 'POST',
      url: Cypress.env('tokenUrl') ?? 'https://pfedcert.wal-mart.com/as/token.oauth2',
      headers: {
        accept: 'application/json',
        'content-type': 'application/x-www-form-encoded',
      },
      body: {
        grant_type: 'password',
        client_id: Cypress.env('username'),
        scope: 'openid full',
        username: Cypress.env('username'),
        password: Cypress.env('password'),
      },
      form: true,
    }).then((res) => {
      let token = JSON.stringify({ token: res.body.access_token });
      let encToken = Buffer.from(token).toString('base64');

      let userInfo = JSON.stringify({
        basicInfo: {
          loginId: Cypress.env('username').split('@')[0],
          name: '',
          email: Cypress.env('username'),
        },
        additionalInfo: {},
      });
      let encUser = Buffer.from(userInfo).toString('base64');

      cy.setCookie(
        'hub-ping',
        Cypress.config().baseUrl.includes('dev.walmart.com') ? encToken : token,
      );
      cy.setCookie('hub-userInfo', encUser);

      cy.visit('/eis');
    });
  });
});

