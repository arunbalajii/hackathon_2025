[![Build Status](https://ci.electrode.walmart.com/buildStatus/icon?job=hub%2Fhub-ui-eis)](https://ci.electrode.walmart.com/job/hub/job/hub-ui-eis/)

# hub-ui-eis

Host Enterprise Integration Services page on DX platform for application self service operations

## Getting Started

Follow instructions [here](https://dx.walmart.com/gtpjselectrodeplatform/documentation/github/Node-js-Setup-e098b49064f2d2427f3448b22c3210a08db9e226adaee2b930c162fc84e8e363) to set up Nodejs environment if you are running electrode/nodejs project for the first time

Additional [development machine setup](https://dx.walmart.com/documents/product/DX%20Console/08hu0cw1l9) instructions with
special callouts for working with a DX Console subapp.

### Engines

- Node: 16.x
- NPM: 8.x

Currently used versions when deployed as part of [hub-shell-app](https://gecgithub01.walmart.com/hub/hub-shell-app):

```sh
$ node -v
v16.19.1
$ npm -v
8.19.3
```

### Dev Setup

1. Review the details of the [project structure](https://dx.walmart.com/documents/product/DX%20Console/i2ijert7px)
2. Get familiar with the information on [PingFed and SSO](https://dx.walmart.com/documents/product/DX%20Console/je4l1sc6b6). You will likely need to make some modifications to your local config to work with the various SSO environments. **Hub CLI can be helpful to toggle between SSO environments.**
3. Make sure your development machine has been set up properly for [DX Console development](https://dx.walmart.com/documents/product/DX%20Console/08hu0cw1l9).
4. Run the CLI as follows: `npx @hub/cli subapp-setup` for default setup or `npx @hub/cli subapp-setup -e [lab|stage]` for specific environment.  
   _NOTE: You will need to be a member of the hub-dev-community AD group to use the stage settings. You can request to be added to that AD group using [this Service Now request form](https://walmartglobal.service-now.com/wm_sp?id=sc_cat_item_guide&sys_id=b3234c3b4fab8700e4cd49cf0310c7d7)_

### New Product Onboarding

DX provides support for UX and SDK development. Review the [New Product Onboarding](https://dx.walmart.com/documents/product/DX%20Console/y0p9vrisyo) to understand onboarding steps and available support. Follow the [Getting Started](https://dx.walmart.com/documents/product/DX%20Console/y0p9vrisyo#getting-started) steps to get into the DX onboarding queue.

### Installation

#### Step 1 - Go to project directory

```sh
cd hub-ui-eis
```

#### Step 2 - Install node modules

You can install node modules using npm.

```sh
npm install
```

_Note: When running npm install with npm v8 in this app, you will see warnings about conflicting
peer dependencies between @xarc/app, @xarc/app-dev and @xarc/webpack. This is currently, expected
as long as we still use React 16, as we cannot update those packages any further to fix it until we
update React to React 18, which will happen at a later date via a new starter kit migration._

#### Step 3 - Run locally in dev mode

Open terminal and execute the following (keep it running)

```sh
npm run dev
```

Open browser and go to the following url: <https://dev.walmart.com/eis>

### Previewing a PR build in DX Console environment

With our ability to load a module dynamically at runtime we can preview a build that came from a PR branch. To preview
your branch in a DX Console environment simply create a branch and open a PR. That PR name is now available to load
dynamically. Here is an example:

1. Create branch called "my-work-here": `git checkout -b my-work-here`
2. Make obvious change
3. Push to github and create a PR from that branch
4. Monitor [PR build](https://ci.electrode.walmart.com/job/hub/job/hub-ui-eis/)
5. Once build is complete you'll be able to load your branch in DX Console using the `showVersion=my-work-here` query param:  
   <https://console-stage.dx.walmart.com/eis?showVersion=my-work-here>

## References

- [Electrode X](https://wmlink/electrode): UI platform to build web applications
- [DX Console SDK docs](https://wmlink/hub-docs)
- [DX Console remote subapp overview](https://dx.walmart.com/documents/product/DX%20Console/09ydzbmu90)
